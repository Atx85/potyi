// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Fixed-size disk ring. The row index is on disk, not a growing heap vector.
use std::{
    fs::{File, OpenOptions},
    io::{self, BufWriter, Read, Seek, SeekFrom, Write},
    path::PathBuf,
};
pub(super) const HISTORY_BYTES: usize = 8 * 1024 * 1024;
const INDEX_ROWS: usize = 65536;
const INDEX_RECORD: usize = 16;
const DATA_BYTES: usize = HISTORY_BYTES - INDEX_ROWS * INDEX_RECORD;
// Encoded records include a bounded command plus native path metadata.
const MAX_ROW_BYTES: usize = 256 * 1024;

#[derive(Debug)]
pub(super) struct Row {
    pub cols: u16,
    pub wrapped: bool,
    pub bytes: Vec<u8>,
}
#[derive(Debug)]
pub(super) struct History {
    path: PathBuf,
    data: Option<BufWriter<File>>,
    index: Option<BufWriter<File>>,
    reader: Option<File>,
    first: usize,
    count: usize,
    used: usize,
    write: usize,
    pub(super) serial: u64,
    pub(super) error: Option<String>,
    failed: bool,
}
impl History {
    pub(super) fn new() -> io::Result<Self> {
        let mut random = [0u8; 16];
        getrandom::getrandom(&mut random).map_err(|e| io::Error::other(e.to_string()))?;
        let suffix: String = random.iter().map(|b| format!("{b:02x}")).collect();
        let path = std::env::temp_dir().join(format!("potyi-terminal-{suffix}.history"));
        let mut options = OpenOptions::new();
        options.read(true).write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let file = options.open(&path)?;
        // Construct the owner first, so every failure closes handles and
        // removes the temporary file through Drop.
        let mut history = Self {
            path,
            data: Some(BufWriter::with_capacity(32 * 1024, file)),
            index: None,
            reader: None,
            first: 0,
            count: 0,
            used: 0,
            write: 0,
            serial: 0,
            error: None,
            failed: false,
        };
        history
            .data
            .as_ref()
            .unwrap()
            .get_ref()
            .set_len(HISTORY_BYTES as u64)?;
        history.reader = Some(OpenOptions::new().read(true).open(&history.path)?);
        let mut index = OpenOptions::new().write(true).open(&history.path)?;
        index.seek(SeekFrom::Start(DATA_BYTES as u64))?;
        history.index = Some(BufWriter::with_capacity(8 * 1024, index));
        Ok(history)
    }
    pub(super) fn len(&self) -> usize {
        self.count
    }
    pub(super) fn clear(&mut self) -> io::Result<()> {
        self.data.as_mut().unwrap().seek(SeekFrom::Start(0))?;
        self.index
            .as_mut()
            .unwrap()
            .seek(SeekFrom::Start(DATA_BYTES as u64))?;
        self.first = 0;
        self.count = 0;
        self.used = 0;
        self.write = 0;
        Ok(())
    }
    pub(super) fn flush(&mut self) -> io::Result<()> {
        self.data.as_mut().unwrap().flush()?;
        self.index.as_mut().unwrap().flush()
    }
    fn metadata(&mut self, row: usize) -> io::Result<[u8; INDEX_RECORD]> {
        let mut bytes = [0u8; INDEX_RECORD];
        let slot = (self.first + row) % INDEX_ROWS;
        let reader = self.reader.as_mut().unwrap();
        reader.seek(SeekFrom::Start((DATA_BYTES + slot * INDEX_RECORD) as u64))?;
        reader.read_exact(&mut bytes)?;
        Ok(bytes)
    }
    fn evict(&mut self) -> io::Result<()> {
        self.index.as_mut().unwrap().flush()?;
        // Evict in small batches to amortize disk-index reads under sustained output.
        let count = self.count.min(256);
        let mut bytes = [0u8; 256 * INDEX_RECORD];
        let first = count.min(INDEX_ROWS - self.first);
        let reader = self.reader.as_mut().unwrap();
        reader.seek(SeekFrom::Start(
            (DATA_BYTES + self.first * INDEX_RECORD) as u64,
        ))?;
        reader.read_exact(&mut bytes[..first * INDEX_RECORD])?;
        if first < count {
            reader.seek(SeekFrom::Start(DATA_BYTES as u64))?;
            reader.read_exact(&mut bytes[first * INDEX_RECORD..count * INDEX_RECORD])?;
        }
        for record in bytes[..count * INDEX_RECORD].chunks_exact(INDEX_RECORD) {
            self.used -= u32::from_le_bytes(record[4..8].try_into().unwrap()) as usize;
        }
        self.first = (self.first + count) % INDEX_ROWS;
        self.count -= count;
        Ok(())
    }
    fn append(&mut self, cols: u16, wrapped: bool, bytes: &[u8]) -> io::Result<()> {
        if bytes.len() > MAX_ROW_BYTES {
            return Err(io::Error::other("History row exceeds its storage limit"));
        }
        while self.count == INDEX_ROWS || self.used + bytes.len() > DATA_BYTES {
            self.evict()?;
        }
        let offset = self.write;
        let first = bytes.len().min(DATA_BYTES - self.write);
        let data = self.data.as_mut().unwrap();
        data.write_all(&bytes[..first])?;
        if first < bytes.len() {
            data.seek(SeekFrom::Start(0))?;
            data.write_all(&bytes[first..])?;
        }
        self.write = (self.write + bytes.len()) % DATA_BYTES;
        if self.write == 0 {
            data.seek(SeekFrom::Start(0))?;
        }
        let slot = (self.first + self.count) % INDEX_ROWS;
        if slot == 0 {
            self.index
                .as_mut()
                .unwrap()
                .seek(SeekFrom::Start(DATA_BYTES as u64))?;
        }
        let mut meta = [0u8; INDEX_RECORD];
        meta[..4].copy_from_slice(&(offset as u32).to_le_bytes());
        meta[4..8].copy_from_slice(&(bytes.len() as u32).to_le_bytes());
        meta[8..10].copy_from_slice(&cols.to_le_bytes());
        meta[10] = u8::from(wrapped);
        self.index.as_mut().unwrap().write_all(&meta)?;
        self.used += bytes.len();
        self.count += 1;
        self.serial = self.serial.saturating_add(1);
        Ok(())
    }
    pub(super) fn row(&mut self, row: usize) -> io::Result<Row> {
        if row >= self.count {
            return Err(io::Error::other("History row is out of range"));
        }
        self.flush()?;
        let meta = self.metadata(row)?;
        let offset = u32::from_le_bytes(meta[..4].try_into().unwrap()) as usize;
        let size = u32::from_le_bytes(meta[4..8].try_into().unwrap()) as usize;
        if offset >= DATA_BYTES || size > MAX_ROW_BYTES {
            return Err(io::Error::other("Invalid history record"));
        }
        let mut bytes = vec![0; size];
        let first = size.min(DATA_BYTES - offset);
        let reader = self.reader.as_mut().unwrap();
        reader.seek(SeekFrom::Start(offset as u64))?;
        reader.read_exact(&mut bytes[..first])?;
        if first < size {
            reader.seek(SeekFrom::Start(0))?;
            reader.read_exact(&mut bytes[first..])?;
        }
        Ok(Row {
            cols: u16::from_le_bytes(meta[8..10].try_into().unwrap()),
            wrapped: meta[10] != 0,
            bytes,
        })
    }
    /// Update fixed-size metadata in place without changing record identity.
    pub(super) fn replace(&mut self, row: usize, bytes: &[u8]) -> io::Result<()> {
        if row >= self.count {
            return Err(io::Error::other("History row is out of range"));
        }
        self.flush()?;
        let meta = self.metadata(row)?;
        let offset = u32::from_le_bytes(meta[..4].try_into().unwrap()) as usize;
        let size = u32::from_le_bytes(meta[4..8].try_into().unwrap()) as usize;
        if offset >= DATA_BYTES || size > MAX_ROW_BYTES || size != bytes.len() {
            return Err(io::Error::other("History replacement must preserve record size"));
        }
        let first = size.min(DATA_BYTES - offset);
        let data = self.data.as_mut().unwrap();
        data.seek(SeekFrom::Start(offset as u64))?;
        data.write_all(&bytes[..first])?;
        if first < size {
            data.seek(SeekFrom::Start(0))?;
            data.write_all(&bytes[first..])?;
        }
        data.seek(SeekFrom::Start(self.write as u64))?;
        Ok(())
    }
    #[cfg(test)]
    pub(super) fn buffer_capacity(&self) -> usize {
        self.data.as_ref().unwrap().capacity() + self.index.as_ref().unwrap().capacity()
    }
}
impl vt100::ScrollbackSink for History {
    fn push(&mut self, cols: u16, wrapped: bool, formatted: &[u8]) {
        if !self.failed
            && let Err(error) = self.append(cols, wrapped, formatted)
        {
            self.failed = true;
            self.error = Some(format!("History write failed: {error}"));
        }
    }
    fn clear(&mut self) {
        if let Err(error) = History::clear(self) {
            self.failed = true;
            self.error = Some(format!("History clear failed: {error}"));
        }
    }
}
impl Drop for History {
    fn drop(&mut self) {
        // Close every handle before deletion, including on Windows.
        self.data.take();
        self.index.take();
        self.reader.take();
        let _ = std::fs::remove_file(&self.path);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use vt100::ScrollbackSink;
    #[test]
    fn metadata_replacement_preserves_ring_ids_and_future_appends() {
        let mut history = History::new().unwrap();
        let payload = vec![b'x'; 60000];
        for _ in 0..200 { history.push(80, false, &payload); }
        let len = history.len();
        let serial = history.serial;
        for index in [0, len / 2, len - 1] {
            let replacement = vec![b'a' + (index % 20) as u8; 60000];
            history.replace(index, &replacement).unwrap();
            assert_eq!(history.row(index).unwrap().bytes, replacement);
        }
        assert_eq!(history.serial, serial);
        assert_eq!(history.len(), len);
        assert!(history.replace(0, b"wrong size").is_err());
        history.push(80, false, b"after");
        assert_eq!(history.row(history.len() - 1).unwrap().bytes, b"after");
    }
    #[test]
    fn file_history_wraps_data_and_disk_index_with_constant_work_buffers() {
        let mut history = History::new().unwrap();
        let capacity = history.buffer_capacity();
        for index in 0..80000 {
            history.push(80, false, format!("ROW_{index:06}").as_bytes());
        }
        assert!(history.len() <= INDEX_ROWS);
        assert_eq!(history.buffer_capacity(), capacity);
        assert_eq!(history.row(history.len() - 1).unwrap().bytes, b"ROW_079999");
        let payload = vec![b'x'; MAX_ROW_BYTES - 100];
        for _ in 0..160 {
            history.push(256, true, &payload);
        }
        assert!(history.used <= DATA_BYTES);
        assert_eq!(history.row(history.len() - 1).unwrap().bytes, payload);
        assert_eq!(
            std::fs::metadata(&history.path).unwrap().len(),
            HISTORY_BYTES as u64
        );
        let path = history.path.clone();
        drop(history);
        assert!(!path.exists());
    }
    #[test]
    fn file_history_clear_reuses_the_file_and_preserves_row_metadata() {
        let mut history = History::new().unwrap();
        history.push(80, true, "é界".as_bytes());
        let row = history.row(0).unwrap();
        assert_eq!(row.cols, 80);
        assert!(row.wrapped);
        assert_eq!(row.bytes, "é界".as_bytes());
        history.clear().unwrap();
        assert_eq!(history.len(), 0);
        history.push(120, false, b"new");
        assert_eq!(history.row(0).unwrap().bytes, b"new");
        assert_eq!(history.row(0).unwrap().cols, 120);
    }
}
