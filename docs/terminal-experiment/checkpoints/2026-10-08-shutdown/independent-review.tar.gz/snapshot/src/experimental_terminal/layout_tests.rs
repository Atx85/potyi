// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
use super::super::transcript::Transcript;
use super::*;
use std::{path::PathBuf, sync::Arc};

fn cwd() -> PathBuf {
    std::env::temp_dir().canonicalize().unwrap()
}
fn native(text: &str, cell: Option<u8>) -> Vec<u8> {
    let mut bytes = Vec::new();
    bytes.extend_from_slice(&(text.len() as u32).to_le_bytes());
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&[
        0,
        0,
        1,
        150,
        220,
        165,
        u8::from(cell.is_some()),
        cell.unwrap_or(0),
    ]);
    bytes.extend_from_slice(text.as_bytes());
    bytes
}
fn layout(shared: SharedTranscript, columns: u16) -> Layout {
    let mut layout = Layout::new(shared, Arc::new(|| {})).unwrap();
    layout.configure(Metrics {
        columns,
        tab_width: 4,
    });
    drain(&mut layout);
    layout
}
fn drain(layout: &mut Layout) {
    let deadline = Instant::now() + Duration::from_secs(20);
    while layout.pending() {
        layout.poll().unwrap();
        assert!(Instant::now() < deadline, "Layout bounded work timed out");
    }
}
fn view(layout: &mut Layout, start: usize, count: usize) -> Vec<Fragment> {
    for _ in 0..8 {
        let rows = layout.visible(start, count).unwrap();
        if layout.query.as_ref().is_some_and(|query| {
            query.start == start
                && query.count == count.min(MAX_VISIBLE_ROWS)
                && query.ready
                && query.revision == layout.projection_revision
        }) {
            return rows;
        }
        if layout.complete && layout.len() == 0 {
            return rows;
        }
        drain(layout);
    }
    panic!("Viewport did not reach the requested projection")
}
fn row_at(layout: &mut Layout, anchor: Anchor) -> Option<usize> {
    let value = layout.row_at(anchor).unwrap();
    if value.is_some() {
        return value;
    }
    drain(layout);
    layout.row_at(anchor).unwrap()
}

#[test]
fn native_columns_are_row_major_and_padding_has_no_source_anchor() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let anchors = {
        let mut store = shared.lock().unwrap();
        ["../", "a.rs", "b.rs", "c.rs"]
            .into_iter()
            .map(|text| {
                store
                    .append_native(&cwd, 1, &native(text, Some(7)))
                    .unwrap()
            })
            .collect::<Vec<_>>()
    };
    let mut layout = layout(shared, 12);
    let rows = view(&mut layout, 0, 20);
    assert_eq!(
        rows.iter().map(|row| row.text.as_str()).collect::<Vec<_>>(),
        ["../    a.rs", "b.rs   c.rs"]
    );
    assert_eq!(rows[0].segments.len(), 2);
    assert_eq!(rows[0].segments[0].range, 0..3);
    assert_eq!(rows[0].segments[1].range, 7..11);
    assert_eq!(rows[0].segments[1].column, 7);
    assert_eq!(rows[0].segments[1].start, anchors[1]);
    assert_eq!(row_at(&mut layout, anchors[0]), Some(0));
    assert_eq!(row_at(&mut layout, anchors[1]), Some(0));
    assert_eq!(row_at(&mut layout, anchors[2]), Some(1));
    assert_eq!(rows[0].anchor_column(5), rows[0].segments[0].end);
    assert!(rows[0].start < rows[0].end && rows[0].end < rows[1].start);
}

#[test]
fn one_per_line_and_recursive_headers_stop_packing() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    {
        let mut store = shared.lock().unwrap();
        store.append_native(&cwd, 1, &native("a", Some(5))).unwrap();
        store
            .append_native(&cwd, 1, &native("child:", None))
            .unwrap();
        store.append_native(&cwd, 1, &native("b", Some(5))).unwrap();
        store.append_native(&cwd, 1, &native("c", Some(5))).unwrap();
        store.append_native(&cwd, 2, &native("one", None)).unwrap();
        store.append_native(&cwd, 2, &native("two", None)).unwrap();
    }
    let mut layout = layout(shared, 20);
    assert_eq!(
        view(&mut layout, 0, 20)
            .iter()
            .map(|row| row.text.as_str())
            .collect::<Vec<_>>(),
        ["a", "child:", "b    c", "one", "two"]
    );
}

#[test]
fn word_wrap_retains_unicode_combining_tabs_long_words_and_blank_lines() {
    let shared = Transcript::shared().unwrap();
    let text = "東京🙂\ta\u{301} word\n\nlongwordwithoutspaces";
    shared
        .lock()
        .unwrap()
        .append_header(&cwd(), 1, text)
        .unwrap();
    let mut layout = layout(shared, 8);
    let rows = view(&mut layout, 0, 40);
    assert!(rows.iter().any(|row| row.text.is_empty()));
    assert!(rows.iter().any(|row| row.text.contains("a\u{301}")));
    assert_eq!(
        rows.iter().map(|row| row.text.as_str()).collect::<String>(),
        text.replace('\t', "  ").replace('\n', "")
    );
    for row in &rows {
        assert!(row.text.trim_end().width() <= 8);
        for segment in &row.segments {
            assert!(row.text.is_char_boundary(segment.range.start));
            assert!(row.text.is_char_boundary(segment.range.end));
        }
    }
}

#[test]
fn terminal_soft_wrap_seams_keep_byte_anchors_and_command_boundaries() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let (first, second) = {
        let mut store = shared.lock().unwrap();
        let first = store.append_terminal(&cwd, 1, 20, true, b"hello ").unwrap();
        let second = store
            .append_terminal(&cwd, 1, 20, false, b"world longer")
            .unwrap();
        store.append_terminal(&cwd, 2, 20, true, b"other").unwrap();
        store
            .append_terminal(&cwd, 3, 20, false, b"command")
            .unwrap();
        (first, second)
    };
    let mut layout = layout(shared, 8);
    let rows = view(&mut layout, 0, 20);
    assert_eq!(
        rows.iter().map(|row| row.text.as_str()).collect::<Vec<_>>(),
        ["hello ", "world ", "longer", "other", "command"]
    );
    assert_eq!(rows[0].start, first);
    assert_eq!(rows[1].segments[0].record_id, second.record_id);
    assert_eq!(row_at(&mut layout, second), Some(1));
    assert!(rows[2].end < rows[3].start);
}

#[test]
fn ansi_styles_survive_reflow_in_bounded_runs() {
    let shared = Transcript::shared().unwrap();
    shared
        .lock()
        .unwrap()
        .append_terminal(
            &cwd(),
            1,
            80,
            false,
            b"\x1b[1;3;4;7;38;2;10;20;30;48;2;40;50;60mstyled\x1b[0m plain \x1b[2mdim",
        )
        .unwrap();
    let mut layout = layout(shared, 8);
    let rows = view(&mut layout, 0, 20);
    let styled = &rows[0].segments[0].style;
    assert_eq!(styled.fg, vt100::Color::Rgb(10, 20, 30));
    assert_eq!(styled.bg, vt100::Color::Rgb(40, 50, 60));
    assert!(styled.bold && styled.italic && styled.inverse && styled.underline);
    assert!(
        rows.iter()
            .flat_map(|row| &row.segments)
            .any(|segment| segment.style.dim)
    );
}

#[test]
fn token_across_saved_physical_rows_is_one_reflowable_line() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let (first, second) = {
        let mut store = shared.lock().unwrap();
        (
            store.append_terminal(&cwd, 1, 4, true, b"long").unwrap(),
            store.append_terminal(&cwd, 1, 4, false, b"word").unwrap(),
        )
    };
    let mut layout = layout(shared, 6);
    let rows = view(&mut layout, 0, 10);
    assert_eq!(
        rows.iter().map(|row| row.text.as_str()).collect::<Vec<_>>(),
        ["longwo", "rd"]
    );
    assert_eq!(rows[0].start, first);
    assert!(
        rows[0]
            .segments
            .iter()
            .any(|segment| segment.record_id == second.record_id)
    );
    assert_eq!(row_at(&mut layout, second), Some(0));
    assert_eq!(
        row_at(
            &mut layout,
            Anchor {
                utf8_byte_offset: 2,
                ..second
            }
        ),
        Some(1)
    );
}

#[test]
fn saved_live_seam_and_incremental_sealing_keep_future_ids_stable() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    shared
        .lock()
        .unwrap()
        .append_terminal(&cwd, 7, 4, true, b"long")
        .unwrap();
    let mut layout = layout(shared.clone(), 6);
    let mut live = vt100::Parser::new(2, 4, 0);
    live.process(b"word\r\nnext");
    layout.set_tail(live.screen(), 0, 2, 7).unwrap();
    drain(&mut layout);
    let rows = view(&mut layout, 0, 20);
    assert_eq!(
        rows.iter().map(|row| row.text.as_str()).collect::<Vec<_>>(),
        ["longwo", "rd", "next"]
    );
    let remaining = rows[2].start;
    assert_eq!(remaining.record_id, 2);
    assert_eq!(row_at(&mut layout, remaining), Some(2));
    shared
        .lock()
        .unwrap()
        .append_terminal(
            &cwd,
            7,
            4,
            false,
            &live.screen().row_scrollback_formatted(0),
        )
        .unwrap();
    layout.set_tail(live.screen(), 1, 1, 7).unwrap();
    drain(&mut layout);
    let sealed = view(&mut layout, 0, 20);
    assert_eq!(sealed[2].start, remaining);
    assert_eq!(
        sealed
            .iter()
            .map(|row| row.text.as_str())
            .collect::<Vec<_>>(),
        ["longwo", "rd", "next"]
    );
    assert_eq!(shared.lock().unwrap().len(), 2);
    shared
        .lock()
        .unwrap()
        .append_terminal(
            &cwd,
            7,
            4,
            false,
            &live.screen().row_scrollback_formatted(1),
        )
        .unwrap();
    layout.set_tail(live.screen(), 0, 0, 7).unwrap();
    drain(&mut layout);
    assert_eq!(view(&mut layout, 0, 20)[2].start, remaining);
    assert!(layout.tail.is_none());
}

#[test]
fn live_grid_bounds_and_primary_snapshot_do_not_duplicate_disk_history() {
    let shared = Transcript::shared().unwrap();
    let mut layout = layout(shared.clone(), 20);
    let oversized = vt100::Parser::new(161, 1, 0);
    assert!(layout.set_tail(oversized.screen(), 0, 1, 1).is_err());
    let valid = vt100::Parser::new(160, 256, 0);
    layout.set_tail(valid.screen(), 0, 160, 1).unwrap();
    assert_eq!(layout.tail.as_ref().unwrap().count, 160);
    layout.set_tail(valid.screen(), 0, 0, 1).unwrap();
    let mut live = vt100::Parser::new(2, 20, 0);
    live.process(b"primary\x1b[?1049halt");
    layout.set_tail(live.screen(), 0, 1, 1).unwrap();
    drain(&mut layout);
    assert_eq!(view(&mut layout, 0, 20)[0].text, "primary");
    assert_eq!(shared.lock().unwrap().len(), 0);
}

#[test]
fn continuous_append_color_and_follow_targets_publish_bounded_frames() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let first = shared
        .lock()
        .unwrap()
        .append_native(&cwd, 1, &native("old", None))
        .unwrap();
    for index in 0..300 {
        shared
            .lock()
            .unwrap()
            .append_header(&cwd, 2, &format!("row{index}"))
            .unwrap();
    }
    let mut layout = layout(shared.clone(), 80);
    assert!(!view(&mut layout, 0, 40).is_empty());
    let mut publications = 0;
    for index in 0..150 {
        let mut color = native("old", None);
        color[11] = index as u8;
        {
            let mut store = shared.lock().unwrap();
            store.replace_native(first.record_id, &color).unwrap();
            store
                .append_header(&cwd, 2, &format!("new{index}"))
                .unwrap();
        }
        layout.poll().unwrap();
        let start = layout.len().saturating_sub(40);
        if !layout.visible(start, 40).unwrap().is_empty() {
            publications += 1;
        }
    }
    assert!(publications > 100);
    drain(&mut layout);
    let start = layout.len().saturating_sub(40);
    let latest = view(&mut layout, start, 40);
    assert!(latest.iter().any(|row| row.text == "new149"));
    assert!(layout.query.as_ref().unwrap().bytes <= MAX_VISIBLE_BYTES);
}

#[test]
fn repeated_live_updates_preserve_a_ready_scrolled_frame_during_rewind() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    for index in 0..100 {
        shared
            .lock()
            .unwrap()
            .append_header(&cwd, 1, &format!("past{index}"))
            .unwrap();
    }
    let mut layout = layout(shared, 20);
    let mut live = vt100::Parser::new(20, 20, 0);
    live.process(b"before");
    layout.set_tail(live.screen(), 0, 20, 2).unwrap();
    drain(&mut layout);
    assert!(!view(&mut layout, 100, 20).is_empty());
    for index in 0..30 {
        live.process(format!("\x1b[Hchanged{index}").as_bytes());
        layout.set_tail(live.screen(), 0, 20, 2).unwrap();
        assert!(!layout.visible(100, 20).unwrap().is_empty());
        layout.poll().unwrap();
    }
    drain(&mut layout);
    assert!(view(&mut layout, 100, 20)[0].text.starts_with("changed29"));
    assert_eq!(layout.cached_start(), Some(100));
    assert!(layout.published_tail().is_some());
}

#[test]
fn continuously_mutating_initial_tail_finishes_captured_index_passes() {
    let shared = Transcript::shared().unwrap();
    let mut layout = layout(shared, 20);
    let mut live = vt100::Parser::new(100, 20, 0);
    for index in 0..100 {
        live.process(format!("\x1b[Hupdate{index}").as_bytes());
        layout.set_tail(live.screen(), 0, 100, 3).unwrap();
        layout.poll().unwrap();
    }
    assert_eq!(layout.len(), 100);
    drain(&mut layout);
    let rows = view(&mut layout, 99, 1);
    assert_eq!(rows.len(), 1);
    assert_eq!(rows[0].start.record_id, 99);
}

#[test]
fn huge_tab_runs_and_dense_style_changes_stay_inside_projection_budget() {
    let shared = Transcript::shared().unwrap();
    shared
        .lock()
        .unwrap()
        .append_header(&cwd(), 1, &"\t".repeat(64 * 1024))
        .unwrap();
    let mut layout = layout(shared, 1);
    let rows = view(&mut layout, 0, usize::MAX);
    assert!(!rows.is_empty());
    assert!(rows.iter().map(Fragment::bytes).sum::<usize>() <= MAX_VISIBLE_BYTES);
    assert!(
        rows.iter()
            .all(|row| row.segments.len() <= MAX_FRAGMENT_SEGMENTS)
    );
    assert!(rows.iter().all(|row| row.text.len() <= MAX_FRAGMENT_BYTES));
}

#[test]
fn resize_append_and_color_only_revision_preserve_logical_positions() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let anchor = shared
        .lock()
        .unwrap()
        .append_native(&cwd, 1, &native("one two three", None))
        .unwrap();
    let mut layout = layout(shared.clone(), 8);
    let before = view(&mut layout, 0, 20);
    assert_eq!(before.len(), 2);
    let target = Anchor {
        utf8_byte_offset: 8,
        ..anchor
    };
    assert_eq!(row_at(&mut layout, target), Some(1));
    layout.configure(Metrics {
        columns: 20,
        tab_width: 4,
    });
    drain(&mut layout);
    assert_eq!(row_at(&mut layout, target), Some(0));
    let checkpoints = layout
        .checkpoints
        .iter()
        .map(|point| (point.row, point.cursor))
        .collect::<Vec<_>>();
    let mut changed = native("one two three", None);
    changed[11..14].copy_from_slice(&[1, 2, 3]);
    shared
        .lock()
        .unwrap()
        .replace_native(anchor.record_id, &changed)
        .unwrap();
    layout.poll().unwrap();
    assert_eq!(
        layout
            .checkpoints
            .iter()
            .map(|point| (point.row, point.cursor))
            .collect::<Vec<_>>(),
        checkpoints
    );
    assert_eq!(
        view(&mut layout, 0, 20)[0].segments[0].color,
        Some((1, 2, 3))
    );
    shared
        .lock()
        .unwrap()
        .append_header(&cwd, 2, "new output")
        .unwrap();
    layout.poll().unwrap();
    drain(&mut layout);
    assert_eq!(row_at(&mut layout, target), Some(0));
    assert_eq!(layout.len(), 2);
}

#[test]
fn sparse_checkpoints_and_visible_projection_are_fixed_bounded_caches() {
    let shared = Transcript::shared().unwrap();
    shared
        .lock()
        .unwrap()
        .append_header(&cwd(), 1, &"x".repeat(64 * 1024))
        .unwrap();
    let mut layout = layout(shared, 1);
    assert_eq!(layout.len(), 64 * 1024);
    assert!(layout.checkpoints.len() <= CHECKPOINTS);
    assert!(layout.checkpoints.capacity() * mem::size_of::<Checkpoint>() <= 128 * 1024);
    assert!(layout.stride > 16);
    let rows = view(&mut layout, 60_000, usize::MAX);
    assert_eq!(rows.len(), MAX_VISIBLE_ROWS);
    assert!(rows.iter().map(Fragment::bytes).sum::<usize>() <= MAX_VISIBLE_BYTES);
    assert_eq!(rows[0].start.utf8_byte_offset, 60_000);
}

#[test]
fn eviction_and_clear_reject_old_anchors_and_do_not_grow_the_index() {
    let shared = Transcript::shared().unwrap();
    let cwd = cwd();
    let first = shared
        .lock()
        .unwrap()
        .append_header(&cwd, 1, "old")
        .unwrap();
    let mut layout = layout(shared.clone(), 80);
    {
        let mut store = shared.lock().unwrap();
        for _ in 0..150 {
            store
                .append_header(&cwd, 2, &"x".repeat(64 * 1024))
                .unwrap();
        }
    }
    layout.poll().unwrap();
    drain(&mut layout);
    assert_eq!(row_at(&mut layout, first), None);
    assert!(layout.checkpoints.len() <= CHECKPOINTS);
    shared.lock().unwrap().clear().unwrap();
    layout.poll().unwrap();
    assert_eq!(layout.len(), 0);
    assert!(layout.complete());
    assert!(view(&mut layout, 0, 20).is_empty());
    assert_eq!(row_at(&mut layout, first), None);
}

#[test]
fn vertical_navigation_is_independent_of_viewport_requests() {
    let shared = Transcript::shared().unwrap();
    let anchor = shared
        .lock()
        .unwrap()
        .append_header(&cwd(), 1, "abcd efgh ijkl")
        .unwrap();
    let mut layout = layout(shared, 5);
    assert_eq!(row_at(&mut layout, anchor), Some(0));
    assert_eq!(layout.neighbour(anchor, 1, 2).unwrap(), None);
    layout.visible(0, 20).unwrap();
    drain(&mut layout);
    let down = layout.neighbour(anchor, 1, 2).unwrap().unwrap();
    assert_eq!(down.utf8_byte_offset, 7);
    assert_eq!(row_at(&mut layout, down), Some(1));
    if layout.row_edge(down, true).unwrap().is_none() {
        drain(&mut layout);
    }
    assert_eq!(
        layout
            .row_edge(down, true)
            .unwrap()
            .unwrap()
            .utf8_byte_offset,
        10
    );
}
