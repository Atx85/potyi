// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Bounded text adapters for visible navigation and background clipboard reads.
use super::{
    output_selection::{self, Bounds, RecordText, TextSource},
    session::Session,
    transcript::{RecordData, SharedTranscript},
};
use std::{
    io,
    sync::{Arc, atomic::{AtomicBool, Ordering}},
};

pub(super) struct Source<'a> {
    pub(super) store: &'a SharedTranscript,
    pub(super) session: &'a Session,
}
impl TextSource for Source<'_> {
    fn bounds(&self) -> Bounds {
        let store = self.store.lock().unwrap();
        Bounds {
            epoch: store.epoch(),
            first: store.base_id(),
            end: store.base_id() + store.len() as u64 + self.session.live_tail_rows() as u64,
        }
    }
    fn text(&mut self, id: u64) -> io::Result<RecordText> {
        let mut store = self.store.lock().unwrap();
        let saved_end = store.base_id() + store.len() as u64;
        if id < saved_end {
            let record = store.read_id(id)?;
            let next_matches = if id + 1 < saved_end {
                let next = store.read_id(id + 1)?;
                next.source == record.source && matches!(next.data, RecordData::Terminal { .. })
            } else { self.session.live_tail_rows() > 0 && self.session.tail_source() == Some(record.source) };
            drop(store);
            let mut text = output_selection::record_text(&record)?;
            text.join_next &= next_matches;
            Ok(text)
        } else {
            drop(store);
            let (screen, start, count) = self.session.tail_screen()
                .ok_or_else(|| io::Error::other("Output tail is no longer available"))?;
            let row = id.checked_sub(saved_end).filter(|row| *row < count as u64)
                .ok_or_else(|| io::Error::other("Output anchor is outside the live tail"))? as u16;
            let mut text = output_selection::terminal_row_text(screen, start + row);
            text.join_next &= row + 1 < count;
            Ok(text)
        }
    }
}

#[derive(Clone)]
pub(super) struct PinnedTail {
    screen: Arc<vt100::Screen>,
    first: u64,
    start: u16,
    count: u16,
    source: Option<u64>,
}
impl PinnedTail {
    pub(super) fn covers(&self, id: u64) -> bool { id >= self.first && id < self.first + u64::from(self.count) }
    pub(super) fn source(&self) -> Option<u64> { self.source }
}
pub(super) struct FrozenSource {
    store: SharedTranscript,
    bounds: Bounds,
    saved_end: u64,
    tail: Option<PinnedTail>,
    cancelled: Arc<AtomicBool>,
}
impl Source<'_> {
    /// Only the bounded transient screen is copied. Retained text stays on disk.
    pub(super) fn pin(screen: &vt100::Screen, start: u16, count: u16, source: u64, first: u64) -> PinnedTail {
        PinnedTail { screen: Arc::new(screen.normal_screen_clone()), start, count, source: Some(source), first }
    }
    pub(super) fn freeze(&self, cancelled: Arc<AtomicBool>) -> FrozenSource {
        self.freeze_pinned(cancelled, None)
    }
    pub(super) fn freeze_pinned(&self, cancelled: Arc<AtomicBool>, pinned: Option<&PinnedTail>) -> FrozenSource {
        let store = self.store.lock().unwrap();
        let saved_end = store.base_id() + store.len() as u64;
        let tail = pinned.cloned().or_else(|| self.session.tail_screen().map(|(screen, start, count)| PinnedTail {
            screen: Arc::new(if screen.alternate_screen() { screen.clone() } else { screen.normal_screen_clone() }),
            first: saved_end, start, count, source: self.session.tail_source(),
        }));
        FrozenSource {
            store: self.store.clone(),
            bounds: Bounds {
                epoch: store.epoch(), first: store.base_id(),
                end: tail.as_ref().map_or(saved_end, |tail| saved_end.max(tail.first + u64::from(tail.count))),
            },
            saved_end, tail, cancelled,
        }
    }
}
impl TextSource for FrozenSource {
    fn bounds(&self) -> Bounds { self.bounds }
    fn text(&mut self, id: u64) -> io::Result<RecordText> {
        if self.cancelled.load(Ordering::Acquire) {
            return Err(io::Error::other("Copy cancelled"));
        }
        let mut store = self.store.lock().unwrap();
        if store.epoch() != self.bounds.epoch || store.base_id() > self.bounds.first {
            return Err(io::Error::other("History changed while copying; try again"));
        }
        if let Some(tail) = self.tail.as_ref().filter(|tail| id >= tail.first && id < tail.first + u64::from(tail.count)) {
            drop(store);
            let row = (id - tail.first) as u16;
            let mut text = output_selection::terminal_row_text(&tail.screen, tail.start + row);
            text.join_next &= row + 1 < tail.count;
            return Ok(text);
        }
        if id < self.saved_end {
            let record = store.read_id(id)?;
            let next_matches = if let Some(tail) = self.tail.as_ref().filter(|tail| id + 1 >= tail.first && id + 1 < tail.first + u64::from(tail.count)) {
                tail.source == Some(record.source)
            } else if id + 1 < self.saved_end {
                let next = store.read_id(id + 1)?;
                next.source == record.source && matches!(next.data, RecordData::Terminal { .. })
            } else { self.tail.as_ref().is_some_and(|tail| tail.first <= self.saved_end && self.saved_end < tail.first + u64::from(tail.count) && tail.source == Some(record.source)) };
            drop(store);
            let mut text = output_selection::record_text(&record)?;
            text.join_next &= next_matches;
            Ok(text)
        } else {
            drop(store);
            let tail = self.tail.as_ref().ok_or_else(|| io::Error::other("No captured output tail"))?;
            let row = id.checked_sub(tail.first).filter(|row| *row < tail.count as u64)
                .ok_or_else(|| io::Error::other("Output anchor is outside captured text"))? as u16;
            let mut text = output_selection::terminal_row_text(&tail.screen, tail.start + row);
            text.join_next &= row + 1 < tail.count;
            Ok(text)
        }
    }
}
