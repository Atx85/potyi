"python3" - <<'PYTHON'
import hashlib, json, os, platform, subprocess
from pathlib import Path
files = sorted(set([*Path("src").rglob("*.rs"), *Path("vendor/vt100/src").rglob("*.rs"), Path("Cargo.toml"), Path("Cargo.lock"), Path("tools/qa/terminal-backend/Cargo.toml"), Path("tools/qa/terminal-backend/Cargo.lock")]))
digest = hashlib.sha256()
for path in files:
    digest.update(path.as_posix().encode())
    digest.update(b"\0")
    digest.update(path.read_bytes())
def command(args):
    return subprocess.check_output(args, text=True).strip()
report = {"schema_version": 1, "platform": os.environ["NATIVE_PLATFORM"], "target": os.environ["BUILD_TARGET"], "os": platform.platform(), "machine": platform.machine(), "rustc": command(["rustc", "+stable", "-vV"]), "commit": command(["git", "rev-parse", "HEAD"]), "source_sha256": digest.hexdigest(), "profile": "debug", "sdl_driver": "dummy", "shell": os.environ["SHELL"], "helper": os.environ.get("POTYI_TERM_TEST_CLIENT"), "limitations": ["No resource comparison or desktop GPU presentation measurement.", "A failed acceptance step remains a failed job; provenance is not a passing result."]}
Path("terminal-native-provenance.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
PYTHON
