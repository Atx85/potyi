# Matched terminal resource comparison

Use one final release executable containing both unchanged `:term` and `:term-new`. Run each route in a fresh process with the same fixtures, pane size, font, shell, environment, SDL driver, machine and native architecture. Record executable/source SHA256, Rust toolchain, OS build, architecture, commit/dirty state and the 12 legacy source identities. Keep ARM-native results separate from x86_64 under Rosetta. Compile-only results cannot substitute for native execution.

Build and correctness testing finish before sampling. One discarded warm-up, then at least three alternating A/B pairs. No other builds, benchmarks or scripted UI work may run during samples. Use a temporary fixture directory, LSP disabled, one pane and a fixed 800x600 window. The screenshot/probe fixture must exit after each run; do not use the user's interactive preview for a controlled claim.

Workloads:

1. Idle with listing visible, then idle after output and after returning to the editor. Measure 20-30 seconds per state after a short settling interval.
2. First visible output and total completion for a tiny command, pipeline and 220-line Unicode command. Verify status and exact output before recording latency.
3. 10,000-entry native listing: time first visible rows, completion and scroll/resize. Use the same Git scope, filename distribution and warm filesystem cache. Include nested paths, spaces and Unicode, plus a small Git repository with status decorations.
4. Sustained output beyond the 8 MiB retained-history cap, then stop, wait, scroll and copy. Repeat with three output volumes. Memory and permanent file size must plateau after eviction; compare those measurements separately from short-command latency.
5. Repeated commands and open/close/toggle cycles. Assert all owned children are reaped and temporary transcript/command files close. Revisit saved Git/diff views repeatedly without rerunning their producers once Stage 3 exists.
6. Copy a large selected range and a logical long word/line navigation. Measure input-to-result latency and whether ordinary UI input remains responsive while the cancellable worker scans. Check Clear/exit cancellation and clipboard atomic failure; no partial payload is accepted.

Record raw sample timestamps, app PID plus descendant identities, cumulative CPU seconds, sampled resident memory and on-disk transcript sizes. Label CPU as percent of one core over the actual interval. Idle `ps` cumulative-time sampling is usable but quantized: zero means below its resolution. Active-command CPU must include exited children through process/wait accounting, or be explicitly labelled a live-process-only observation; polling only surviving PIDs loses short-lived helper work. RSS samples are observations, not an allocation bound or a guaranteed peak. Native desktop idle and headless SDL frame timing are different experiments and must be labelled separately.

Report medians and ranges, plus new-minus-old deltas and child/process overhead. Give retained-history correctness and source-enforced caps alongside observed values. Do not declare timing thresholds passed unless a threshold was set before the run. Low memory/CPU claims need both plateau evidence and absence of continuous idle wakes. Windows pipes intentionally retain the legacy stdin-null/fresh-environment limits, so Unix interactive persistence is a separate capability test and is not included in the shared old/new workload comparison.

Existing `tools/benchmarks/run.py` provides release provenance and repeated legacy probes, but its editor-only idle sampler does not open either terminal and samples only the app process at two endpoints. Extend a private matched fixture/probe or add a dedicated paired mode; the existing numbers alone cannot establish terminal parity.
