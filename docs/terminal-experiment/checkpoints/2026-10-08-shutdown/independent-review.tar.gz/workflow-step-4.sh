cargo +stable test --locked --target "$BUILD_TARGET" \
  --manifest-path tools/qa/terminal-backend/Cargo.toml \
  --lib -- --test-threads=1
