cargo +stable build --locked --target "$BUILD_TARGET" \
  --manifest-path tools/qa/terminal-backend/Cargo.toml
"python3" - <<'PYTHON'
import os
from pathlib import Path
suffix = ".exe" if os.name == "nt" else ""
helper = (Path("tools/qa/terminal-backend/target") / os.environ["BUILD_TARGET"] / "debug" / ("potyi-terminal-backend-check" + suffix)).resolve()
if not helper.is_file():
    raise SystemExit("Native helper was not built: " + str(helper))
with open(os.environ["GITHUB_ENV"], "a", encoding="utf-8") as output:
    output.write("POTYI_TERM_TEST_CLIENT=" + str(helper) + "\n")
PYTHON
