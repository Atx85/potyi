cargo +stable test --locked --target "$BUILD_TARGET" \
  experimental_terminal -- --include-ignored --test-threads=1
