// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Opt-in embedded terminal, independent of the original command panel.
pub(crate) mod bridge;
pub(crate) mod browser;
mod prompt;
mod lifecycle;
#[cfg(test)]
mod command_tests;
#[cfg(test)]
mod comparison;
mod history;
mod transcript;
mod output_selection;
mod output_source;
mod input;
pub(crate) mod links;
pub(crate) mod painting;
pub(crate) mod pane;
mod session;
#[cfg(test)]
mod window;
pub(crate) use session::Wake;
pub(crate) fn run(command: Option<String>) -> Result<(), String> {
    crate::app::run_experimental(command)
}
