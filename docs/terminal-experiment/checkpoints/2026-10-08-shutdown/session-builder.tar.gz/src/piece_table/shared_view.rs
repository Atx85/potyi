// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Pane-local cursors over shared, file-backed text storage. The UI serializes
//! edits and reconciles the piece layouts before another view can edit.
use super::*;
use std::{collections::VecDeque, sync::Weak};

/// A replacement in pre-edit coordinates. Zero-length removals are insertions.
#[derive(Clone, Copy, Debug)]
pub(super) struct PositionChange {
    pub start: usize,
    pub removed: usize,
    pub inserted: usize,
}

impl PositionChange {
    fn map(self, position: usize) -> usize {
        if position <= self.start {
            position // Keep a cursor at an insertion boundary before the insertion.
        } else if position >= self.start + self.removed {
            position - self.removed + self.inserted
        } else {
            self.start + self.inserted
        }
    }
}

pub(super) fn inverse_changes(changes: &[PositionChange]) -> Arc<[PositionChange]> {
    let (mut old_end, mut new_end) = (0, 0);
    changes.iter().map(|change| {
        let start = new_end + (change.start - old_end);
        old_end = change.start + change.removed;
        new_end = start + change.inserted;
        PositionChange { start, removed: change.inserted, inserted: change.removed }
    }).collect()
}

#[derive(Clone)]
pub(super) enum PositionChanges {
    Single(PositionChange),
    Multiple(Arc<[PositionChange]>),
}

impl From<[PositionChange; 1]> for PositionChanges {
    fn from(changes: [PositionChange; 1]) -> Self { Self::Single(changes[0]) }
}

impl PositionChanges {
    pub fn inverse(&self) -> Self {
        match self {
            Self::Single(change) => Self::Single(PositionChange {
                start: change.start, removed: change.inserted, inserted: change.removed,
            }),
            Self::Multiple(changes) => Self::Multiple(inverse_changes(changes)),
        }
    }

    fn map(&self, mut position: usize) -> usize {
        match self {
            Self::Single(change) => change.map(position),
            Self::Multiple(changes) => {
                // Batch ranges use pre-edit coordinates. Apply right to left
                // so earlier ranges do not shift the remaining positions.
                for change in changes.iter().rev() { position = change.map(position); }
                position
            }
        }
    }
}

struct RevisionChanges {
    before: u64,
    after: u64,
    changes: PositionChanges,
}

#[derive(Default)]
struct HistoryState {
    views: Vec<Weak<AtomicU64>>,
    changes: VecDeque<RevisionChanges>,
}

/// Keep edit maps only until every live view has caught up. A single view
/// retains no synchronization history, and dropped views cannot pin it.
pub(super) struct ViewHistory {
    state: Arc<Mutex<HistoryState>>,
    revision: Arc<AtomicU64>,
}

impl ViewHistory {
    pub fn new(revision: u64) -> Self {
        let revision = Arc::new(AtomicU64::new(revision));
        let state = HistoryState {
            views: vec![Arc::downgrade(&revision)],
            ..Default::default()
        };
        Self { state: Arc::new(Mutex::new(state)), revision }
    }

    fn duplicate(&self, revision: u64) -> Self {
        let revision = Arc::new(AtomicU64::new(revision));
        self.state.lock().unwrap().views.push(Arc::downgrade(&revision));
        Self { state: self.state.clone(), revision }
    }

    pub fn record(&self, before: u64, after: u64, changes: PositionChanges) {
        self.revision.store(after, Ordering::Relaxed);
        // Ordinary single-pane typing needs neither an allocation nor a lock.
        if Arc::strong_count(&self.state) == 1 { return; }
        let mut state = self.state.lock().unwrap();
        let mut oldest = after;
        state.views.retain(|view| {
            if let Some(view) = view.upgrade() {
                oldest = oldest.min(view.load(Ordering::Relaxed));
                true
            } else {
                false
            }
        });
        if oldest < after {
            state.changes.push_back(RevisionChanges { before, after, changes });
        }
        while state.changes.front().is_some_and(|change| change.after <= oldest) {
            state.changes.pop_front();
        }
    }

    fn changes_since(&self, mut revision: u64, target: u64) -> io::Result<Vec<PositionChanges>> {
        let state = self.state.lock().unwrap();
        let mut changes = Vec::new();
        for change in &state.changes {
            if change.before == revision {
                changes.push(change.changes.clone());
                revision = change.after;
                if revision == target { return Ok(changes); }
            }
        }
        Err(io::Error::other("Shared view edit history is incomplete"))
    }
}

impl Drop for ViewHistory {
    fn drop(&mut self) {
        let mut state = self.state.lock().unwrap();
        let mut oldest = u64::MAX;
        state.views.retain(|view| {
            if let Some(view) = view.upgrade() {
                if Arc::ptr_eq(&view, &self.revision) { return false; }
                oldest = oldest.min(view.load(Ordering::Relaxed));
                true
            } else {
                false
            }
        });
        while state.changes.front().is_some_and(|change| change.after <= oldest) {
            state.changes.pop_front();
        }
    }
}

impl PieceTable {
    pub(crate) fn shares_storage_with(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.add, &other.add)
    }

    pub(crate) fn duplicate_view(&self) -> Self {
        Self {
            revision: self.revision,
            view_history: self.view_history.duplicate(self.revision),
            line_views: Default::default(),
            original: self.original.clone(),
            original_length: self.original_length,
            add: self.add.clone(),
            pieces: self.pieces.clone(),
            length: self.length,
            line_cache: self.line_cache.clone(),
            all_lines_cached: self.all_lines_cached,
            cursor: self.cursor.clone(),
            secondary_cursors: self.secondary_cursors.clone(),
            recovery: self.recovery.clone(),
        }
    }

    pub(crate) fn refresh_view_from(&mut self, source: &Self) -> io::Result<()> {
        if self.revision == source.revision {
            return Ok(());
        }
        let changes = source.view_history.changes_since(self.revision, source.revision)?;
        let map = |position: usize| {
            let mut position = position;
            for batch in &changes {
                position = batch.map(position);
            }
            position
        };
        let mut cursors = Vec::with_capacity(1 + self.secondary_cursors.len());
        cursors.push(self.cursor.clone());
        cursors.extend(self.secondary_cursors.iter().cloned());
        let mut updated = source.duplicate_view();
        for cursor in &mut cursors {
            cursor.position = map(cursor.position).min(updated.len());
            cursor.anchor = map(cursor.anchor).min(updated.len());
            (cursor.line, cursor.column) = updated.line_column_at(cursor.position)?;
            (cursor.anchor_line, cursor.anchor_column) = updated.line_column_at(cursor.anchor)?;
            cursor.desired_column = None;
        }
        updated.cursor = cursors.remove(0);
        updated.secondary_cursors = cursors;
        *self = updated;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn view_history_is_released_after_sync_or_dropping_a_stale_view() {
        let mut a = PieceTable::empty().unwrap();
        a.insert(0, "text").unwrap();
        assert!(a.view_history.state.lock().unwrap().changes.is_empty());
        let mut b = a.duplicate_view();
        a.insert(0, "first ").unwrap();
        assert_eq!(a.view_history.state.lock().unwrap().changes.len(), 1);
        b.refresh_view_from(&a).unwrap();
        assert!(a.view_history.state.lock().unwrap().changes.is_empty());
        a.insert(0, "second ").unwrap();
        drop(b);
        assert!(a.view_history.state.lock().unwrap().changes.is_empty());
        for _ in 0..100 { a.insert(0, "x").unwrap(); }
        assert!(a.view_history.state.lock().unwrap().changes.is_empty());
        assert_eq!(a.view_history.state.lock().unwrap().views.len(), 1);
    }

    #[test]
    fn several_views_keep_edits_until_the_oldest_view_catches_up() {
        let mut a = PieceTable::empty().unwrap();
        a.insert(0, "aaa bbb ccc").unwrap();
        let mut b = a.duplicate_view();
        let mut c = a.duplicate_view();
        b.move_cursor(5).unwrap();
        c.move_cursor(5).unwrap();
        a.insert(0, "X").unwrap();
        b.refresh_view_from(&a).unwrap();
        a.insert(a.len(), "Y").unwrap();
        c.refresh_view_from(&a).unwrap();
        b.refresh_view_from(&a).unwrap();
        assert_eq!(b.cursor.position, 6);
        assert_eq!(c.cursor.position, 6);
        assert!(a.view_history.state.lock().unwrap().changes.is_empty());
    }
}
