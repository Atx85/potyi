// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
use super::*;
use super::super::transcript::Transcript;

struct Fixture { directory: PathBuf, store: SharedTranscript, provenance: Provenance }
impl Fixture {
    fn new(name: &str) -> Self {
        let directory = std::env::temp_dir().join(format!("potyi-diagnostic-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&directory);
        std::fs::create_dir_all(&directory).unwrap();
        let store = Transcript::shared().unwrap();
        let provenance = {
            let mut transcript = store.lock().unwrap();
            let source = transcript.next_source();
            transcript.append_header(&directory, source, "compiler").unwrap();
            Provenance { epoch: transcript.epoch(), source, cwd: directory.clone(), relative_safe: true }
        };
        Self { directory, store, provenance }
    }
    fn file(&self, name: &str) -> PathBuf { let path = self.directory.join(name); std::fs::write(&path, "test").unwrap(); path }
    fn row(&self, text: &str, wrapped: bool) -> Anchor {
        self.store.lock().unwrap().append_terminal(&self.directory, self.provenance.source, 256, wrapped, text.as_bytes()).unwrap()
    }
    fn finish(&self, cwd: &Path, safe: bool) {
        self.store.lock().unwrap().append_result_with_provenance(cwd, self.provenance.source, 0, "Exit 0", safe).unwrap();
    }
    fn lookup(&self, mut anchor: Anchor, byte: usize) -> io::Result<Option<FileLink>> {
        anchor.utf8_byte_offset = byte;
        resolve(anchor, &self.store, &mut DiskSource::new(self.store.clone()), &self.provenance, &AtomicBool::new(false))
    }
}
impl Drop for Fixture { fn drop(&mut self) { let _ = std::fs::remove_dir_all(&self.directory); } }

#[test]
fn quoted_and_spaced_unicode_diagnostics_keep_numeric_suffix_and_click_range() {
    let f = Fixture::new("quoted");
    let path = f.file("é notes.rs");
    let a = f.row("error: \"é notes.rs\":12:3: failed", false);
    let b = f.row("é notes.rs:18:2: failed", false);
    let c = f.row("warning: 'é notes.rs:21:4' failed", false);
    let d = f.row("é notes.rs(9,5): error", false);
    f.finish(&f.directory, true);
    for (anchor, byte, line, column) in [(a, 8, 12, 3), (b, 4, 18, 2), (c, 12, 21, 4), (d, 4, 9, 5)] {
        let link = f.lookup(anchor, byte).unwrap().unwrap_or_else(|| panic!("no link at record {} byte {byte}", anchor.record_id));
        assert_eq!(link.path, path);
        assert_eq!(link.line, Some(line));
        assert_eq!(link.column, Some(column));
    }
    assert!(f.lookup(a, 0).unwrap().is_none(), "error prefix is outside the filename");
    assert!(f.lookup(a, 27).unwrap().is_none(), "message text is outside the filename");
    assert!(f.lookup(a, "error: \"é notes.rs\":12:3: failed".len()).unwrap().is_none(), "padding must never activate a link");
    let e = f.row("é notes.rs:12:3abc", false);
    f.finish(&f.directory, true);
    assert!(f.lookup(e, 4).unwrap().is_none(), "numbers embedded in text are not a diagnostic location");
}

#[test]
fn physical_soft_wrap_and_visual_byte_anchors_resolve_as_one_line() {
    let f = Fixture::new("wrap");
    let path = f.file("long file é.rs");
    let a = f.row("error: \"long ", true);
    let b = f.row("file é.rs\":32", true);
    let c = f.row(":7: failed", false);
    f.finish(&f.directory, true);
    for (anchor, byte) in [(a, 9), (b, 2), (c, 1)] {
        let link = f.lookup(anchor, byte).unwrap().unwrap();
        assert_eq!(link.path, path);
        assert_eq!((link.line, link.column), (Some(32), Some(7)));
    }
}

#[cfg(unix)]
#[test]
fn existing_literal_colon_filename_takes_precedence_over_location_parsing() {
    let f = Fixture::new("colon");
    let path = f.file("literal:12:3");
    f.file("literal");
    let a = f.row("literal:12:3", false);
    f.finish(&f.directory, true);
    let link = f.lookup(a, 2).unwrap().unwrap();
    assert_eq!(link.path, path);
    assert_eq!((link.line, link.column), (None, None));
}

#[test]
fn relative_diagnostics_require_completed_matching_origin_and_safety_flag() {
    let f = Fixture::new("provenance");
    f.file("file.rs");
    let a = f.row("file.rs:2:4", false);
    assert!(f.lookup(a, 2).unwrap().is_none());
    f.finish(&f.directory, false);
    assert!(f.lookup(a, 2).unwrap().is_none());
    let g = Fixture::new("cwd");
    g.file("file.rs");
    let b = g.row("file.rs:2:4", false);
    g.finish(&f.directory, true);
    assert!(g.lookup(b, 2).unwrap().is_none());
    let h = Fixture::new("safe");
    h.file("file.rs");
    let c = h.row("file.rs:2:4", false);
    h.finish(&h.directory, true);
    assert!(h.lookup(c, 2).unwrap().is_some());
    let mut provenance = h.provenance.clone();
    provenance.relative_safe = false;
    assert!(resolve(Anchor { utf8_byte_offset: 2, ..c }, &h.store, &mut DiskSource::new(h.store.clone()), &provenance, &AtomicBool::new(false)).unwrap().is_none());
}

#[test]
fn absolute_live_diagnostics_work_but_source_boundaries_never_join() {
    let f = Fixture::new("absolute");
    let path = f.file("absolute.rs");
    let text = format!("{}:8:2", path.display());
    let a = f.row(&text, false);
    let link = f.lookup(a, 2).unwrap().unwrap();
    assert_eq!(link.path, path);
    assert_eq!((link.line, link.column), (Some(8), Some(2)));
    f.file("combined.rs");
    let b = f.row("combined", true);
    let other = f.store.lock().unwrap().next_source();
    f.store.lock().unwrap().append_terminal(&f.directory, other, 256, false, b".rs:3:1").unwrap();
    f.finish(&f.directory, true);
    assert!(f.lookup(b, 2).unwrap().is_none());
}

#[test]
fn cancellation_clear_stale_unicode_offset_and_hard_newlines_are_safe() {
    let f = Fixture::new("cancel");
    f.file("é.rs");
    let a = f.row("é.rs:1:2", false);
    f.finish(&f.directory, true);
    assert!(f.lookup(a, 1).unwrap().is_none(), "cannot split UTF-8");
    assert!(resolve(a, &f.store, &mut DiskSource::new(f.store.clone()), &f.provenance, &AtomicBool::new(true)).is_err());
    f.store.lock().unwrap().clear().unwrap();
    assert!(f.lookup(a, 0).unwrap().is_none());
    let g = Fixture::new("hardline");
    g.file("file.rs");
    let b = g.row("file", false);
    g.row(".rs:1:2", false);
    g.finish(&g.directory, true);
    assert!(g.lookup(b, 1).unwrap().is_none());
}

#[test]
fn logical_line_size_and_row_limits_reject_partial_filename_fragments() {
    struct Huge { bounds: Bounds, reads: usize }
    impl TextSource for Huge {
        fn bounds(&self) -> Bounds { self.bounds }
        fn text(&mut self, _: u64) -> io::Result<RecordText> {
            self.reads += 1;
            Ok(RecordText { text: "x".repeat(512), join_next: true })
        }
    }
    let f = Fixture::new("bounded");
    let mut source = Huge { bounds: Bounds { epoch: f.provenance.epoch, first: 1000, end: 2000 }, reads: 0 };
    let click = Anchor { epoch: source.bounds.epoch, record_id: 1500, utf8_byte_offset: 1 };
    assert!(resolve(click, &f.store, &mut source, &f.provenance, &AtomicBool::new(false)).unwrap().is_none());
    assert!(source.reads <= MAX_LINE_ROWS + 1);
    assert!(source.reads <= MAX_LINE_BYTES / 512 + 1);
}

#[test]
fn job_returns_one_result_and_has_no_permanent_index() {
    let f = Fixture::new("job");
    let path = f.file("job.rs");
    let a = f.row("job.rs:4:2", false);
    f.finish(&f.directory, true);
    let mut job = Job::start(a, f.store.clone(), None, f.provenance.clone(), Arc::new(|| {}));
    let start = std::time::Instant::now();
    let result = loop {
        if let Some(result) = job.poll() { break result.unwrap().unwrap(); }
        assert!(start.elapsed() < std::time::Duration::from_secs(5));
        std::thread::sleep(std::time::Duration::from_millis(5));
    };
    assert_eq!(result.path, path);
    assert!(!job.pending());
    assert!(job.poll().is_none());
}
