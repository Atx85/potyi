// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
use super::{
    bridge::Bridge,
    browser::{BrowseAction, Browser, Kind, Row},
    input,
    links::{self, FileLink},
    painting::{self, GlyphCache, Point, Selection},
    prompt::Prompt,
    session::{Session, Wake},
};
use sdl3::{
    event::Event,
    keyboard::Keycode,
    mouse::MouseButton,
    rect::Rect,
    render::{Canvas, TextureCreator},
    ttf::Font,
    video::{Window, WindowContext},
};
use std::{
    collections::VecDeque,
    io,
    path::{Path, PathBuf},
};

#[derive(Debug)]
pub(crate) struct Ready;
pub(crate) enum Action {
    Handled,
    Editor,
    Open(FileLink),
    CommandBar,
    ClosePane,
}
pub(crate) struct Pane {
    session: Session,
    bridge: Bridge,
    browser: Browser,
    prompt: Prompt,
    browsing: bool,
    browse_offset: usize,
    browse_follow: bool,
    visible_rows: Vec<Row>,
    visible_widths: Vec<i32>,
    queued: VecDeque<FileLink>,
    last_command: Option<String>,
    output_directory: PathBuf,
    relative_links_safe: bool,
    selection: Selection,
    press: Option<(Point, bool)>,
    wheel: f32,
    area: Rect,
    cell: (i32, i32),
    pending_command: Option<String>,
    pub(crate) pane: usize,
    pub(crate) visible: bool,
}
impl Pane {
    pub(crate) fn new(
        directory: &Path,
        rows: u16,
        cols: u16,
        wake: Wake,
        pane: usize,
    ) -> io::Result<Self> {
        let bridge = Bridge::new(wake.clone())?;
        #[allow(unused_mut)]
        let mut environment = bridge.environment()?;
        #[cfg(test)]
        {
            let client = std::env::var_os("POTYI_TERM_TEST_CLIENT")
                .map(PathBuf::from)
                .or_else(|| {
                    std::env::current_exe()
                        .ok()?
                        .parent()?
                        .parent()
                        .map(|p| p.join(format!("potyi{}", std::env::consts::EXE_SUFFIX)))
                });
            if let Some(client) = client.filter(|p| p.is_file()) {
                environment[0].1 = client.to_string_lossy().into_owned();
            }
        }
        let browser = Browser::new(directory, wake.clone())?;
        let session = Session::open_with_environment(directory, rows, cols, wake, &environment)?;
        let output_directory = browser.directory().to_path_buf();
        Ok(Self {
            session,
            bridge,
            browser,
            prompt: Prompt::default(),
            browsing: true,
            browse_offset: 0,
            browse_follow: true,
            visible_rows: Vec::new(),
            visible_widths: Vec::new(),
            queued: VecDeque::new(),
            last_command: None,
            output_directory,
            relative_links_safe: true,
            selection: Selection::default(),
            press: None,
            wheel: 0.0,
            area: Rect::new(0, 0, 1, 1),
            cell: (1, 1),
            pending_command: None,
            pane,
            visible: true,
        })
    }
    pub(crate) fn closed(&self) -> bool {
        self.session.closed
    }
    pub(crate) fn dragging(&self) -> bool {
        self.selection.dragging
    }
    #[cfg(test)]
    pub(crate) fn contents(&self) -> String {
        self.session.screen().contents()
    }
    #[cfg(test)]
    pub(crate) fn directory(&self) -> &Path {
        self.browser.directory()
    }
    #[cfg(test)]
    pub(crate) fn ready(&self) -> bool {
        self.session.ready()
    }
    #[cfg(test)]
    pub(crate) fn prompt_text(&self) -> &str {
        self.prompt.text()
    }
    #[cfg(test)]
    pub(crate) fn browser_rows(&mut self) -> Vec<Row> {
        self.visible_rows.clone()
    }
    pub(crate) fn pending(&self) -> bool {
        self.session.work_pending || self.browser.pending()
    }
    pub(crate) fn command_running(&self) -> bool {
        self.session.running()
    }
    pub(crate) fn running(&self) -> bool {
        self.session.running() || self.browser.working() || self.pending_command.is_some()
    }
    pub(crate) fn prompt_view(&self, columns: usize) -> (String, usize) {
        if self.session.running() {
            return (
                "Running · keyboard input goes to the program".into(),
                usize::MAX,
            );
        }
        let columns = columns.clamp(1, 256);
        let before: Vec<_> = self.prompt.text()[..self.prompt.cursor()]
            .chars()
            .rev()
            .take(columns.saturating_sub(3))
            .collect();
        let mut text = String::from("> ");
        text.extend(before.into_iter().rev());
        let cursor = text.chars().count();
        text.extend(
            self.prompt.text()[self.prompt.cursor()..]
                .chars()
                .take(columns.saturating_sub(cursor)),
        );
        (text.replace(['\n', '\t'], " "), cursor)
    }
    pub(crate) fn poll(&mut self) -> bool {
        let mut changed = self.session.poll() | self.browser.poll();
        if self.browser.take_failure() {
            self.pending_command = None;
        }
        while let Ok(request) = self.bridge.requests.try_recv() {
            changed = true;
            if request.operation == "complete" {
                if let (Some(id), Some(status)) = (request.command_id, request.exit_status) {
                    self.session.command_finished(id, status, request.directory);
                }
                continue;
            }
            if request.operation == "cwd" {
                if request.directory != self.output_directory {
                    self.relative_links_safe = false;
                }
                // The native directory changes only after the managed command
                // completes. A helper never injects cd into a running child's stdin.
                continue;
            }
            let exact = if request.path == "~"
                || request.path.starts_with("~/")
                || request.path.starts_with("~\\")
            {
                std::env::var_os("HOME")
                    .or_else(|| std::env::var_os("USERPROFILE"))
                    .map(PathBuf::from)
                    .unwrap_or(request.directory.clone())
                    .join(request.path.get(2..).unwrap_or(""))
            } else {
                request.directory.join(&request.path)
            };
            let (value, line, column) = if exact.exists() {
                (&*request.path, None, None)
            } else {
                crate::parse_location(&request.path)
                    .map(|(p, l, c)| (p, Some(l), c))
                    .unwrap_or((&request.path, None, None))
            };
            if value.is_empty() {
                self.set_status("Usage: edit/view PATH[:LINE[:COLUMN]]".into());
                continue;
            }
            let path = if value == "~" || value.starts_with("~/") || value.starts_with("~\\") {
                std::env::var_os("HOME")
                    .or_else(|| std::env::var_os("USERPROFILE"))
                    .map(PathBuf::from)
                    .unwrap_or(request.directory.clone())
                    .join(value.get(2..).unwrap_or(""))
            } else {
                request.directory.join(value)
            };
            if self.queued.len() < 32 {
                self.queued.push_back(FileLink {
                    path,
                    line,
                    column,
                    read_only: request.operation == "view",
                    other_pane: true,
                });
            }
        }
        if let Some(completion) = self.session.take_completion() {
            if completion.directory != self.output_directory {
                self.relative_links_safe = false;
            }
            if completion.directory.is_dir() && completion.directory != self.browser.directory() {
                if let Err(error) = self.browser.enter(&completion.directory) {
                    self.set_status(error.to_string());
                }
                self.prompt.reset_completion();
            }
            self.session.status = Some(format!(
                "Exit {} · {}",
                completion.status,
                completion.directory.display()
            ));
            changed = true;
        }
        if changed {
            self.selection.clear();
            self.press = None;
        }
        if self.session.ready()
            && !self.browser.running()
            && let Some(command) = self.pending_command.take()
        {
            if let Err(error) = self.send_command(&command) {
                self.set_status(error.to_string());
            }
            changed = true;
        }
        changed
    }
    pub(crate) fn request(&mut self) -> Option<FileLink> {
        self.queued.pop_front()
    }
    pub(crate) fn enter_directory(&mut self, directory: &Path) -> io::Result<()> {
        if self.session.running() {
            return Err(io::Error::other(
                "Stop the running command before changing directory",
            ));
        }
        self.pending_command = None;
        self.browser.enter(directory)?;
        self.browsing = true;
        self.browse_offset = 0;
        self.browse_follow = true;
        self.prompt.reset_completion();
        Ok(())
    }
    pub(crate) fn send_command(&mut self, command: &str) -> io::Result<()> {
        if command.len() > super::session::MAX_PASTE_BYTES {
            return Err(io::Error::other("Command exceeds 64 KiB"));
        }
        if self.session.running() {
            return Err(io::Error::other("A command is already running"));
        }
        if self.pending_command.is_some() {
            return Err(io::Error::other(
                "A command is already waiting for the terminal",
            ));
        }
        if self.browser.running() {
            self.pending_command = Some(command.into());
            return Ok(());
        }
        if command.trim() == "clear" {
            self.clear();
            self.last_command = Some(command.into());
            return Ok(());
        }
        let action = self.browser.execute(command)?;
        self.last_command = Some(command.into());
        self.prompt.reset_completion();
        match action {
            BrowseAction::NotHandled => {
                if !self.session.ready() {
                    self.pending_command = Some(command.into());
                    return Ok(());
                }
                self.browser.stop();
                if self.browser.directory() != self.output_directory {
                    self.relative_links_safe = false;
                }
                self.output_directory = self.browser.directory().to_path_buf();
                self.session
                    .start_command(command, self.browser.directory())?;
                self.browsing = false;
            }
            BrowseAction::Changed => {
                self.browsing = true;
                self.browse_offset = 0;
                self.browse_follow = true;
            }
            BrowseAction::Open {
                path,
                read_only,
                line,
                column,
            } => {
                if self.queued.len() < 32 {
                    self.queued.push_back(FileLink {
                        path,
                        read_only,
                        line,
                        column,
                        other_pane: false,
                    });
                }
            }
            BrowseAction::Editor => self.visible = false,
        }
        Ok(())
    }
    pub(crate) fn set_status(&mut self, status: String) {
        if self.browsing {
            self.browser.set_status(status);
        } else {
            self.session.status = Some(status);
        }
    }
    pub(crate) fn stop(&mut self) {
        let waiting = self.pending_command.take().is_some();
        if self.session.running() {
            if let Err(e) = self.session.send(vec![3]) {
                self.set_status(e.to_string());
            }
        } else if self.browser.working() {
            self.browser.stop();
        } else if !waiting && let Some(command) = self.last_command.clone() {
            if let Err(error) = self.send_command(&command) {
                self.set_status(error.to_string());
            }
        }
    }
    pub(crate) fn clear(&mut self) {
        self.pending_command = None;
        self.selection.clear();
        self.session.clear();
        self.output_directory = self.browser.directory().to_path_buf();
        self.relative_links_safe = true;
        if let Err(error) = self.browser.clear() {
            self.set_status(error.to_string());
        }
        self.browse_offset = 0;
        self.browse_follow = true;
    }
    pub(crate) fn draw<'a>(
        &mut self,
        canvas: &mut Canvas<Window>,
        creator: &'a TextureCreator<WindowContext>,
        font: &mut Font<'_>,
        cache: &mut GlyphCache<'a>,
        cell: (i32, i32),
        scale: f32,
        focused: bool,
        area: Rect,
    ) -> Result<(), String> {
        self.area = area;
        self.cell = cell;
        let rows = ((area.height() as i32 - painting::MARGIN * 2 - painting::FOOTER) / cell.1)
            .clamp(1, super::session::MAX_ROWS as i32) as u16;
        let cols = ((area.width() as i32 - painting::MARGIN * 2) / cell.0)
            .clamp(1, super::session::MAX_COLS as i32) as u16;
        if self.session.resize(rows, cols).map_err(|e| e.to_string())? {
            self.selection.clear();
        }
        if self.browsing {
            return self.draw_browser(canvas, creator, font, cache, scale, area);
        }
        if !self.session.ready() {
            canvas.set_draw_color(sdl3::pixels::Color::RGB(30, 30, 30));
            canvas.fill_rect(area).map_err(|e| e.to_string())?;
            return Ok(());
        }
        painting::draw_area(
            canvas,
            creator,
            font,
            cache,
            self.session.screen(),
            &self.selection,
            self.session
                .status
                .as_deref()
                .or(Some("Terminal · edit/view: open files · Ctrl+`: editor")),
            cell.0,
            cell.1,
            scale,
            focused,
            area,
        )
    }
    fn draw_browser<'a>(
        &mut self,
        canvas: &mut Canvas<Window>,
        creator: &'a TextureCreator<WindowContext>,
        font: &mut Font<'_>,
        cache: &mut GlyphCache<'a>,
        scale: f32,
        area: Rect,
    ) -> Result<(), String> {
        use sdl3::pixels::Color;
        canvas.set_viewport(area);
        canvas.set_draw_color(Color::RGB(30, 30, 30));
        canvas
            .fill_rect(Rect::new(0, 0, area.width(), area.height()))
            .map_err(|e| e.to_string())?;
        let count = ((area.height() as i32 - painting::FOOTER - 2 * painting::MARGIN) / self.cell.1)
            .clamp(1, 160) as usize;
        let end = self.browser.len().saturating_sub(count);
        self.browse_offset = if self.browse_follow {
            end
        } else {
            self.browse_offset.min(end)
        };
        self.visible_rows = self
            .browser
            .rows(self.browse_offset, count)
            .map_err(|e| e.to_string())?;
        let cols =
            ((area.width() as i32 - 2 * painting::MARGIN) / self.cell.0).clamp(1, 256) as usize;
        canvas.set_clip_rect(Rect::new(
            painting::MARGIN,
            painting::MARGIN,
            area.width().saturating_sub(16),
            area.height().saturating_sub(painting::FOOTER as u32 + 16),
        ));
        self.visible_widths.clear();
        for (index, row) in self.visible_rows.iter().enumerate() {
            let text: String = row.text.chars().take(cols).collect();
            let color = row.color.unwrap_or(row.kind.color());
            let width =
                (font.size_of(&text).map_err(|e| e.to_string())?.0 as f32 / scale).round() as i32;
            self.visible_widths.push(width);
            let y = painting::MARGIN + index as i32 * self.cell.1;
            cache.draw(
                canvas,
                creator,
                font,
                &text,
                Color::RGB(color.0, color.1, color.2),
                0,
                painting::MARGIN,
                y,
                scale,
            )?;
            if row.path.is_some() && matches!(row.kind, Kind::Text | Kind::Directory) {
                canvas.set_draw_color(Color::RGB(color.0, color.1, color.2));
                let width = width.min(area.width() as i32 - 16).max(1);
                canvas
                    .fill_rect(Rect::new(
                        painting::MARGIN,
                        y + self.cell.1 - 2,
                        width as u32,
                        1,
                    ))
                    .map_err(|e| e.to_string())?;
            }
        }
        canvas.set_clip_rect(None);
        let footer = area.height() as i32 - painting::FOOTER;
        canvas.set_draw_color(Color::RGB(45, 45, 45));
        canvas
            .fill_rect(Rect::new(
                0,
                footer.max(0),
                area.width(),
                painting::FOOTER as u32,
            ))
            .map_err(|e| e.to_string())?;
        canvas.set_clip_rect(Rect::new(
            0,
            footer.max(0),
            area.width(),
            painting::FOOTER as u32,
        ));
        let directory = self.browser.directory().display().to_string();
        let status = self.browser.status().unwrap_or(&directory);
        let status: String = status.chars().take(cols).collect();
        cache.draw(
            canvas,
            creator,
            font,
            &status,
            Color::RGB(175, 185, 175),
            0,
            painting::MARGIN,
            footer + 4,
            scale,
        )?;
        canvas.set_clip_rect(None);
        font.set_style(sdl3::ttf::FontStyle::NORMAL);
        canvas.set_viewport(None);
        Ok(())
    }
    fn browse_link(&self, x: f32, y: f32, other_pane: bool) -> Option<FileLink> {
        let x = x as i32 - self.area.x() - painting::MARGIN;
        let y = y as i32 - self.area.y() - painting::MARGIN;
        if x < 0
            || y < 0
            || y >= self.area.height() as i32 - painting::FOOTER - 2 * painting::MARGIN
        {
            return None;
        }
        let index = (y / self.cell.1) as usize;
        let row = self.visible_rows.get(index)?;
        if x >= *self.visible_widths.get(index)?
            || !matches!(row.kind, Kind::Text | Kind::Directory)
        {
            return None;
        }
        Some(FileLink {
            path: row.path.clone()?,
            line: None,
            column: None,
            read_only: false,
            other_pane,
        })
    }
    fn point(&self, x: f32, y: f32) -> Point {
        let (rows, cols) = self.session.screen().size();
        Point {
            row: ((y as i32 - self.area.y() - painting::MARGIN).max(0) / self.cell.1)
                .min(rows as i32 - 1) as u16,
            col: ((x as i32 - self.area.x() - painting::MARGIN).max(0) / self.cell.0)
                .min(cols as i32) as u16,
        }
    }
    fn link(&self, point: Point) -> Option<FileLink> {
        let screen = self.session.screen();
        let mut text = String::new();
        let mut column = 0;
        for col in 0..screen.size().1 {
            let cell = screen.cell(point.row, col)?;
            if cell.is_wide_continuation() {
                continue;
            }
            let contents = cell.contents();
            if col < point.col {
                column += if contents.is_empty() {
                    1
                } else {
                    contents.chars().count()
                };
            }
            text.push_str(if contents.is_empty() { " " } else { contents });
        }
        links::at(text.trim_end(), column, &self.output_directory).and_then(|(range, link)| {
            // The browser stores exact paths. Raw terminal rows lack per-command
            // provenance, so only absolute links remain safe after cwd changes.
            let value = text[range].trim_matches(['\'', '"', '(', ')', '[', ']', ',', ';']);
            ((self.relative_links_safe && !self.session.running())
                || Path::new(value).is_absolute())
            .then_some(link)
        })
    }
    fn scroll(&mut self, rows: isize) {
        if self.browsing {
            self.browse_follow = false;
            self.browse_offset = self.browse_offset.saturating_add_signed(-rows);
        } else {
            self.session.scroll(rows);
        }
    }
    pub(crate) fn event(
        &mut self,
        event: &Event,
        modifiers: sdl3::keyboard::Mod,
        clipboard: &sdl3::clipboard::ClipboardUtil,
    ) -> Option<Action> {
        let result: Result<(), String> = match event {
            Event::KeyDown {
                keycode: Some(key),
                keymod,
                ..
            } => {
                if *key == Keycode::Grave && input::control(*keymod) {
                    return Some(Action::Editor);
                }
                if *key == Keycode::P && input::control(*keymod) {
                    return Some(Action::CommandBar);
                }
                let copy = *key == Keycode::C
                    && (input::command(*keymod)
                        || (input::control(*keymod) && input::shift(*keymod)));
                let paste = *key == Keycode::V
                    && (input::command(*keymod)
                        || (input::control(*keymod) && input::shift(*keymod)));
                if copy {
                    let selected = if self.browsing {
                        self.visible_rows
                            .iter()
                            .map(|r| r.text.as_str())
                            .collect::<Vec<_>>()
                            .join("\n")
                    } else {
                        self.selection.text(self.session.screen())
                    };
                    let text = if selected.is_empty() {
                        self.session.screen().contents()
                    } else {
                        selected
                    };
                    clipboard
                        .set_clipboard_text(&text)
                        .map_err(|e| e.to_string())
                } else if paste {
                    clipboard
                        .clipboard_text()
                        .map_err(|e| e.to_string())
                        .and_then(|s| {
                            if self.session.running() {
                                self.session.paste(&s).map_err(|e| e.to_string())
                            } else {
                                self.prompt.insert(&s);
                                Ok(())
                            }
                        })
                } else if !self.session.running() {
                    match *key {
                        Keycode::Escape => return Some(Action::Editor),
                        Keycode::Return | Keycode::KpEnter => {
                            if let Some(command) = self.prompt.take_command() {
                                if command == ":exit" {
                                    return Some(Action::ClosePane);
                                }
                                if let Err(error) = self.send_command(&command) {
                                    self.prompt.insert(&command);
                                    self.set_status(error.to_string());
                                }
                            }
                        }
                        Keycode::Backspace => self.prompt.backspace(),
                        Keycode::Delete => self.prompt.delete(),
                        Keycode::Left => self.prompt.move_left(),
                        Keycode::Right => self.prompt.move_right(),
                        Keycode::Home => self.prompt.home(),
                        Keycode::End => self.prompt.end(),
                        Keycode::Up => self.prompt.history_previous(),
                        Keycode::Down => self.prompt.history_next(),
                        Keycode::Tab => {
                            let candidates: Vec<_> = self
                                .browser
                                .completion()
                                .iter()
                                .map(|c| (c.path.clone(), c.directory))
                                .collect();
                            if let Some(status) = self.prompt.complete(
                                input::shift(*keymod),
                                self.browser.directory(),
                                &candidates,
                            ) {
                                self.set_status(status);
                            }
                        }
                        Keycode::C if input::control(*keymod) => {
                            self.pending_command = None;
                            self.browser.stop();
                            self.prompt.clear();
                        }
                        Keycode::L if input::control(*keymod) => self.clear(),
                        Keycode::PageUp => self.scroll(10),
                        Keycode::PageDown => self.scroll(-10),
                        _ => {}
                    }
                    Ok(())
                } else if input::shift(*keymod)
                    && matches!(*key, Keycode::PageUp | Keycode::PageDown)
                {
                    self.session
                        .scroll(if *key == Keycode::PageUp { 10 } else { -10 });
                    self.selection.clear();
                    Ok(())
                } else if input::command(*keymod) {
                    Ok(())
                } else {
                    input::key_bytes(
                        *key,
                        *keymod,
                        self.session.live_screen().application_cursor(),
                    )
                    .map_or(Ok(()), |bytes| {
                        self.session.send(bytes).map_err(|e| e.to_string())
                    })
                }
            }
            Event::TextInput { text, .. } => {
                if (!input::control(modifiers) || input::alt_graph(modifiers))
                    && !input::command(modifiers)
                {
                    if !self.session.running() {
                        self.prompt.insert(text);
                        return Some(Action::Handled);
                    }
                    let bytes = if input::alt(modifiers) && !input::alt_graph(modifiers) {
                        [b"\x1b".as_slice(), text.as_bytes()].concat()
                    } else {
                        text.as_bytes().to_vec()
                    };
                    self.selection.clear();
                    self.session.send(bytes).map_err(|e| e.to_string())
                } else {
                    Ok(())
                }
            }
            Event::MouseWheel { y, .. } => {
                self.wheel += *y * 3.0;
                let rows = self.wheel.trunc() as isize;
                self.wheel -= rows as f32;
                self.scroll(rows);
                self.selection.clear();
                Ok(())
            }
            Event::MouseButtonDown {
                mouse_btn: MouseButton::Left,
                x,
                y,
                clicks,
                ..
            } => {
                if self.browsing {
                    if let Some(link) = self.browse_link(
                        *x,
                        *y,
                        input::command(modifiers) || input::control(modifiers),
                    ) {
                        return Some(Action::Open(link));
                    }
                    return Some(Action::Handled);
                }
                let point = self.point(*x, *y);
                self.press = Some((
                    point,
                    input::command(modifiers) || input::control(modifiers),
                ));
                self.selection = Selection {
                    anchor: Some(point),
                    end: Some(point),
                    dragging: true,
                };
                if *clicks >= 2 {
                    self.selection.anchor = Some(Point {
                        row: point.row,
                        col: 0,
                    });
                    self.selection.end = Some(Point {
                        row: point.row,
                        col: self.session.screen().size().1,
                    });
                }
                Ok(())
            }
            Event::MouseMotion { x, y, .. } if self.selection.dragging => {
                self.selection.end = Some(self.point(*x, *y));
                Ok(())
            }
            Event::MouseButtonUp {
                mouse_btn: MouseButton::Left,
                x,
                y,
                ..
            } => {
                self.selection.dragging = false;
                if let Some((start, other)) = self.press.take()
                    && start == self.point(*x, *y)
                    && self.selection.anchor == self.selection.end
                    && let Some(mut link) = self.link(start)
                {
                    link.other_pane = other;
                    return Some(Action::Open(link));
                }
                Ok(())
            }
            Event::Window {
                win_event: sdl3::event::WindowEvent::FocusLost,
                ..
            } => {
                self.selection.dragging = false;
                self.press = None;
                return None;
            }
            _ => return None,
        };
        if let Err(error) = result {
            self.set_status(error);
        }
        Some(Action::Handled)
    }
}
