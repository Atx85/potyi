// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Click-scoped diagnostics. Retained text stays on disk; file probes and
//! command provenance checks run off the UI thread and are cancellable.
use super::{
    links::FileLink,
    output_selection::{self, Bounds, RecordText, TextSource},
    output_source::FrozenSource,
    session::Wake,
    transcript::{Anchor, Record, RecordData, SharedTranscript},
};
use std::{
    io,
    ops::Range,
    path::{Path, PathBuf},
    sync::{Arc, OnceLock, atomic::{AtomicBool, Ordering}, mpsc::{self, Receiver}},
};

const MAX_LINE_BYTES: usize = 64 * 1024;
const MAX_LINE_ROWS: usize = 256;
const MAX_CANDIDATES: usize = 64;
const MAX_SOURCE_ROWS: usize = 65_536;

#[derive(Clone, Debug)]
pub(super) struct Provenance {
    pub(super) epoch: u64,
    pub(super) source: u64,
    pub(super) cwd: PathBuf,
    /// False if an authenticated helper revealed another cwd. Final cwd
    /// equality cannot undo an observed intermediate directory change.
    pub(super) relative_safe: bool,
}

pub(super) struct Job {
    receiver: Receiver<io::Result<Option<FileLink>>>,
    cancelled: Arc<AtomicBool>,
    pending: bool,
}
impl Job {
    pub(super) fn start(click: Anchor, store: SharedTranscript, frozen: Option<FrozenSource>, provenance: Provenance, wake: Wake) -> Self {
        let (sender, receiver) = mpsc::sync_channel(1);
        let cancelled = Arc::new(AtomicBool::new(false));
        let cancellation = cancelled.clone();
        std::thread::spawn(move || {
            let result = if let Some(mut source) = frozen {
                resolve(click, &store, &mut source, &provenance, &cancellation)
            } else {
                let mut source = DiskSource::new(store.clone());
                resolve(click, &store, &mut source, &provenance, &cancellation)
            };
            if !cancellation.load(Ordering::Acquire) && sender.send(result).is_ok() { wake(); }
        });
        Self { receiver, cancelled, pending: true }
    }
    pub(super) fn pending(&self) -> bool { self.pending }
    pub(super) fn poll(&mut self) -> Option<io::Result<Option<FileLink>>> {
        match self.receiver.try_recv() {
            Ok(result) => { self.pending = false; Some(result) }
            Err(mpsc::TryRecvError::Disconnected) if self.pending => {
                self.pending = false;
                Some(Err(io::Error::other("Diagnostic lookup cancelled")))
            }
            _ => None,
        }
    }
}
impl Drop for Job { fn drop(&mut self) { self.cancelled.store(true, Ordering::Release); } }

struct DiskSource { store: SharedTranscript, bounds: Bounds }
impl DiskSource {
    fn new(store: SharedTranscript) -> Self {
        let bounds = {
            let transcript = store.lock().unwrap();
            Bounds { epoch: transcript.epoch(), first: transcript.base_id(), end: transcript.base_id() + transcript.len() as u64 }
        };
        Self { store, bounds }
    }
}
impl TextSource for DiskSource {
    fn bounds(&self) -> Bounds { self.bounds }
    fn text(&mut self, id: u64) -> io::Result<RecordText> {
        let mut store = self.store.lock().unwrap();
        validate_store(&store, self.bounds)?;
        let record = store.read_id(id)?;
        let join = if id + 1 < self.bounds.end { output_selection::joins_next(&record, &store.read_id(id + 1)?) } else { false };
        drop(store);
        let mut text = output_selection::record_text(&record)?;
        text.join_next &= join;
        Ok(text)
    }
}

fn check_cancel(cancelled: &AtomicBool) -> io::Result<()> {
    if cancelled.load(Ordering::Acquire) { Err(io::Error::other("Diagnostic lookup cancelled")) } else { Ok(()) }
}
fn validate_store(store: &super::transcript::Transcript, bounds: Bounds) -> io::Result<()> {
    if store.epoch() != bounds.epoch || store.base_id() > bounds.first {
        Err(io::Error::other("History changed during diagnostic lookup"))
    } else { Ok(()) }
}
fn metadata(store: &SharedTranscript, bounds: Bounds, id: u64, cancelled: &AtomicBool) -> io::Result<Option<Record>> {
    check_cancel(cancelled)?;
    let mut store = store.lock().unwrap();
    validate_store(&store, bounds)?;
    if id >= store.base_id() + store.len() as u64 { return Ok(None); }
    store.read_id(id).map(Some)
}
fn terminal_origin(record: &Record, provenance: &Provenance) -> bool {
    record.epoch == provenance.epoch && record.source == provenance.source && matches!(record.data, RecordData::Terminal { .. })
}

fn resolve(click: Anchor, store: &SharedTranscript, source: &mut impl TextSource, provenance: &Provenance, cancelled: &AtomicBool) -> io::Result<Option<FileLink>> {
    check_cancel(cancelled)?;
    let bounds = source.bounds();
    if click.epoch != bounds.epoch || click.epoch != provenance.epoch || click.record_id < bounds.first || click.record_id >= bounds.end || provenance.source == 0 { return Ok(None); }
    let saved_click = metadata(store, bounds, click.record_id, cancelled)?;
    if saved_click.as_ref().is_some_and(|record| !terminal_origin(record, provenance) || record.cwd != provenance.cwd) { return Ok(None); }
    let Some((line, byte)) = logical_line(click, store, source, provenance, cancelled)? else { return Ok(None); };
    let ranges = candidates(&line, byte);
    let mut relative = None;
    let mut probes = 0;
    for range in ranges {
        check_cancel(cancelled)?;
        if !range.contains(&byte) { continue; }
        for (path, location) in parse_candidate(&line[range]) {
            let path = Path::new(&path);
            let absolute = path.is_absolute();
            if !absolute {
                let allowed = if let Some(allowed) = relative { allowed } else {
                    let allowed = saved_click.is_some() && completed_origin(store, bounds, click.record_id, provenance, cancelled)?;
                    relative = Some(allowed);
                    allowed
                };
                if !allowed { continue; }
            }
            let path = if absolute { path.to_path_buf() } else { provenance.cwd.join(path) };
            if probes == MAX_CANDIDATES { return Ok(None); }
            probes += 1;
            if path.is_file() {
                check_cancel(cancelled)?;
                // A stale click must not publish after a concurrent Clear or
                // ring eviction, even if the filesystem probe succeeded.
                validate_store(&store.lock().unwrap(), bounds)?;
                return Ok(Some(FileLink { path, line: location.map(|v| v.0), column: location.and_then(|v| v.1), read_only: false, other_pane: false }));
            }
        }
    }
    Ok(None)
}

fn logical_line(click: Anchor, store: &SharedTranscript, source: &mut impl TextSource, provenance: &Provenance, cancelled: &AtomicBool) -> io::Result<Option<(String, usize)>> {
    let bounds = source.bounds();
    let row = source.text(click.record_id)?;
    if click.utf8_byte_offset >= row.text.len() || !row.text.is_char_boundary(click.utf8_byte_offset) { return Ok(None); }
    let mut bytes = row.text.len();
    if bytes > MAX_LINE_BYTES { return Ok(None); }
    let mut rows = vec![(click.record_id, row)];
    let mut first = click.record_id;
    while first > bounds.first {
        check_cancel(cancelled)?;
        let id = first - 1;
        if metadata(store, bounds, id, cancelled)?.as_ref().is_some_and(|record| !terminal_origin(record, provenance)) { break; }
        let previous = source.text(id)?;
        if !previous.join_next { break; }
        bytes += previous.text.len();
        if rows.len() == MAX_LINE_ROWS || bytes > MAX_LINE_BYTES { return Ok(None); }
        rows.push((id, previous));
        first = id;
    }
    rows.reverse();
    let mut next = click.record_id + 1;
    while rows.last().unwrap().1.join_next && next < bounds.end {
        check_cancel(cancelled)?;
        if metadata(store, bounds, next, cancelled)?.as_ref().is_some_and(|record| !terminal_origin(record, provenance)) { break; }
        let row = source.text(next)?;
        bytes += row.text.len();
        if rows.len() == MAX_LINE_ROWS || bytes > MAX_LINE_BYTES { return Ok(None); }
        rows.push((next, row));
        next += 1;
    }
    let mut text = String::with_capacity(bytes);
    let mut byte = click.utf8_byte_offset;
    for (id, row) in rows {
        if id < click.record_id { byte += row.text.len(); }
        text.push_str(&row.text);
    }
    Ok(Some((text, byte)))
}

/// Origin/final equality is the same launch-directory heuristic as :term.
/// It cannot prove a program did not chdir internally and return. Explicit
/// helper cwd changes veto it, and unfinished/evicted sources never qualify.
fn completed_origin(store: &SharedTranscript, bounds: Bounds, click: u64, provenance: &Provenance, cancelled: &AtomicBool) -> io::Result<bool> {
    if !provenance.relative_safe { return Ok(false); }
    let mut first = click;
    let mut visited = 0;
    while first > bounds.first {
        let Some(record) = metadata(store, bounds, first - 1, cancelled)? else { return Ok(false); };
        visited += 1;
        if visited >= MAX_SOURCE_ROWS { return Ok(false); }
        if record.source != provenance.source { break; }
        if record.cwd != provenance.cwd || !matches!(record.data, RecordData::Terminal { .. } | RecordData::Header(_)) { return Ok(false); }
        first -= 1;
    }
    for id in click..bounds.end {
        let Some(record) = metadata(store, bounds, id, cancelled)? else { return Ok(false); };
        visited += 1;
        if visited > MAX_SOURCE_ROWS || record.source != provenance.source || record.cwd != provenance.cwd { return Ok(false); }
        match record.data {
            RecordData::Result { relative_safe, .. } => return Ok(relative_safe),
            RecordData::Terminal { .. } | RecordData::Header(_) => {},
            RecordData::Native(_) => return Ok(false),
        }
    }
    Ok(false)
}

fn add_range(ranges: &mut Vec<Range<usize>>, range: Range<usize>, click: usize) {
    if ranges.len() < MAX_CANDIDATES && range.contains(&click) && !ranges.contains(&range) { ranges.push(range); }
}
fn message_prefix(text: &str) -> bool {
    let prefix = text.split_whitespace().next().unwrap_or("").trim_end_matches(':').to_ascii_lowercase();
    matches!(prefix.as_str(), "error" | "warning" | "note" | "fatal" | "-->" | "at" | "file")
}
fn path_starts(text: &str, end: usize) -> Vec<usize> {
    let mut starts = vec![];
    let mut start = text.len() - text.trim_start().len();
    if start < end && !message_prefix(&text[start..end]) { starts.push(start); }
    for (index, character) in text[..end].char_indices() {
        if character.is_whitespace() { start = index + character.len_utf8(); }
        else if start == index && starts.last() != Some(&start) { starts.push(start); }
    }
    starts.retain(|start| !message_prefix(&text[*start..end]));
    if starts.len() > 8 { starts.drain(1..starts.len() - 7); }
    starts
}
fn candidates(text: &str, click: usize) -> Vec<Range<usize>> {
    let mut ranges = Vec::new();
    let start = text.len() - text.trim_start().len();
    let end = text.trim_end().len();
    if !message_prefix(&text[start..end]) { add_range(&mut ranges, start..end, click); }
    // Quote-delimited names can contain spaces, Unicode and colons. Include a
    // numeric suffix outside the closing quote without swallowing the message.
    let mut opening = None;
    for (index, character) in text.char_indices() {
        if !matches!(character, '\'' | '"') { continue; }
        match opening {
            Some((first, quote)) if quote == character => {
                let end = index + character.len_utf8();
                let suffix = location_regex().find(&text[end..]).filter(|m| m.start() == 0 && suffix_boundary(text, end + m.end()));
                if let Some(suffix) = suffix { add_range(&mut ranges, first..end + suffix.end(), click); }
                add_range(&mut ranges, first..end, click);
                opening = None;
            }
            None => opening = Some((index, character)),
            _ => {},
        }
    }
    for matched in location_regex().find_iter(text).take(MAX_CANDIDATES) {
        if !suffix_boundary(text, matched.end()) { continue; }
        for start in path_starts(text, matched.start()) { add_range(&mut ranges, start..matched.end(), click); }
    }
    for matched in parenthesis_regex().find_iter(text).take(MAX_CANDIDATES) {
        if !suffix_boundary(text, matched.end()) { continue; }
        for start in path_starts(text, matched.start()) { add_range(&mut ranges, start..matched.end(), click); }
    }
    let mut token = 0;
    for (index, character) in text.char_indices() {
        if character.is_whitespace() {
            add_range(&mut ranges, token..index, click);
            token = index + character.len_utf8();
        }
    }
    add_range(&mut ranges, token..text.len(), click);
    ranges
}
fn suffix_boundary(text: &str, end: usize) -> bool {
    text[end..].chars().next().is_none_or(|character| character.is_whitespace() || matches!(character, ':' | '\'' | '"' | ')' | ']' | ',' | ';'))
}
fn location_regex() -> &'static regex::Regex {
    static VALUE: OnceLock<regex::Regex> = OnceLock::new();
    VALUE.get_or_init(|| regex::Regex::new(r":[1-9][0-9]*(?::[1-9][0-9]*)?").unwrap())
}
fn parenthesis_regex() -> &'static regex::Regex {
    static VALUE: OnceLock<regex::Regex> = OnceLock::new();
    VALUE.get_or_init(|| regex::Regex::new(r"\([1-9][0-9]*(?:,[1-9][0-9]*)?\)").unwrap())
}
type Location = Option<(usize, Option<usize>)>;
fn clean_path(path: &str) -> &str {
    path.trim().trim_matches(['\'', '"', '[', ']', ',', ';'])
}
fn parse_candidate(value: &str) -> Vec<(String, Location)> {
    let value = value.trim().trim_matches([',', ';']);
    let value = if value.len() >= 2 && ((value.starts_with('\'') && value.ends_with('\'')) || (value.starts_with('"') && value.ends_with('"'))) { &value[1..value.len() - 1] } else { value };
    let mut result = vec![(clean_path(value).to_owned(), None)];
    if let Some((path, last)) = value.rsplit_once(':') {
        if let Ok(last) = last.parse::<usize>() && last > 0 {
            result.push((clean_path(path).to_owned(), Some((last, None))));
            if let Some((path, line)) = path.rsplit_once(':') {
                if let Ok(line) = line.parse::<usize>() && line > 0 {
                    result.push((clean_path(path).to_owned(), Some((line, Some(last)))));
                }
            }
        }
    }
    if let Some(open) = value.rfind('(') && value.ends_with(')') {
        let numbers = &value[open + 1..value.len() - 1];
        let (line, column) = numbers.split_once(',').map_or((numbers, None), |(line, col)| (line, Some(col)));
        if let Ok(line) = line.parse::<usize>() && line > 0 {
            let column = column.and_then(|column| column.parse::<usize>().ok()).filter(|column| *column > 0);
            result.push((clean_path(&value[..open]).to_owned(), Some((line, column))));
        }
    }
    result.retain(|(path, _)| !path.is_empty() && !path.contains('\0') && !path.contains("://"));
    result
}

#[cfg(test)]
#[path = "diagnostic_links_tests.rs"]
mod tests;
