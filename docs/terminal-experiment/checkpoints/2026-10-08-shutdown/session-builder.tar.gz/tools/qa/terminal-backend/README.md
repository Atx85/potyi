# SDL-free terminal checks

This harness compiles the production PTY, browser, disk history, prompt and helper
modules. Build its headless helper before running the managed-command tests:

```sh
cargo build --locked --manifest-path tools/qa/terminal-backend/Cargo.toml --example headless-client
POTYI_TERM_TEST_CLIENT="$PWD/tools/qa/terminal-backend/target/debug/examples/headless-client" \
  cargo test --locked --manifest-path tools/qa/terminal-backend/Cargo.toml -- --test-threads=1
```

On Windows use the `.exe` suffix and set `POTYI_TERM_TEST_CLIENT` to the absolute
helper path. When using `CARGO_TARGET_DIR` or an explicit target triple, adjust
the helper path accordingly. Git fixtures require Git installed and available
on PATH. Cross-target `cargo check --tests` validates compilation, not runtime.
The complete application workflow separately checks SDL routing and rendering.
