# Event handling refactor plan

Status: proposed; implementation has not started.

## Objective

Make event handling easier to change and review by centralizing repeated
follow-up work, separating mouse responsibilities, and narrowing handler
dependencies. Deliver the refactor in small stages that preserve existing
behavior.

## Current structure

- `src/app/mod.rs` owns initialization, event polling, terminal and LSP event
  handling, scheduled work, reconciliation, and rendering.
- `src/app/input/mod.rs` dispatches SDL input and window events, cancels pending
  interactions, and synchronizes shared pane views before and after dispatch.
- `src/app/input/keyboard.rs` defines the order in which keyboard handlers run.
  Each stage currently returns `Result<Option<EventFlow>, String>`.
- `src/app/input/mouse.rs` combines window controls, split resizing, terminal
  interactions, completion, command-bar execution, document selection, and
  scrolling.
- Keyboard command-bar, Emacs, and mouse handlers repeat parts of the work
  required after command execution: pane changes, renderer updates, cache
  invalidation, cursor visibility, and redraw requests.
- `src/app/input/tests.rs` provides synthetic SDL event tests through the
  production input dispatcher.

## Behavior to preserve

- Keep keyboard priority explicit: pane shortcuts, terminal toggle, terminal
  input, completion, Emacs handling, search/command shortcuts, command-bar
  input, history, conventional Escape, Vim, then conventional commands.
- Preserve paired key/text suppression, repeat handling, prefixes, cancellation,
  and undo grouping in every keybinding mode.
- Preserve mouse hit-test priority, coordinate-conversion checks, drag ownership,
  fractional scrolling, and autoscroll cancellation.
- Preserve pane focus and shared-document synchronization. Pane focus currently
  swaps active editor and Vim state; follow-up work must address the correct
  editor after a switch.
- Process custom terminal and LSP events before input coordinate conversion for
  those events, without reordering the event batch.
- Preserve bounded event processing, terminal frame scheduling, idle waits, and
  recovery timing.
- Keep live state borrowed without cloning documents or histories. Preserve
  existing error propagation and user-visible error reporting.

## Implementation stages

### 1. Establish the baseline

Run the regular tests and isolated headless SDL checks using the existing QA
workflow. Review coverage for keyboard priority, key/text suppression, undo
groups, pane focus, command execution, and mouse interactions.

Add focused regression coverage where upcoming extractions expose meaningful
gaps, particularly command outcomes reached through different input paths and
background events that change documents or focus.

**Acceptance:** existing checks pass, and behavior relied on by the first
extraction is covered. Record any pre-existing failures separately.

### 2. Centralize command outcome application

Start with `CommandOutcome` in `src/app/commands.rs`. Extract shared application
of quit, pane closure, split changes, focus changes, path updates, document
reloads, keybinding changes, and renderer invalidation.

Migrate keyboard command-bar execution and mouse command execution first, then
the applicable Emacs paths. Preserve the ordering of these operations. Make
caller-specific cursor and search visibility behavior explicit rather than
assuming the existing paths are identical.

Keep execution of the command separate from applying its follow-up work.

**Acceptance:** equivalent commands retain their behavior across input paths;
shared follow-up operations have one implementation, with deliberate
caller-specific behavior visible at each call site.

### 3. Split mouse handling by responsibility

Retain a small dispatcher whose order is easy to inspect. Extract focused
operations for window controls, split dragging, terminal input/output,
completion, command-bar interactions, document selection, and wheel scrolling.

Keep drag state, capture ownership, cancellation, and scheduled autoscroll
coherent. Reuse the command outcome application from stage 2.

**Acceptance:** the dispatcher clearly expresses mouse priority, and selection,
pane resizing, terminal links, wheel accumulation, and focus-loss cancellation
continue to pass their regression checks.

### 4. Clarify routing results and narrow dependencies

Replace the keyboard routing convention based on `Option<EventFlow>` with an
explicit result such as `Pass`, `Handled`, and `Quit`, retaining `Result` for
errors. Preserve the current sequential handler order.

Gradually introduce smaller borrowed contexts or direct parameters for focused
operations. Define them around actual dependencies, such as document editing,
pane navigation, or terminal interaction, rather than passing the full
`InputContext` everywhere.

Document the key/text suppression contract and keep mode-specific suppression
rules intact. Apply this work incrementally to avoid coupling it to a redesign
of pane ownership or controllers.

**Acceptance:** pass-through and consumption are explicit, handlers receive
only the state their responsibilities require, and key/text and repeat behavior
remain unchanged.

### 5. Extract background-event handling

Move terminal, LSP setup, and LSP result handling into focused application
functions or modules. Keep one clear dispatch boundary for custom events and
ordinary SDL input.

Leave the outer loop responsible for polling and waiting, dispatching events,
running scheduled work, reconciling state, and rendering. Preserve per-event
follow-up work and shared-pane synchronization at their current boundaries.

Retain the existing event-batch limit, terminal frame schedule, mouse deadlines,
and recovery prompt timing.

**Acceptance:** the main loop exposes its lifecycle clearly; background results
still update the correct documents and panes, and idle behavior and input
responsiveness remain consistent.

### 6. Complete verification and documentation

Run the regular suite and isolated headless SDL routing checks after each
meaningful stage. Add tests for behavior affected by each change rather than
tests that mirror the extracted implementation.

Finish with native checks for physical keyboard/text pairing, clipboard
interaction, dragging, window controls, and display scaling. Synthetic SDL
events establish routing behavior but do not establish native event delivery.

Update `docs/architecture.md` to describe the final routing order, handler
boundaries, command outcome application, and background-event lifecycle.

**Acceptance:** relevant automated checks pass, native results and any remaining
verification gaps are recorded, and architecture documentation matches the
implementation.

## Delivery order

Implement the stages as small, reviewable changes in the order above. Stage 2
is the first production-code change after establishing the baseline. Keep
behavior changes separate from structural changes so each stage can be assessed
and reverted independently.

## Existing verification commands

```sh
python3 tools/dev.py test
python3 tools/dev.py check
```

Use `py -3` instead of `python3` on Windows. The `check` workflow includes the
regular tests and isolated headless SDL checks; evidence defaults to
`target/qa/`.
