# Experimental embedded terminal — browsing milestone

`:term-new` opens a separate integration inside Pötyi's custom window and pane
layout. The preview lives on `feature/term-integration` in
`/private/tmp/potyi-term-integration`. The original `:term` implementation remains
unchanged; shared application source has not been replaced.

Use `:term-new [command]` through Ctrl+P, or launch `potyi --term-new [command]`.
Opening the pane again restores its live session. Ctrl+grave toggles back to the
same new pane after opening a document. Escape or **Editor** returns to the
document; closing the application ends its shell and foreground job.

## What this milestone adds

- Pötyi owns the command row: Unicode editing, cursor movement, history with
  draft restoration, bounded paste, Tab and Shift+Tab path cycling.
- Portable `ls`, `cd`, `pwd`, `touch`, `clear`, `help`, `exit` and `editor`.
  `cd` lists the new directory. Listings include dotfiles by default and `../`,
  distinguish text, binary, unreadable files and directories, and add Git status
  colours when Git is available. Windows drive changes are supported.
- Clickable, underlined text files and directories use exact absolute native
  paths stored with each row. Spaces, Unicode, quotes, escaped control characters
  and literal colon filenames do not depend on parsing displayed shell text.
  Ctrl/Cmd-click opens a file in the other pane.
- A standalone non-executable text filename opens directly in Pötyi without
  shadowing an installed command. `edit` and `view` support line/column locations
  and Pötyi's existing document reuse and unsaved-document protections.
- Directory clicks use the browser service. They cannot send `cd` into a running
  program's stdin. Failed or cancelled directory changes discard waiting commands.
  File drops use the editor's protected open route; folder drops use the new
  browser when this integration exists. Busy folder changes fail before changing
  pane layout or documents.
- External commands and shell expressions run in a persistent PTY. Completion
  comes from authenticated command IDs and exit status, rather than visual prompt
  guessing. While a program runs, typed input and control keys go to that program.
  Overlapping command launches are rejected. **Stop** interrupts a program or
  cancels listing; **Again** repeats the last command while idle.

The browser uses one entry per clipped row and filesystem order. Column packing,
alphabetical ordering and word-aware wrapping remain future work. Completion
uses the latest bounded listing, rather than recursively searching the disk.
For multi-scope `ls`, rows retain their exact paths but Git colours currently
cover the last successfully collected scope. Recursive listing depth is capped
at 64. These preview limits are explicit, not claims of complete `:term` parity.

## Shell and link boundaries

Managed commands use private script files and a persistent shell driver. A
checked shell-native directory change precedes each command. This keeps command
text out of bootstrap interpolation and preserves environment and cwd between
commands. Dispatch uses a random session nonce and a numbered file consumed before execution.
Leftover complete or partial stdin cannot replay a command. The driver restores
terminal input modes between commands, and its utilities work after PATH changes.
Syntax validation protects the driver from common unmatched-quote
errors. Personal shell startup files remain disabled. POSIX shells, bash, zsh
and fish have explicit drivers; Windows uses cmd/ConPTY and batch helpers.
Unsupported shell families fail clearly.

`edit` and `view` inside shell expressions use a bounded, authenticated loopback
helper. The helper runs before SDL initialization; Pötyi opens documents on its
UI thread. Literal existing filenames take precedence over location suffixes.
Standalone native opens use the current pane; shell helpers prefer the other
pane when split, preserving the terminal view.

Raw terminal output still has heuristic file/diagnostic links. Relative guesses
are disabled while a command runs and after command directory changes, until
Clear. This avoids opening an older row against the wrong directory. Absolute
raw links and structured browser/helper links remain available. Per-command raw
row provenance, wrapped raw links and fuller output navigation belong to the
next milestones.

## Resource design

Browsing rows and terminal scrollback each use a fixed 8 MiB temporary file:
7 MiB encoded data and a 1 MiB on-disk index, at most 65,536 retained records per
file. Each file uses 40 KiB of fixed write buffers and is removed on normal drop.
The browser reads only visible rows; the terminal retains its live grid and a
visible history grid. A crash can leave temporary files.

The browser queue has eight batches, normally at most 16 KiB/64 rows each; one
row is capped at 64 KiB. Completion is capped at 4,096 paths/256 KiB path bytes.
Git collection is on demand, cancellable, capped at 1 MiB output and 8,192 paths,
and has a two-second deadline. Command input is capped at 64 KiB; command history
at 100 entries/256 KiB. These small caches are bounded RAM, rather than a
transcript or directory-wide memory index.

The PTY output queue is 512 KiB plus one pending 16 KiB chunk; input writes use a
bounded worker queue. Parsing uses 1 KiB slices, a 128 KiB per-turn ceiling and a
2 ms budget checked between slices. The grid is capped at 160 rows/256 columns,
OSC control strings at 1 KiB, and terminal glyph textures at 8 MiB/512 entries.
Workers block while idle and coalesce wake events; there is no terminal idle
animation or recurring browser scan. The editor retains its one-second fallback
wait. Shells and arbitrary child programs have their own resource use.

These bounds support Pötyi's philosophy, but do not establish whole-application
CPU/RAM parity. Earlier independent parser/history probes stayed near 1.38 MiB
tracked heap while processing 64 MiB of output, and verified ring wraparound,
OSC bounds and control-count limits. Those probes excluded SDL and child
processes. Controlled whole-application comparison remains a separate milestone.

## Intentional limits and remaining parity work

This remains a limited embedded terminal. Mouse reporting, terminal graphics,
OSC clipboard/hyperlink operations, modern keyboard protocols, configurable
shell profiles and automatic font fallback are outside the supported scope.
The bundled font can show missing-glyph boxes. History preserves its original
width and clips when the pane narrows; output changes clear selection.

Next stages add saved Git log/diff views and Back navigation, richer transcript
keyboard/Vim selection and copy-all, wrapping/reflow and stronger raw link
provenance. Native browsing currently has scrolling and click activation, while
full selection parity remains unfinished. The original terminal has no claimed
transcript search or pointer-drag auto-scroll feature to reproduce.

## Validation and reproducibility

Build the application before running managed helper and SDL checks:

```sh
cargo build --locked
SDL_VIDEODRIVER=dummy cargo test --locked experimental_terminal -- --include-ignored --test-threads=1
```

The standalone [backend harness](../tools/qa/terminal-backend/README.md) avoids
SDL and includes a small headless helper for repeatable command lifecycle tests.
The dedicated workflow covers the project's Linux x64, Windows x64, Intel macOS
and Apple Silicon macOS targets. It is prepared, not published or dispatched.
Cross-target compilation is not native runtime validation. Windows ConPTY needs
Windows 10 1809 or newer. Native Windows, Apple Silicon and fish runtime checks
remain pending on this host.

The review patch is generated against the captured shared-project baseline,
excluding other models' ongoing changes. The original terminal, layout, text
cache and terminal keyboard handler are checked byte for byte against that
baseline. The shared checkout has continued to change, so integrating there may
require reconciliation; the isolated preview remains directly runnable.

## Local results on 8 October 2026

- Native Intel macOS: application build and 57 focused integration/backend checks
  passed. The SDL-free production harness passed 43 checks with its own helper.
  Managed command tests also passed with sh, bash and zsh.
- Independent Linux dash review: 51 checks plus two helper checks passed. Its
  offline image lacks Git, so the Git-only fixture was skipped there and covered
  by native macOS checks.
- Windows GNU and Apple Silicon: refreshed backend/test compilation passed.
  Native runtime validation remains pending; fish is unavailable on this host.
- All 12 protected legacy terminal implementation/layout/input files remain
  byte-identical to the captured baseline.
- The broader editor-input suite passed 36/37 checks before the final additional
  exit regression. The existing synthetic TextInput enqueue test still fails on
  this SDL platform; the focused new routing checks pass.

An independent review caught and verified corrections for leftover stdin replay,
raw-mode recovery, failed/cancelled directory changes, helper literal-colon paths,
raw output path provenance, and hidden-pane redraw/cache release. The review
artifact remains separate from the shared source while other models work there.

The refreshed 54-file review patch applies cleanly to the captured baseline.
The current shared checkout needs reconciliation in `src/app/mod.rs` and
`src/app/navigation.rs`, where parallel work has advanced. The patch was not
applied there; the independent preview contains the working integration.

A read-only 10.13-second idle sample of the updated GUI preview observed
50.02 MiB RSS for Pötyi and 3.97 MiB for zsh, with only 8 KiB growth and no
measurable CPU-counter increase at the sampler's precision. This is an observed
idle sample, not a controlled comparison with the original terminal. Summed RSS
can count shared pages twice and does not include GPU memory.
