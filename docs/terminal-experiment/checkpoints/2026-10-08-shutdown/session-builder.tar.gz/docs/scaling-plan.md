# Pötyi scaling plan

Updated: 8 October 2026.

Improve sustained editing of large files and long sessions while preserving
file-backed text storage, lazy opening, predictable memory use, and quiet idle
behaviour. Deliver the stages below separately and compare each with the same
baseline workloads. This document proposes future scaling work; the three
correctness fixes and their regression tests are already implemented.

## Completed fixes and regression coverage

Eight regular regression tests were added:

| Area | Added tests | Source |
| --- | --- | --- |
| Save permissions | `save_preserves_executable_and_private_permissions`; `save_as_overwrite_uses_destination_permissions_and_new_files_stay_exclusive` | [Save tests](../src/piece_table/save_tests.rs) |
| Symbolic links | `save_follows_relative_symlink_chains_and_preserves_target_permissions`; `save_does_not_replace_dangling_links_or_overwrite_links_for_new_files` | [Save tests](../src/piece_table/save_tests.rs) |
| Shared cursors and selections | `shared_views_preserve_middle_selection_across_compound_edits_and_grouped_undo`; `shared_views_preserve_middle_selection_across_replace_all_and_snapshot_undo` | [Editor tests](../src/editor/shared_view_tests.rs) |
| Synchronization history lifetime | `view_history_is_released_after_sync_or_dropping_a_stale_view`; `several_views_keep_edits_until_the_oldest_view_catches_up` | [Shared-view tests](../src/piece_table/shared_view.rs) |

The permission tests check that executable `755` and private `600` modes survive
saving. The link tests check relative link chains, repeated saves, preserved
links with updated target contents, dangling-link failures, and exclusive creation. The cursor tests
check Unicode selections through edits at both ends of a document, replace-all,
grouped undo, and snapshot undo/redo.

Shared views now map positions through actual edits. Pending maps are released
when all live views catch up or stale views close. Ordinary single-pane edits
do not allocate or lock a synchronization log. Snapshot maps are prepared in
both directions so undo/redo does not rebuild them.

### Recorded verification

The local macOS run passed **605 regular tests**, with **66 optional tests
ignored**. Two existing headless integration tests were also run individually
and passed:

- `app::input::tests::terminal_clicks_open_shared_views_and_edit_undo_save_from_either_pane`
- `app::input::tests::shared_views_keep_vim_insert_groups_separate_when_switching_panes`

The Unix permission and link tests have not been run on Linux, and native
Windows behaviour remains unverified. Headless checks do not establish native
keyboard, mouse, or clipboard delivery.

Run the regular suite from the repository root:

```sh
cargo test --locked --bin potyi -- --test-threads=1
```

Run the two headless checks in separate processes:

```sh
SDL_VIDEODRIVER=dummy cargo test --locked --bin potyi app::input::tests::terminal_clicks_open_shared_views_and_edit_undo_save_from_either_pane -- --ignored --exact --test-threads=1
SDL_VIDEODRIVER=dummy cargo test --locked --bin potyi app::input::tests::shared_views_keep_vim_insert_groups_separate_when_switching_panes -- --ignored --exact --test-threads=1
```

## Stage 1: Establish sustained-editing measurements

Extend the [existing benchmark suite](../tools/benchmarks/README.md). Its current
large-file opening probe and raw piece-table edits do not establish full editor
typing performance deep inside a document.

Measure these workloads using the production editing paths:

- Files of 1 MiB, 100 MiB, and 1 GB, with many short lines and separate long-line
  fixtures. Record sizes and line counts explicitly.
- Cursor movement followed by typing at the beginning, middle, and near the end.
- Repeated edits after warming the line index, with undo/redo included.
- One pane and two panes viewing the same document, with short and long histories.
- Edits spread across many locations to accumulate fragmented pieces.
- Recovery off and on, reported separately to distinguish indexing and copying
  costs from journal synchronization.

Record edit-handler and redraw times separately, median and tail latency,
process memory, bytes read, lines rescanned, piece count, and metadata copied.
Keep fixture creation and initial navigation outside repeated-typing timers;
report first navigation and first edit separately. Use bounded run durations
and report unfinished workloads instead of silently dropping them.

**Completion criteria:** retain raw samples, environment and source identity,
and a reproducible baseline. Performance targets should follow these results;
no sustained-editing baseline has been collected for this plan yet.

## Stage 2: Preserve valid line-index work

Primary code: [piece table](../src/piece_table.rs) and
[viewport checkpoints](../src/piece_table/line_view.rs).

Currently each mutation clears the entire line index. Start with the smallest
correct change: retain cached lines before the earliest affected line and
invalidate the affected line and following entries. Rebuild later information
only when navigation or rendering requests it.

Determine the affected line using the pre-edit index. Account for insertion at
line boundaries, newline deletion that joins lines, CRLF, and edits at EOF.
Compound operations should invalidate from their earliest changed location.
Snapshot restoration may initially retain conservative invalidation.

Reuse unread bytes from the scanning buffer across short-line discovery;
avoid repeatedly reading a large overlapping block for each short line.
Preserve unaffected viewport checkpoints where their coordinates remain valid.

**Completion criteria:** deterministic read-count checks show that repeated
typing deep in an indexed file no longer rescans its unchanged prefix. Unicode,
CRLF, newline edits, selection, navigation, and undo/redo tests must pass. The
same sustained-editing benchmarks must show the practical improvement.

## Stage 3: Share one document across panes

Primary code: [editor](../src/editor.rs),
[shared views](../src/piece_table/shared_view.rs), and
[application navigation](../src/app/navigation.rs).

Move document-wide state into one owner: piece layout, line index, backing
stores, revision, path, dirty/read-only state, recovery, and undo/redo history.
Each pane should reference that document and retain its own cursor, selection,
scroll position, and keyboard-mode state.

Keep UI document ownership on the application thread. Language-server and
formatter workers should continue receiving explicit snapshots or file-backed
inputs rather than live mutable UI state. Avoid adding document locks to every
UI access merely to share state between panes.

Reuse the edit-position maps introduced by the cursor fix. Remove full history,
piece-layout, and line-index copies from pane synchronization and switching.
Keep position maps only as long as a live view needs them.

**Completion criteria:** two views contain one document history and piece layout;
typing and switching panes do not clone them. Verify editing and undo from
either pane, Vim grouping, Save As, workspace refactoring, and closing one view
while the other remains editable. Memory and synchronization cost should stop
doubling with document metadata and history size.

## Stage 4: Bound line-index memory

After the prefix-preservation change is measured, replace unrestricted dense
line caching with a budgeted detailed cache and compact sparse checkpoints.
Evict detailed entries and compact checkpoints as density grows. Reconstruct
line and Unicode-column information near the requested position using bounded
read buffers.

Account separately for line metadata, checkpoint metadata, and cached text.
Do not introduce full-file background scanning. First navigation to an
unindexed distant region will still require scanning; measure and document
that cost rather than claiming every jump is constant-time.

**Completion criteria:** visiting more lines respects the chosen index-memory
budget. Cache eviction and reconstruction preserve exact line, character, and
visual-column results. Repeated navigation remains practical on the baseline
fixtures, without adding idle work.

## Stage 5: Address fragmented pieces if justified

Use Stage 1's fragmentation measurements to decide whether replacing the flat
piece vector is necessary. If piece lookup, splicing, and metadata copying
remain material costs after the earlier stages, introduce a balanced structure
with chunked leaves and subtree byte counts.

Keep text in the original file and append-only edit store. Share unchanged
structure across snapshots where practical. Track newline aggregates only for
indexed regions so creating the structure does not force eager file scanning.
Preserve efficient streaming traversal and bulk replacement.

**Completion criteria:** edits and position lookup scale with tree depth and
affected leaves instead of total piece count. Compare with the vector on both
small documents and heavily fragmented sessions; retain the vector if the
measured benefit does not justify the added complexity.

## Delivery order

Implement measurements, then line-index preservation, then shared document
ownership. Use the resulting evidence to set memory budgets and decide on the
piece structure. Each stage should be independently reviewable, pass the
relevant correctness and headless checks, and retain before/after evidence.
Native platform checks remain necessary for platform-sensitive file behaviour.
