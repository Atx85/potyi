// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! SDL-free harness for native PTY checks and cross-target compile checks.
#![allow(dead_code)]
#[path = "../../../../src/experimental_terminal/session.rs"]
mod session;

pub(crate) use session::Wake;
#[path = "../../../../src/experimental_terminal/bridge.rs"]
mod bridge;
#[path = "../../../../src/experimental_terminal/links.rs"]
mod links;

#[path = "../../../../src/experimental_terminal/history.rs"]
mod history;

#[path = "../../../../src/experimental_terminal/lifecycle.rs"]
mod lifecycle;
#[path = "../../../../src/experimental_terminal/prompt.rs"]
mod prompt;
#[path = "../../../../src/experimental_terminal/browser.rs"]
mod browser;
