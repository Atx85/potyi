// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! Bounded projection of the disk transcript. Sparse checkpoints are transient;
//! logical anchors and native paths remain in the one shared transcript file.
use super::{
    Wake,
    browser::{decode_native, native_packing},
    output_selection::{record_text, terminal_row_text},
    transcript::{Anchor, Record, RecordData, SharedTranscript},
};
use std::{
    io, mem,
    ops::Range,
    sync::Arc,
    time::{Duration, Instant},
};
use unicode_width::UnicodeWidthChar;
#[cfg(test)]
use unicode_width::UnicodeWidthStr;

const CHECKPOINTS: usize = 1024;
const MAX_VISIBLE_ROWS: usize = 160;
const MAX_VISIBLE_BYTES: usize = 256 * 1024;
const MAX_FRAGMENT_BYTES: usize = 64 * 1024;
const MAX_FRAGMENT_SEGMENTS: usize = 1024;

fn text_width(text: &str) -> usize {
    text.chars()
        .map(|character| character.width().unwrap_or(0))
        .sum()
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Metrics {
    pub(crate) columns: u16,
    pub(crate) tab_width: usize,
}
impl Default for Metrics {
    fn default() -> Self {
        Self {
            columns: 80,
            tab_width: 4,
        }
    }
}
impl Metrics {
    fn bounded(self) -> Self {
        Self {
            columns: self.columns.clamp(1, 256),
            tab_width: self.tab_width.clamp(1, 256),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct Style {
    pub(crate) fg: vt100::Color,
    pub(crate) bg: vt100::Color,
    pub(crate) bold: bool,
    pub(crate) italic: bool,
    pub(crate) dim: bool,
    pub(crate) inverse: bool,
    pub(crate) underline: bool,
}
impl Style {
    fn cell(cell: &vt100::Cell) -> Self {
        Self {
            fg: cell.fgcolor(),
            bg: cell.bgcolor(),
            bold: cell.bold(),
            italic: cell.italic(),
            dim: cell.dim(),
            inverse: cell.inverse(),
            underline: cell.underline(),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Segment {
    pub(crate) range: Range<usize>,
    pub(crate) start: Anchor,
    pub(crate) end: Anchor,
    pub(crate) column: u16,
    pub(crate) record_id: u64,
    pub(crate) color: Option<(u8, u8, u8)>,
    pub(crate) style: Style,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Fragment {
    pub(crate) start: Anchor,
    pub(crate) end: Anchor,
    pub(crate) text: String,
    pub(crate) segments: Vec<Segment>,
}
impl Fragment {
    fn bytes(&self) -> usize {
        mem::size_of::<Self>()
            + self.text.capacity()
            + self.segments.capacity() * mem::size_of::<Segment>()
    }
    fn trim(&mut self, length: usize, end: Anchor) {
        self.text.truncate(length);
        self.segments.retain(|segment| segment.range.start < length);
        if let Some(segment) = self.segments.last_mut() {
            if segment.range.end > length {
                let removed = segment.range.end - length;
                segment.range.end = length;
                segment.end.utf8_byte_offset = segment.end.utf8_byte_offset.saturating_sub(removed);
            }
        }
        self.end = end;
    }
    pub(crate) fn anchor_column(&self, wanted: u16) -> Anchor {
        let mut previous = self.start;
        for segment in &self.segments {
            if wanted < segment.column {
                return previous;
            }
            let text = &self.text[segment.range.clone()];
            let mut column = usize::from(segment.column);
            let synthetic_tab =
                segment.end.utf8_byte_offset - segment.start.utf8_byte_offset != text.len();
            if synthetic_tab {
                if usize::from(wanted) < column + text.len() {
                    return segment.start;
                }
            } else {
                for (offset, character) in text.char_indices() {
                    let width = character.width().unwrap_or(0);
                    if usize::from(wanted) < column + width {
                        return Anchor {
                            utf8_byte_offset: segment.start.utf8_byte_offset + offset,
                            ..segment.start
                        };
                    }
                    column += width;
                }
            }
            previous = segment.end;
        }
        self.end
    }
    pub(crate) fn anchor_visual_column(&self, anchor: Anchor) -> Option<u16> {
        for segment in &self.segments {
            if anchor.epoch != segment.start.epoch
                || anchor.record_id != segment.record_id
                || anchor.utf8_byte_offset < segment.start.utf8_byte_offset
                || anchor.utf8_byte_offset > segment.end.utf8_byte_offset
            {
                continue;
            }
            let text = &self.text[segment.range.clone()];
            let offset = anchor.utf8_byte_offset - segment.start.utf8_byte_offset;
            let width =
                if segment.end.utf8_byte_offset - segment.start.utf8_byte_offset != text.len() {
                    if anchor == segment.end { text.len() } else { 0 }
                } else {
                    if !text.is_char_boundary(offset) {
                        return None;
                    }
                    text[..offset]
                        .chars()
                        .map(|character| character.width().unwrap_or(0))
                        .sum()
                };
            return Some((usize::from(segment.column) + width).min(u16::MAX as usize) as u16);
        }
        (anchor == self.start).then_some(0)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Cursor {
    id: u64,
    byte: usize,
}
impl Cursor {
    fn anchor(self, epoch: u64) -> Anchor {
        Anchor {
            epoch,
            record_id: self.id,
            utf8_byte_offset: self.byte,
        }
    }
}
#[derive(Clone, Copy)]
struct Checkpoint {
    row: usize,
    cursor: Cursor,
}

struct StyledRange {
    range: Range<usize>,
    style: Style,
}
struct Loaded {
    id: u64,
    source: u64,
    text: String,
    terminal: bool,
    join_next: bool,
    packed: Option<u16>,
    color: Option<(u8, u8, u8)>,
    styles: Vec<StyledRange>,
}
impl Loaded {
    fn new(record: Record) -> io::Result<Self> {
        let plain = record_text(&record)?;
        let mut loaded = Self {
            id: record.id,
            source: record.source,
            text: plain.text,
            terminal: false,
            join_next: plain.join_next,
            packed: None,
            color: None,
            styles: Vec::new(),
        };
        match &record.data {
            RecordData::Native(bytes) => {
                loaded.packed = native_packing(bytes);
                loaded.color = decode_native(bytes)?.color;
            }
            RecordData::Terminal {
                cols, formatted, ..
            } => {
                loaded.terminal = true;
                let mut parser = vt100::Parser::new(1, (*cols).clamp(1, 256), 0);
                parser.process(formatted);
                let mut offset = 0;
                for column in 0..(*cols).clamp(1, 256) {
                    let Some(cell) = parser.screen().cell(0, column) else {
                        continue;
                    };
                    if cell.is_wide_continuation() {
                        continue;
                    }
                    let length = if cell.has_contents() {
                        cell.contents().len()
                    } else {
                        1
                    };
                    let end = (offset + length).min(loaded.text.len());
                    if end > offset {
                        let style = Style::cell(cell);
                        if let Some(previous) = loaded.styles.last_mut() {
                            if previous.style == style {
                                previous.range.end = end;
                            } else {
                                loaded.styles.push(StyledRange {
                                    range: offset..end,
                                    style,
                                });
                            }
                        } else {
                            loaded.styles.push(StyledRange {
                                range: offset..end,
                                style,
                            });
                        }
                    }
                    offset = end;
                    if offset == loaded.text.len() {
                        break;
                    }
                }
            }
            RecordData::Header(_) | RecordData::Result { .. } => {}
        }
        Ok(loaded)
    }
    fn style(&self, byte: usize) -> Style {
        self.styles
            .iter()
            .find(|range| range.range.contains(&byte))
            .map_or_else(
                || Style {
                    fg: self.color.map_or(vt100::Color::Default, |(r, g, b)| {
                        vt100::Color::Rgb(r, g, b)
                    }),
                    ..Style::default()
                },
                |range| range.style,
            )
    }
    fn live(screen: &vt100::Screen, row: u16, id: u64, source: u64) -> Self {
        let plain = terminal_row_text(screen, row);
        let mut loaded = Self {
            id,
            source,
            text: plain.text,
            terminal: true,
            join_next: plain.join_next,
            packed: None,
            color: None,
            styles: Vec::new(),
        };
        let mut offset = 0;
        for column in 0..screen.size().1 {
            let Some(cell) = screen.cell(row, column) else {
                continue;
            };
            if cell.is_wide_continuation() {
                continue;
            }
            let length = if cell.has_contents() {
                cell.contents().len()
            } else {
                1
            };
            let end = (offset + length).min(loaded.text.len());
            if end > offset {
                let style = Style::cell(cell);
                if let Some(previous) = loaded
                    .styles
                    .last_mut()
                    .filter(|previous| previous.style == style)
                {
                    previous.range.end = end;
                } else {
                    loaded.styles.push(StyledRange {
                        range: offset..end,
                        style,
                    });
                }
            }
            offset = end;
            if offset == loaded.text.len() {
                break;
            }
        }
        loaded
    }
}

struct Tail {
    screen: vt100::Screen,
    first: u64,
    start: u16,
    count: u16,
    source: u64,
}
impl Tail {
    fn end(&self) -> u64 {
        self.first + u64::from(self.count)
    }
}
struct Source<'a> {
    store: &'a SharedTranscript,
    disk_end: u64,
    tail: Option<&'a Tail>,
}
impl Source<'_> {
    fn read(&self, id: u64) -> io::Result<Loaded> {
        if id < self.disk_end {
            return Loaded::new(self.store.lock().unwrap().read_id(id)?);
        }
        let tail = self
            .tail
            .filter(|tail| id >= tail.first && id < tail.end())
            .ok_or_else(|| io::Error::other("Layout row is unavailable"))?;
        Ok(Loaded::live(
            &tail.screen,
            tail.start + (id - tail.first) as u16,
            id,
            tail.source,
        ))
    }
}

struct Budget {
    deadline: Instant,
    reads: usize,
}
impl Budget {
    fn new() -> Self {
        Self {
            deadline: Instant::now() + Duration::from_millis(2),
            reads: 16,
        }
    }
    fn exhausted(&self) -> bool {
        self.reads == 0 || Instant::now() >= self.deadline
    }
}

enum Mode {
    Text {
        last_break: Option<(Cursor, usize)>,
    },
    Packed {
        cell: usize,
        count: usize,
        entries: usize,
        source: u64,
    },
}
struct Building {
    start: Cursor,
    fragment: Fragment,
    width: usize,
    mode: Mode,
}
struct Flow {
    cursor: Cursor,
    loaded: Option<Loaded>,
    building: Option<Building>,
}
impl Flow {
    fn new(cursor: Cursor) -> Self {
        Self {
            cursor,
            loaded: None,
            building: None,
        }
    }
    fn load(&mut self, source: &Source<'_>, end: u64, budget: &mut Budget) -> io::Result<bool> {
        if self.cursor.id >= end {
            return Ok(false);
        }
        if self
            .loaded
            .as_ref()
            .is_some_and(|row| row.id == self.cursor.id)
        {
            return Ok(true);
        }
        if budget.exhausted() {
            return Ok(false);
        }
        budget.reads -= 1;
        self.loaded = Some(source.read(self.cursor.id)?);
        let row = self.loaded.as_ref().unwrap();
        if self.cursor.byte > row.text.len() || !row.text.is_char_boundary(self.cursor.byte) {
            return Err(io::Error::other("Layout anchor is not a UTF-8 boundary"));
        }
        Ok(true)
    }
    fn finished(&self, end: u64) -> bool {
        self.cursor.id >= end && self.building.is_none()
    }
    fn next(
        &mut self,
        source: &Source<'_>,
        end: u64,
        epoch: u64,
        metrics: Metrics,
        budget: &mut Budget,
    ) -> io::Result<Option<(Cursor, Fragment)>> {
        if self.building.is_none() {
            if !self.load(source, end, budget)? {
                return Ok(None);
            }
            let row = self.loaded.as_ref().unwrap();
            let packed = row
                .packed
                .filter(|cell| usize::from(*cell) <= usize::from(metrics.columns));
            let mode = if let Some(cell) = packed {
                let count = ((usize::from(metrics.columns) + 2) / usize::from(cell)).max(1);
                if count > 1 && text_width(&row.text) <= usize::from(metrics.columns) {
                    Mode::Packed {
                        cell: usize::from(cell),
                        count,
                        entries: 0,
                        source: row.source,
                    }
                } else {
                    Mode::Text { last_break: None }
                }
            } else {
                Mode::Text { last_break: None }
            };
            let anchor = self.cursor.anchor(epoch);
            self.building = Some(Building {
                start: self.cursor,
                fragment: Fragment {
                    start: anchor,
                    end: anchor,
                    text: String::new(),
                    segments: Vec::new(),
                },
                width: 0,
                mode,
            });
        }
        let mut build = self.building.take().unwrap();
        let mut characters = 0;
        loop {
            if !self.load(source, end, budget)? {
                if self.cursor.id >= end {
                    return Ok(Some((build.start, build.fragment)));
                }
                self.building = Some(build);
                return Ok(None);
            }
            let row = self.loaded.as_ref().unwrap();
            if let Mode::Packed {
                cell,
                count,
                entries,
                source,
            } = &mut build.mode
            {
                if row.source != *source || row.packed != Some(*cell as u16) {
                    return Ok(Some((build.start, build.fragment)));
                }
                let width = text_width(&row.text);
                let padding = if *entries == 0 {
                    0
                } else {
                    cell.saturating_sub(build.width % *cell).max(2)
                };
                if *entries > 0 && build.width + padding + width > usize::from(metrics.columns) {
                    return Ok(Some((build.start, build.fragment)));
                }
                if padding != 0 {
                    build
                        .fragment
                        .text
                        .extend(std::iter::repeat_n(' ', padding));
                    build.width += padding;
                }
                let anchor = Cursor {
                    id: row.id,
                    byte: 0,
                }
                .anchor(epoch);
                let end_anchor = Cursor {
                    id: row.id,
                    byte: row.text.len(),
                }
                .anchor(epoch);
                let start = build.fragment.text.len();
                build.fragment.text.push_str(&row.text);
                build.fragment.segments.push(Segment {
                    range: start..build.fragment.text.len(),
                    start: anchor,
                    end: end_anchor,
                    column: build.width as u16,
                    record_id: row.id,
                    color: row.color,
                    style: row.style(0),
                });
                build.fragment.end = end_anchor;
                build.width += width;
                *entries += 1;
                self.cursor = Cursor {
                    id: row.id + 1,
                    byte: 0,
                };
                self.loaded = None;
                if *entries == *count || budget.exhausted() {
                    if *entries == *count {
                        return Ok(Some((build.start, build.fragment)));
                    }
                    self.building = Some(build);
                    return Ok(None);
                }
                continue;
            }
            if self.cursor.byte >= row.text.len() {
                let old_source = row.source;
                let join = row.terminal && row.join_next;
                let previous = self.cursor;
                self.cursor = Cursor {
                    id: row.id + 1,
                    byte: 0,
                };
                self.loaded = None;
                if !join || self.cursor.id >= end {
                    return Ok(Some((build.start, build.fragment)));
                }
                // A saved soft wrap only joins another row from the same command.
                // The next load may yield; remember that provenance in the flow.
                if !self.load(source, end, budget)? {
                    self.cursor = previous;
                    self.building = Some(build);
                    return Ok(None);
                }
                let next = self.loaded.as_ref().unwrap();
                if !next.terminal || next.source != old_source {
                    return Ok(Some((build.start, build.fragment)));
                }
                continue;
            }
            let character = row.text[self.cursor.byte..].chars().next().unwrap();
            let anchor = self.cursor.anchor(epoch);
            if character == '\n' {
                self.cursor.byte += 1;
                build.fragment.end = anchor;
                return Ok(Some((build.start, build.fragment)));
            }
            let width = if character == '\t' {
                metrics.tab_width - build.width % metrics.tab_width
            } else {
                character.width().unwrap_or(0)
            };
            if build.width != 0 && build.width.saturating_add(width) > usize::from(metrics.columns)
            {
                if !character.is_whitespace() {
                    if let Mode::Text {
                        last_break: Some((cursor, length)),
                    } = &build.mode
                    {
                        if *length != 0 && *length < build.fragment.text.len() {
                            self.cursor = *cursor;
                            self.loaded = None;
                            build.fragment.trim(*length, cursor.anchor(epoch));
                        }
                    }
                    return Ok(Some((build.start, build.fragment)));
                }
                // Legacy wrapping keeps separators on the preceding visual row.
                // Still bound very long runs of whitespace rather than buffering
                // a transcript-sized logical line.
                if build.fragment.text.len() >= MAX_FRAGMENT_BYTES - 4 {
                    return Ok(Some((build.start, build.fragment)));
                }
            }
            let style = row.style(self.cursor.byte);
            let color = row.color;
            if build.fragment.text.len() + character.len_utf8().max(width) > MAX_FRAGMENT_BYTES {
                return Ok(Some((build.start, build.fragment)));
            }
            let start = build.fragment.text.len();
            if character == '\t' {
                build.fragment.text.extend(std::iter::repeat_n(' ', width));
            } else {
                build.fragment.text.push(character);
            }
            self.cursor.byte += character.len_utf8();
            let end_anchor = self.cursor.anchor(epoch);
            let tab = character == '\t';
            let previous = build.fragment.segments.last_mut();
            if let Some(previous) = previous.filter(|previous| {
                !tab && previous.end == anchor
                    && previous.style == style
                    && previous.color == color
                    && previous.range.end - previous.range.start
                        == previous.end.utf8_byte_offset - previous.start.utf8_byte_offset
            }) {
                previous.range.end = build.fragment.text.len();
                previous.end = end_anchor;
            } else {
                build.fragment.segments.push(Segment {
                    range: start..build.fragment.text.len(),
                    start: anchor,
                    end: end_anchor,
                    column: build.width.min(u16::MAX as usize) as u16,
                    record_id: anchor.record_id,
                    color,
                    style,
                });
            }
            build.fragment.end = end_anchor;
            build.width = build.width.saturating_add(width);
            if character.is_whitespace() {
                if let Mode::Text { last_break } = &mut build.mode {
                    *last_break = Some((self.cursor, build.fragment.text.len()));
                }
            }
            characters += 1;
            if build.fragment.text.len() >= MAX_FRAGMENT_BYTES
                || build.fragment.segments.len() >= MAX_FRAGMENT_SEGMENTS
                || (characters % 64 == 0 && budget.exhausted())
            {
                if build.fragment.text.len() >= MAX_FRAGMENT_BYTES
                    || build.fragment.segments.len() >= MAX_FRAGMENT_SEGMENTS
                {
                    return Ok(Some((build.start, build.fragment)));
                }
                self.building = Some(build);
                return Ok(None);
            }
        }
    }
}

struct Query {
    start: usize,
    count: usize,
    row: usize,
    flow: Flow,
    end: u64,
    tail: Option<Arc<Tail>>,
    fragments: Vec<Fragment>,
    bytes: usize,
    revision: u64,
    ready: bool,
}
struct Published {
    start: usize,
    revision: u64,
    rows: Arc<Vec<Fragment>>,
    tail: Option<Arc<Tail>>,
}

struct Locate {
    anchor: Anchor,
    row: usize,
    flow: Flow,
    end: u64,
    tail: Option<Arc<Tail>>,
    result: Option<usize>,
    ready: bool,
}

pub(crate) struct Layout {
    store: SharedTranscript,
    wake: Wake,
    metrics: Metrics,
    epoch: u64,
    base: u64,
    end: u64,
    disk_end: u64,
    tail: Option<Arc<Tail>>,
    pending_tail: Option<Option<Arc<Tail>>>,
    pending_end: bool,
    revision: u64,
    projection_revision: u64,
    rows: usize,
    complete: bool,
    flow: Flow,
    last_start: Option<Cursor>,
    checkpoints: Vec<Checkpoint>,
    stride: usize,
    query: Option<Query>,
    navigation: Option<Query>,
    locate: Option<Locate>,
    published: Option<Published>,
    published_rows: usize,
}
impl Layout {
    pub(crate) fn new(store: SharedTranscript, wake: Wake) -> io::Result<Self> {
        let (epoch, base, end, revision) = {
            let transcript = store.lock().unwrap();
            (
                transcript.epoch(),
                transcript.base_id(),
                transcript.base_id() + transcript.len() as u64,
                transcript.serial(),
            )
        };
        Ok(Self {
            store,
            wake,
            metrics: Metrics::default(),
            epoch,
            base,
            end,
            disk_end: end,
            tail: None,
            pending_tail: None,
            pending_end: false,
            revision,
            projection_revision: revision,
            rows: 0,
            complete: base == end,
            flow: Flow::new(Cursor { id: base, byte: 0 }),
            last_start: None,
            checkpoints: Vec::with_capacity(CHECKPOINTS),
            stride: 16,
            query: None,
            navigation: None,
            locate: None,
            published: None,
            published_rows: 0,
        })
    }
    pub(crate) fn configure(&mut self, metrics: Metrics) -> bool {
        let metrics = metrics.bounded();
        if self.metrics == metrics {
            return false;
        }
        self.metrics = metrics;
        if let Some(next) = self.pending_tail.take() {
            self.tail = next;
        }
        self.end = self
            .tail
            .as_ref()
            .map_or(self.disk_end, |tail| self.disk_end.max(tail.end()));
        self.pending_end = false;
        self.reset();
        (self.wake)();
        true
    }
    /// The live screen is the bounded mutable tail, never another disk history.
    /// A query retains an Arc to the snapshot it began with while new output
    /// arrives, so continuous output cannot discard its unfinished projection.
    pub(crate) fn set_tail(
        &mut self,
        screen: &vt100::Screen,
        start: u16,
        count: u16,
        source: u64,
    ) -> io::Result<bool> {
        self.sync();
        let next = if count == 0 {
            if self.tail.is_none() && self.pending_tail.as_ref().is_none_or(Option::is_none) {
                return Ok(false);
            }
            None
        } else {
            let (rows, columns) = screen.size();
            if rows > 160 || columns > 256 || start >= rows || count > rows - start {
                return Err(io::Error::other(
                    "Live terminal snapshot exceeds its bounded grid",
                ));
            }
            Some(Arc::new(Tail {
                screen: screen.normal_screen_clone(),
                first: self.disk_end,
                start,
                count,
                source,
            }))
        };
        // A captured pass always finishes. Updates replace one pending snapshot
        // rather than rewinding the same first16 rows indefinitely under output.
        self.pending_tail = Some(next);
        self.pending_end = true;
        if self.complete {
            self.refresh();
        }
        (self.wake)();
        Ok(true)
    }
    fn refresh(&mut self) {
        let previous_first = self.tail.as_ref().map(|tail| tail.first);
        let tail_changed = self.pending_tail.is_some();
        if let Some(next) = self.pending_tail.take() {
            self.tail = next;
        }
        self.end = self
            .tail
            .as_ref()
            .map_or(self.disk_end, |tail| self.disk_end.max(tail.end()));
        self.pending_end = false;
        if tail_changed {
            let first = previous_first
                .into_iter()
                .chain(self.tail.as_ref().map(|tail| tail.first))
                .min()
                .unwrap_or(self.disk_end);
            self.projection_revision = self.projection_revision.wrapping_add(1);
            self.rewind(first);
        } else if let Some(start) = self.last_start {
            self.rows = self.rows.saturating_sub(1);
            self.checkpoints
                .retain(|checkpoint| checkpoint.row < self.rows);
            self.flow = Flow::new(start);
            self.complete = false;
        } else {
            self.flow = Flow::new(Cursor {
                id: self.base,
                byte: 0,
            });
            self.complete = self.flow.finished(self.end);
        }
    }
    fn rewind(&mut self, id: u64) {
        let checkpoint = self
            .checkpoints
            .iter()
            .rev()
            .find(|point| point.cursor.id < id)
            .copied()
            .unwrap_or(Checkpoint {
                row: 0,
                cursor: Cursor {
                    id: self.base,
                    byte: 0,
                },
            });
        self.rows = checkpoint.row;
        self.checkpoints.retain(|point| point.row < checkpoint.row);
        self.flow = Flow::new(checkpoint.cursor);
        self.last_start = None;
        self.complete = self.flow.finished(self.end);
        // Prefix queries keep their captured end and bounded screen snapshot.
        // Their completed projection is published before a refresh is scheduled.
    }
    fn reset(&mut self) {
        self.rows = 0;
        self.complete = self.base == self.end;
        self.flow = Flow::new(Cursor {
            id: self.base,
            byte: 0,
        });
        self.last_start = None;
        self.checkpoints.clear();
        self.stride = 16;
        self.query = None;
        self.navigation = None;
        self.locate = None;
        self.published = None;
        self.published_rows = 0;
    }
    pub(crate) fn len(&self) -> usize {
        self.rows.max(self.published_rows)
    }
    pub(crate) fn complete(&self) -> bool {
        self.complete
    }
    pub(crate) fn pending(&self) -> bool {
        !self.complete
            || self.pending_end
            || self.query.as_ref().is_some_and(|query| !query.ready)
            || self.navigation.as_ref().is_some_and(|query| !query.ready)
            || self.locate.as_ref().is_some_and(|locate| !locate.ready)
    }
    fn sync(&mut self) -> bool {
        let (epoch, base, disk_end, revision) = {
            let transcript = self.store.lock().unwrap();
            (
                transcript.epoch(),
                transcript.base_id(),
                transcript.base_id() + transcript.len() as u64,
                transcript.serial(),
            )
        };
        let changed = revision != self.revision;
        if changed {
            self.projection_revision = self.projection_revision.wrapping_add(1);
        }
        self.revision = revision;
        self.disk_end = disk_end;
        if epoch != self.epoch || base != self.base {
            if epoch != self.epoch {
                self.tail = None;
                self.pending_tail = None;
            } else if let Some(next) = self.pending_tail.take() {
                self.tail = next;
            }
            self.epoch = epoch;
            self.base = base;
            self.end = self
                .tail
                .as_ref()
                .map_or(disk_end, |tail| disk_end.max(tail.end()));
            self.pending_end = false;
            self.reset();
        } else {
            let latest = self.pending_tail.as_ref().unwrap_or(&self.tail);
            let desired_end = latest
                .as_ref()
                .map_or(disk_end, |tail| disk_end.max(tail.end()));
            if desired_end != self.end || self.pending_tail.is_some() {
                self.pending_end = true;
            }
            if self.complete && self.pending_end {
                self.refresh();
            }
        }
        changed
    }
    fn checkpoint(points: &mut Vec<Checkpoint>, stride: &mut usize, row: usize, cursor: Cursor) {
        if row % *stride != 0 {
            return;
        }
        if points.len() == CHECKPOINTS {
            *stride = stride.saturating_mul(2);
            points.retain(|checkpoint| checkpoint.row % *stride == 0);
            if row % *stride != 0 {
                return;
            }
        }
        points.push(Checkpoint { row, cursor });
    }
    fn before_row(&self, row: usize) -> Checkpoint {
        self.checkpoints
            .iter()
            .rev()
            .find(|checkpoint| checkpoint.row <= row)
            .copied()
            .unwrap_or(Checkpoint {
                row: 0,
                cursor: Cursor {
                    id: self.base,
                    byte: 0,
                },
            })
    }
    fn before_anchor(&self, anchor: Anchor) -> Checkpoint {
        self.checkpoints
            .iter()
            .rev()
            .find(|checkpoint| checkpoint.cursor.anchor(self.epoch) <= anchor)
            .copied()
            .unwrap_or(Checkpoint {
                row: 0,
                cursor: Cursor {
                    id: self.base,
                    byte: 0,
                },
            })
    }
    /// Each call yields after at most16 record reads or roughly2ms. Color-only
    /// revisions repaint projections without discarding the shape checkpoints.
    pub(crate) fn poll(&mut self) -> io::Result<bool> {
        let mut changed = self.sync();
        let mut budget = Budget::new();
        let source = Source {
            store: &self.store,
            disk_end: self.disk_end,
            tail: self.tail.as_deref(),
        };
        for query in [self.navigation.as_mut(), self.query.as_mut()]
            .into_iter()
            .flatten()
        {
            let source = Source {
                store: &self.store,
                disk_end: self.disk_end,
                tail: query.tail.as_deref(),
            };
            while !query.ready && !budget.exhausted() {
                let Some((_, fragment)) =
                    query
                        .flow
                        .next(&source, query.end, self.epoch, self.metrics, &mut budget)?
                else {
                    if query.flow.finished(query.end) {
                        query.ready = true;
                    }
                    break;
                };
                if query.row >= query.start {
                    let size = fragment.bytes();
                    if query.bytes + size > MAX_VISIBLE_BYTES && !query.fragments.is_empty() {
                        query.ready = true;
                        break;
                    }
                    query.bytes += size;
                    query.fragments.push(fragment);
                    if query.fragments.len() == query.count {
                        query.ready = true;
                    }
                }
                query.row += 1;
                changed = true;
            }
        }
        if let Some(locate) = &mut self.locate {
            let source = Source {
                store: &self.store,
                disk_end: self.disk_end,
                tail: locate.tail.as_deref(),
            };
            while !locate.ready && !budget.exhausted() {
                let Some((_, fragment)) =
                    locate
                        .flow
                        .next(&source, locate.end, self.epoch, self.metrics, &mut budget)?
                else {
                    if locate.flow.finished(locate.end) {
                        locate.ready = true;
                    }
                    break;
                };
                let hard_end = locate.flow.cursor.id != fragment.end.record_id;
                if locate.anchor >= fragment.start
                    && (locate.anchor < fragment.end || (hard_end && locate.anchor == fragment.end))
                {
                    locate.result = Some(locate.row);
                    locate.ready = true;
                } else if locate.anchor < fragment.start {
                    locate.ready = true;
                }
                locate.row += 1;
                changed = true;
            }
        }
        while !self.complete && !budget.exhausted() {
            let Some((start, _)) =
                self.flow
                    .next(&source, self.end, self.epoch, self.metrics, &mut budget)?
            else {
                if self.flow.finished(self.end) {
                    self.complete = true;
                    self.published_rows = self.rows;
                }
                break;
            };
            Self::checkpoint(&mut self.checkpoints, &mut self.stride, self.rows, start);
            self.last_start = Some(start);
            self.rows += 1;
            changed = true;
        }
        if self.pending() {
            (self.wake)();
        }
        Ok(changed)
    }
    /// A distant viewport may return no rows while its bounded projection is
    /// prepared by poll(). Repeating the same request returns the ready cache.
    pub(crate) fn visible(&mut self, start: usize, count: usize) -> io::Result<Vec<Fragment>> {
        self.sync();
        let count = count.min(MAX_VISIBLE_ROWS);
        if count == 0 {
            self.query = None;
            self.published = None;
            return Ok(Vec::new());
        }
        let mut replace = self.query.is_none();
        if let Some(query) = &self.query {
            if !query.fragments.is_empty() {
                let changed = self.published.as_ref().is_none_or(|frame| {
                    frame.start != query.start
                        || frame.revision != query.revision
                        || frame.rows.len() != query.fragments.len()
                });
                if changed {
                    self.published = Some(Published {
                        start: query.start,
                        revision: query.revision,
                        rows: Arc::new(query.fragments.clone()),
                        tail: query.tail.clone(),
                    });
                }
            }
            // Finish the captured prefix even if following output moves the
            // requested start. Once ready, coalesce to the newest request.
            replace = query.ready
                && (query.start != start
                    || query.count != count
                    || query.revision != self.projection_revision);
        }
        if replace && !(self.complete && start >= self.rows) {
            let checkpoint = self.before_row(start);
            self.query = Some(Query {
                start,
                count,
                row: checkpoint.row,
                flow: Flow::new(checkpoint.cursor),
                end: self.end,
                tail: self.tail.clone(),
                fragments: Vec::new(),
                bytes: 0,
                revision: self.projection_revision,
                ready: false,
            });
            (self.wake)();
        }
        Ok(self
            .published
            .as_ref()
            .map_or_else(Vec::new, |frame| (*frame.rows).clone()))
    }
    /// Actual visual start for the returned cached frame while a newer target
    /// is being prepared. The frame's anchors remain authoritative.
    pub(crate) fn cached_start(&self) -> Option<usize> {
        self.published.as_ref().map(|frame| frame.start)
    }
    /// Selection can pin the bounded screen which produced the visible frame,
    /// rather than a newer mutable screen whose text has already changed.
    pub(crate) fn published_tail(&self) -> Option<(&vt100::Screen, u16, u16, u64, u64)> {
        let tail = self.published.as_ref()?.tail.as_ref()?;
        Some((
            &tail.screen,
            tail.start,
            tail.count,
            tail.source,
            tail.first,
        ))
    }
    pub(crate) fn row_at(&mut self, anchor: Anchor) -> io::Result<Option<usize>> {
        self.sync();
        if anchor.epoch != self.epoch
            || anchor.record_id < self.base
            || anchor.record_id >= self.end
        {
            return Ok(None);
        }
        if let Some(locate) = &self.locate {
            if locate.anchor == anchor {
                return Ok(if locate.ready { locate.result } else { None });
            }
        }
        let checkpoint = self.before_anchor(anchor);
        self.locate = Some(Locate {
            anchor,
            row: checkpoint.row,
            flow: Flow::new(checkpoint.cursor),
            end: self.end,
            tail: self.tail.clone(),
            result: None,
            ready: false,
        });
        (self.wake)();
        Ok(None)
    }
    pub(crate) fn neighbour(
        &mut self,
        anchor: Anchor,
        delta: i32,
        preferred_col: u16,
    ) -> io::Result<Option<Anchor>> {
        let Some(row) = self.row_at(anchor)? else {
            return Ok(None);
        };
        let target = row
            .saturating_add_signed(delta as isize)
            .min(self.len().saturating_sub(1));
        Ok(self
            .navigation_row(target)?
            .map(|fragment| fragment.anchor_column(preferred_col)))
    }
    pub(crate) fn row_edge(&mut self, anchor: Anchor, end: bool) -> io::Result<Option<Anchor>> {
        let Some(row) = self.row_at(anchor)? else {
            return Ok(None);
        };
        Ok(self
            .navigation_row(row)?
            .map(|fragment| if end { fragment.end } else { fragment.start }))
    }
    fn navigation_row(&mut self, row: usize) -> io::Result<Option<Fragment>> {
        if let Some(query) = &self.navigation {
            if query.start == row {
                return Ok(if query.ready {
                    query.fragments.first().cloned()
                } else {
                    None
                });
            }
        }
        let checkpoint = self.before_row(row);
        self.navigation = Some(Query {
            start: row,
            count: 1,
            row: checkpoint.row,
            flow: Flow::new(checkpoint.cursor),
            end: self.end,
            tail: self.tail.clone(),
            fragments: Vec::new(),
            bytes: 0,
            revision: self.projection_revision,
            ready: false,
        });
        (self.wake)();
        Ok(None)
    }
}

#[cfg(test)]
#[path = "layout_tests.rs"]
mod tests;
