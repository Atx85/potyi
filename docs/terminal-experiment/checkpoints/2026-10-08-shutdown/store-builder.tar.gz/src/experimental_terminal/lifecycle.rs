// Pötyi - SPDX-License-Identifier: GPL-3.0-or-later
//! File-based managed commands with explicit, authenticated completion boundaries.
use std::{
    fs::{self, OpenOptions},
    io::{self, Write},
    path::{Path, PathBuf},
};
#[derive(Debug, Clone)]
pub(crate) struct Completion {
    pub(crate) id: u64,
    pub(crate) status: i32,
    pub(crate) directory: PathBuf,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Shell {
    Posix,
    Fish,
    Windows,
}
pub(super) struct Lifecycle {
    directory: PathBuf,
    shell: Shell,
    nonce: String,
    next_id: u64,
    running: Option<u64>,
    completion: Option<Completion>,
}
impl Lifecycle {
    pub(super) fn new(shell: Shell, helpers: &str) -> io::Result<Self> {
        let mut random = [0u8; 16];
        getrandom::getrandom(&mut random).map_err(|e| io::Error::other(e.to_string()))?;
        let name: String = random.iter().map(|b| format!("{b:02x}")).collect();
        let directory = std::env::temp_dir().join(format!("potyi-managed-{name}"));
        #[allow(unused_mut)]
        let mut builder = fs::DirBuilder::new();
        #[cfg(unix)]
        {
            use std::os::unix::fs::DirBuilderExt;
            builder.mode(0o700);
        }
        builder.create(&directory)?;
        let lifecycle = Self {
            directory,
            shell,
            nonce: name,
            next_id: 0,
            running: None,
            completion: None,
        };
        lifecycle.write_file(lifecycle.driver_filename(), &lifecycle.driver(helpers))?;
        if shell == Shell::Windows {
            for operation in ["edit", "view"] {
                lifecycle.write_file(&format!("{operation}.cmd"),&format!("@echo off\r\n\"%POTYI_TERM_CLIENT%\" --term-request %POTYI_TERM_ADDRESS% %POTYI_TERM_TOKEN% {operation} %*\r\n"))?;
            }
        }
        Ok(lifecycle)
    }
    pub(super) fn nonce(&self) -> &str {
        &self.nonce
    }
    pub(super) fn directory(&self) -> &Path {
        &self.directory
    }
    pub(super) fn launch(&self) -> String {
        match self.shell {
            Shell::Posix => format!(
                ". {}",
                quote_posix(
                    &self
                        .directory
                        .join(self.driver_filename())
                        .to_string_lossy()
                )
            ),
            Shell::Fish => format!(
                "source {}",
                quote_posix(
                    &self
                        .directory
                        .join(self.driver_filename())
                        .to_string_lossy()
                )
            ),
            Shell::Windows => format!(
                "\"{}\"",
                self.directory.join(self.driver_filename()).display()
            ),
        }
    }
    pub(super) fn running(&self) -> bool {
        self.running.is_some()
    }
    pub(super) fn prepare(&mut self, command: &str, directory: &Path) -> io::Result<Vec<u8>> {
        if self.running() {
            return Err(io::Error::other("A command is already running"));
        }
        if command.len() > 64 * 1024 || command.as_bytes().contains(&0) {
            return Err(io::Error::other("Command exceeds 64 KiB or contains NUL"));
        }
        if !directory.is_dir() {
            return Err(io::Error::other("The command directory is unavailable"));
        }
        let directory = directory.canonicalize()?;
        let path = directory
            .to_str()
            .ok_or_else(|| io::Error::other("Command directory is not valid Unicode"))?;
        let body = match self.shell {
            Shell::Posix => format!(
                "case \"$POTYI_DRIVER_SHELL\" in *zsh|*bash|*ksh) builtin cd {0} ;; *) command cd {0} ;; esac || return $?\n{command}\n",
                quote_posix(path)
            ),
            Shell::Fish => format!(
                "builtin cd {}; or return $status\n{command}\n",
                quote_posix(path)
            ),
            Shell::Windows => format!(
                "@echo off\r\ncd /D \"{}\"\r\nif errorlevel 1 exit /b %ERRORLEVEL%\r\n{command}\r\n",
                path.replace('%', "%%")
            ),
        };
        let id = self.next_id.wrapping_add(1).max(1);
        self.write_file(&self.command_filename(id), &body)?;
        self.next_id = id;
        self.running = Some(id);
        self.completion = None;
        Ok(if self.shell == Shell::Fish {
            format!("\0{}:{}\0", self.nonce, self.next_id).into_bytes()
        } else {
            format!("\r{}:{}\r", self.nonce, self.next_id).into_bytes()
        })
    }
    pub(super) fn cancel_start(&mut self) {
        if let Some(id) = self.running.take() {
            let _ = fs::remove_file(self.directory.join(self.command_filename(id)));
        }
    }
    pub(super) fn finish(&mut self, id: u64, status: i32, directory: PathBuf) -> bool {
        if self.running != Some(id) {
            return false;
        }
        self.running = None;
        self.completion = Some(Completion {
            id,
            status,
            directory,
        });
        true
    }
    pub(super) fn take_completion(&mut self) -> Option<Completion> {
        self.completion.take()
    }
    fn driver_filename(&self) -> &str {
        if self.shell == Shell::Windows {
            "driver.cmd"
        } else {
            "driver"
        }
    }
    fn command_filename(&self, id: u64) -> String {
        if self.shell == Shell::Windows {
            format!("command-{id}.cmd")
        } else {
            format!("command-{id}")
        }
    }
    fn write_file(&self, name: &str, body: &str) -> io::Result<()> {
        let path = self.directory.join(name);
        let mut options = OpenOptions::new();
        options.write(true).create(true).truncate(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        options.open(path)?.write_all(body.as_bytes())
    }
    fn driver(&self, helpers: &str) -> String {
        match self.shell {
            Shell::Posix=>format!(r#"PS1= PS2= PS3= PS4=
{helpers}
__potyi_complete() {{
    command -p stty sane -echo 2>/dev/null
    "$POTYI_TERM_CLIENT" --term-request "$POTYI_TERM_ADDRESS" "$POTYI_TERM_TOKEN" complete "$__potyi_id" "$1"
}}
trap ':' INT
command -p stty sane -echo 2>/dev/null
printf '\033[2J\033[H\033]777;potyi-ready\007'
while IFS= read -r __potyi_dispatch; do
    case "$__potyi_dispatch" in "$POTYI_DRIVER_NONCE":*) __potyi_id=${{__potyi_dispatch#*:}} ;; *) continue ;; esac
    case "$__potyi_id" in ''|*[!0-9]*) continue ;; esac
    [ -f "$POTYI_DRIVER_DIRECTORY/command-$__potyi_id" ] || continue
    command -p mv "$POTYI_DRIVER_DIRECTORY/command-$__potyi_id" "$POTYI_DRIVER_DIRECTORY/running-command" || exit $?
    case "$POTYI_DRIVER_SHELL" in
        *zsh) "$POTYI_DRIVER_SHELL" -f -n "$POTYI_DRIVER_DIRECTORY/running-command" ;;
        *bash) "$POTYI_DRIVER_SHELL" --noprofile --norc -n "$POTYI_DRIVER_DIRECTORY/running-command" ;;
        *) "$POTYI_DRIVER_SHELL" -n "$POTYI_DRIVER_DIRECTORY/running-command" ;;
    esac
    __potyi_status=$?
    if [ "$__potyi_status" -eq 0 ]; then
        command -p stty sane 2>/dev/null
        . "$POTYI_DRIVER_DIRECTORY/running-command"
        __potyi_status=$?
    fi
    command -p rm -f "$POTYI_DRIVER_DIRECTORY/running-command" || exit $?
    __potyi_complete "$__potyi_status" || exit $?
done
"#),
            Shell::Fish=>format!(r#"set -g __potyi_dispatch_stty (command --search stty)
set -g __potyi_dispatch_mv (command --search mv)
set -g __potyi_dispatch_rm (command --search rm)
test -n "$__potyi_dispatch_stty"; or exit 127
test -n "$__potyi_dispatch_mv"; or exit 127
test -n "$__potyi_dispatch_rm"; or exit 127
{helpers}
function __potyi_complete --argument-names exit_status
    "$__potyi_dispatch_stty" sane -echo -icanon min 1 time 0 2>/dev/null
    "$POTYI_TERM_CLIENT" --term-request "$POTYI_TERM_ADDRESS" "$POTYI_TERM_TOKEN" complete "$__potyi_id" "$exit_status"
end
function __potyi_interrupt --on-signal INT
end
"$__potyi_dispatch_stty" sane -echo -icanon min 1 time 0 2>/dev/null
printf '\033[2J\033[H\033]777;potyi-ready\007'
while read --null --nchars 64 --global __potyi_dispatch
    set __potyi_parts (string split --max 1 ':' -- "$__potyi_dispatch")
    test (count $__potyi_parts) -eq 2; or continue
    test "$__potyi_parts[1]" = "$POTYI_DRIVER_NONCE"; or continue
    set -g __potyi_id "$__potyi_parts[2]"
    string match -qr '^[0-9]+$' -- "$__potyi_id"; or continue
    test -f "$POTYI_DRIVER_DIRECTORY/command-$__potyi_id"; or continue
    "$__potyi_dispatch_mv" "$POTYI_DRIVER_DIRECTORY/command-$__potyi_id" "$POTYI_DRIVER_DIRECTORY/running-command"; or exit $status
    "$POTYI_DRIVER_SHELL" --no-config --no-execute "$POTYI_DRIVER_DIRECTORY/running-command"
    set __potyi_status $status
    if test $__potyi_status -eq 0
        "$__potyi_dispatch_stty" sane 2>/dev/null
        source "$POTYI_DRIVER_DIRECTORY/running-command"
        set __potyi_status $status
    end
    "$__potyi_dispatch_rm" -f "$POTYI_DRIVER_DIRECTORY/running-command"; or exit $status
    __potyi_complete $__potyi_status; or exit $status
end
"#),
            Shell::Windows=>format!(r#"@echo off
{helpers}
"%POTYI_TERM_CLIENT%" --term-request %POTYI_TERM_ADDRESS% %POTYI_TERM_TOKEN% ready
:potyi_next
set "POTYI_COMMAND_DISPATCH="
set "POTYI_COMMAND_ID="
for /f "delims=" %%I in ('"%POTYI_TERM_CLIENT%" --term-request %POTYI_TERM_ADDRESS% %POTYI_TERM_TOKEN% read-command') do set "POTYI_COMMAND_DISPATCH=%%I"
if not defined POTYI_COMMAND_DISPATCH exit /b 1
for /f "tokens=1,2 delims=:" %%A in ("%POTYI_COMMAND_DISPATCH%") do if "%%A"=="%POTYI_DRIVER_NONCE%" set "POTYI_COMMAND_ID=%%B"
if not defined POTYI_COMMAND_ID goto potyi_next
if not exist "%POTYI_DRIVER_DIRECTORY%\command-%POTYI_COMMAND_ID%.cmd" goto potyi_next
move /Y "%POTYI_DRIVER_DIRECTORY%\command-%POTYI_COMMAND_ID%.cmd" "%POTYI_DRIVER_DIRECTORY%\running-command.cmd" >NUL
if errorlevel 1 exit /b %ERRORLEVEL%
call "%POTYI_DRIVER_DIRECTORY%\running-command.cmd"
set "POTYI_COMMAND_STATUS=%ERRORLEVEL%"
del /Q "%POTYI_DRIVER_DIRECTORY%\running-command.cmd" >NUL 2>&1
"%POTYI_TERM_CLIENT%" --term-request %POTYI_TERM_ADDRESS% %POTYI_TERM_TOKEN% complete %POTYI_COMMAND_ID% %POTYI_COMMAND_STATUS%
if errorlevel 1 exit /b %ERRORLEVEL%
goto potyi_next
"#).replace('\n',"\r\n"),
        }
    }
}
impl Drop for Lifecycle {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.directory);
    }
}
fn quote_posix(text: &str) -> String {
    format!("'{}'", text.replace('\'', "'\\''"))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn lifecycle_rejects_overlapping_and_stale_completions_and_cleans_private_files() {
        let mut lifecycle = Lifecycle::new(Shell::Posix, "").unwrap();
        let directory = lifecycle.directory.clone();
        assert!(
            lifecycle
                .prepare(
                    "printf '%s\\n' 'quoted'; # final comment",
                    &std::env::temp_dir()
                )
                .is_ok()
        );
        assert!(
            lifecycle
                .prepare("echo too early", &std::env::temp_dir())
                .is_err()
        );
        assert!(!lifecycle.finish(7, 0, "/tmp".into()));
        assert!(lifecycle.running());
        assert!(lifecycle.finish(1, 17, "/tmp".into()));
        assert!(!lifecycle.finish(1, 0, "/tmp".into()));
        assert_eq!(lifecycle.take_completion().unwrap().status, 17);
        drop(lifecycle);
        assert!(!directory.exists());
    }
}
