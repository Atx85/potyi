# Terminal latency evidence, 2026-10-09

`records/assessment.json` checks frozen identities and contains paired resource comparisons. `startup/` retains all60 processes, including first-command outliers; `resources/` retains all12 resource processes and raw observer intervals. Tracing was disabled and root ran measurements without concurrent builds, profilers or other samplers.

`sources/before` is the previous terminal with the identical command-completion probe; `sources/after` is the measured optimization. `sources/combined` preserves concurrent editor changes and is separately validated. Source manifests use the established sha256-relative-path-nul-file-v1 scope. The additional compile-time test input docs/lsp.md is archived and separately hashed in records/extra-test-inputs.json. The optimization patch is against the immutable captured baseline, not current Git HEAD.

Build/test logs retain failed preliminary synthetic fixtures, sandbox-blocked runs, and the combined snapshot's initially omitted help-document fixture. These are diagnostic history. Only *final logs, linux-check.log, successful Windows check and visual-parity-final feed the acceptance results. Native Windows runtime is not verified.

`visual/lossless-png-manifest.json` maps each raw BMP to a lossless PNG and verifies identical RGB bytes. Raw BMPs and executable copies remain in the local temporary workspace rather than adding them to the repository. Capture fixture manifests retain deterministic Git inputs; no fixture .git directories are archived. Existing historical evidence was not overwritten.

Reproduction requires the recorded compiler/dependency environment. Rebuild the frozen sources and replace local temporary paths in collector configurations with your own absolute paths and new matching build manifests. The visual runner also expects the prior fixture templates referenced by its source; those paths are historical, not portable. Figures use hidden SDL x86_64 macOS under Rosetta on ARM hardware and do not establish native Windows/compositor behavior or universal resource guarantees.

The combined integration passed the release build and all 246 terminal tests, another 55 RGB/ 21 clipboard comparison, and Mac package signing. Its full core source identity matches the shared checkout after applying the changes. See records/integration-check.json. Final archive membership and hashes appear in archive-manifest.json.
