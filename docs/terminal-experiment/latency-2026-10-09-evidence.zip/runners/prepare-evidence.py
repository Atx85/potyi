from pathlib import Path
import hashlib,json,shutil,datetime
from PIL import Image
P=Path('/private/tmp/potyi-terminal-latency-4tteslv2');E=P/'evidence';E.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(src,name):
 dest=E/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for src in sorted(P.iterdir()):
 if src.is_file() and src.suffix in {'.json','.jsonl','.log','.patch','.sha256'}:copy(src,Path('records')/src.name)
for label in ['before','after']:
 for src in sorted((P/(label+'-resources')).rglob('*')):
  if src.is_file():copy(src,Path('resources')/label/src.relative_to(P/(label+'-resources')))
for src in sorted((P/'startup').rglob('*')):
 if src.is_file():copy(src,Path('startup')/src.relative_to(P/'startup'))
for src in [P/'candidate/tools/qa/terminal-startup.py',P/'candidate/tools/qa/terminal-resources.py',P/'prepare-evidence.py',Path('/private/tmp/potyi-terminal-performance-20261009-111723/review/assess-terminal-performance.py'),Path('/private/tmp/potyi-terminal-performance-20261009-111723/review/run_terminal_visual_parity.py')]:copy(src,Path('runners')/src.name)
for label,source,manifest in [('before',P/'baseline-instrumented',P/'baseline-instrumented-source.json'),('after',P/'candidate',P/'candidate-source-final-after.json'),('combined',P/'integration',P/'integration-source-before.json')]:
 data=json.loads(manifest.read_text())
 for row in data['files']:
  src=source/row['path'];assert sha(src)==row['sha256'];copy(src,Path('sources')/label/row['path'])
 for name in ['Readme.md','docs/lsp.md','tools/qa/terminal-backend/Cargo.toml','tools/qa/terminal-backend/Cargo.lock']:
  copy(source/name,Path('sources')/label/name)
 for src in (source/'tools/qa/terminal-backend/src').rglob('*'):
  if src.is_file():copy(src,Path('sources')/label/src.relative_to(source))
 for src in (source/'tools/qa/terminal-backend/examples').rglob('*'):
  if src.is_file():copy(src,Path('sources')/label/src.relative_to(source))
visual=P/'visual-parity-final';conversion=[]
for src in sorted(visual.rglob('*')):
 if not src.is_file() or '.git' in src.relative_to(visual).parts:continue
 name=Path('visual')/src.relative_to(visual)
 if src.suffix=='.bmp':
  png=E/name.with_suffix('.png');png.parent.mkdir(parents=True,exist_ok=True)
  with Image.open(src) as img:
   rgb=img.convert('RGB');pixels=rgb.tobytes();rgb.save(png)
   with Image.open(png) as restored:assert restored.convert('RGB').tobytes()==pixels
   conversion.append({'bmp':name.as_posix(),'bmp_sha256':sha(src),'png':png.relative_to(E).as_posix(),'png_sha256':sha(png),'rgb_sha256':hashlib.sha256(pixels).hexdigest(),'width':rgb.width,'height':rgb.height})
 else:copy(src,name)
(E/'visual/lossless-png-manifest.json').write_text(json.dumps(conversion,indent=2)+'\n')
(E/'README.md').write_text('''# Terminal latency evidence, 2026-10-09

`records/assessment.json` checks frozen identities and contains paired resource comparisons. `startup/` retains all60 processes, including first-command outliers; `resources/` retains all12 resource processes and raw observer intervals. Tracing was disabled and root ran measurements without concurrent builds, profilers or other samplers.

`sources/before` is the previous terminal with the identical command-completion probe; `sources/after` is the measured optimization. `sources/combined` preserves concurrent editor changes and is separately validated. Source manifests use the established sha256-relative-path-nul-file-v1 scope. The additional compile-time test input docs/lsp.md is archived and separately hashed in records/extra-test-inputs.json. The optimization patch is against the immutable captured baseline, not current Git HEAD.

Build/test logs retain failed preliminary synthetic fixtures, sandbox-blocked runs, and the combined snapshot's initially omitted help-document fixture. These are diagnostic history. Only *final logs, linux-check.log, successful Windows check and visual-parity-final feed the acceptance results. Native Windows runtime is not verified.

`visual/lossless-png-manifest.json` maps each raw BMP to a lossless PNG and verifies identical RGB bytes. Raw BMPs and executable copies remain in the local temporary workspace rather than adding them to the repository. Capture fixture manifests retain deterministic Git inputs; no fixture .git directories are archived. Existing historical evidence was not overwritten.

Reproduction requires the recorded compiler/dependency environment. Rebuild the frozen sources and replace local temporary paths in collector configurations with your own absolute paths and new matching build manifests. The visual runner also expects the prior fixture templates referenced by its source; those paths are historical, not portable. Figures use hidden SDL x86_64 macOS under Rosetta on ARM hardware and do not establish native Windows/compositor behavior or universal resource guarantees.
''')
print('Prepared evidence',len([x for x in E.rglob('*') if x.is_file()]),'files;',len(conversion),'verified lossless PNGs')
