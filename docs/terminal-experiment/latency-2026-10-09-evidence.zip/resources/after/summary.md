# Matched terminal resource measurements

2026-10-09T14:46:51.571011+00:00 · release test binary · 3 fresh paired samples, alternating order.

Execution: **x86_64 release binary under Rosetta on ARM hardware**. SDL uses a hidden 800×600 dummy-video fixture, embedded fonts and the app's poll/frame schedule. This is not a native window idle measurement.

App and descendant processes are separate scopes. CPU is a percentage of one core from cumulative process counters; small zero values can be below `ps` time resolution. Descendant CPU covers observed process lifetimes and can miss short-lived children.

Only snapshots whose whole `ps` interval is within an observed phase are aggregated. Boundary exclusions and timestamps remain in the raw JSONL evidence. The source digest identifies the sampled checkout; compiled-source identity requires the matching frozen-build manifest.

| Phase | Integration | App RSS median MiB | App CPU s | App CPU % | Descendant RSS median MiB | Observed descendant CPU s | Observed descendant CPU % |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| idle | old | 14.40 | 0.01 | 0.54 | 0.00 | 0.00 | 0.00 |
| idle | new | 15.05 | 0.01 | 0.54 | 3.96 | 0.00 | 0.00 |
| small_command | old | 15.13 | — | — | 2.88 | — | — |
| small_command | new | 15.68 | — | — | 5.64 | — | — |
| small_idle | old | 15.68 | 0.01 | 0.55 | 0.00 | 0.00 | 0.00 |
| small_idle | new | 16.68 | 0.01 | 0.54 | 4.26 | 0.00 | 0.00 |
| stream_first | old | 32.33 | 0.56 | 24.10 | 12.16 | 0.09 | 3.32 |
| stream_first | new | 34.12 | 0.58 | 22.86 | 16.28 | 0.15 | 5.71 |
| plateau_first | old | 39.75 | 0.01 | 0.52 | 0.00 | 0.00 | 0.00 |
| plateau_first | new | 44.51 | 0.02 | 1.08 | 4.12 | 0.00 | 0.00 |
| stream_second | old | 43.01 | 0.55 | 23.91 | 12.39 | 0.09 | 3.99 |
| stream_second | new | 49.07 | 0.59 | 24.50 | 16.39 | 0.16 | 6.56 |
| plateau_second | old | 46.01 | 0.01 | 0.55 | 0.00 | 0.00 | 0.00 |
| plateau_second | new | 50.47 | 0.01 | 0.54 | 4.15 | 0.00 | 0.00 |
| stream_third | old | 47.17 | 0.56 | 24.01 | 12.22 | 0.08 | 3.51 |
| stream_third | new | 52.29 | 0.63 | 24.90 | 16.04 | 0.15 | 6.21 |
| plateau_third | old | 49.02 | 0.01 | 0.55 | 0.00 | 0.00 | 0.00 |
| plateau_third | new | 52.73 | 0.01 | 0.55 | 4.14 | 0.00 | 0.00 |
| resize | old | 85.86 | 2.20 | 99.55 | 0.00 | 0.00 | 0.00 |
| resize | new | 58.74 | 0.60 | 100.89 | 4.14 | 0.00 | 0.00 |
| copy_selected | old | 104.66 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| copy_selected | new | 64.14 | 0.00 | 0.00 | 4.14 | 0.00 | 0.00 |
| copy_all | old | 128.66 | 0.01 | 1.57 | 0.00 | 0.00 | 0.00 |
| copy_all | new | 87.00 | 0.05 | 7.50 | 4.14 | 0.00 | 0.00 |
| copied_idle | old | 128.66 | 0.01 | 0.52 | 0.00 | 0.00 | 0.00 |
| copied_idle | new | 87.00 | 0.01 | 0.55 | 4.14 | 0.00 | 0.00 |

| Operation | Integration | Median ms | Min–max ms | Median copied MiB |
| --- | --- | ---: | ---: | ---: |
| small_command | old | 53.27 | 51.95–58.57 | — |
| small_command | new | 144.02 | 130.79–159.72 | — |
| stream_first | old | 2439.49 | 2437.09–2901.78 | — |
| stream_first | new | 2792.22 | 2566.39–2890.28 | — |
| stream_second | old | 2433.77 | 2426.81–2931.54 | — |
| stream_second | new | 2609.64 | 2574.69–3230.50 | — |
| stream_third | old | 2430.85 | 2423.18–2896.40 | — |
| stream_third | new | 2604.22 | 2603.53–4432.52 | — |
| resize | old | 2444.06 | 2314.81–2507.61 | — |
| resize | new | 723.30 | 705.15–860.75 | — |
| copy_selected | old | 0.02 | 0.01–0.02 | 0.00 |
| copy_selected | new | 1.43 | 1.41–10.00 | 0.00 |
| copy_all | old | 13.36 | 12.34–13.45 | 8.00 |
| copy_all | new | 47.89 | 47.69–49.20 | 4.56 |

Each integration receives the same 64KiB small producer and three paced 12MiB producers (36MiB cumulative cap-crossing output), then 9 width/height changes and selected ≤4KiB / all-retained clipboard copies. Commands, cwd, fonts and test binary are shared. Later settled phases check continued eviction and memory growth after the first cap crossing; a flat RSS plateau is not asserted.

RSS includes allocator-retained memory, headless renderer/texture caches, terminal grids and clipboard storage. Clipboard phases include verification through SDL. Binary/test fixture setup and producer creation are outside the measured settled phases.

CopyAll is each integration's retained plaintext, whose size is recorded above: the new 8MiB budget includes record/index metadata, while legacy caps its output text. CopyAll costs therefore cover different retained byte counts; the selected ≤4KiB scope is matched. Producer rows contain changing serial numbers and Unicode, rather than repeating one cache-identical row.

The command helper path is explicit and overrides inherited test-helper settings; its SHA-256 is checked before and after each run and against the frozen-build manifest when supplied.

- Headless hidden SDL fixture; no native compositor, OS keyboard delivery or visible clipboard UX is measured.
- The persistent new terminal shell contributes to descendant idle RSS; it is separate from app RSS.
- Polling ps is an external observer with scheduling overhead, retained in raw sample timings.
- Whole observer intervals crossing observed phase markers are excluded; marker timestamps include log reader scheduling delay.
- CPU counters have platform-dependent resolution; vanished/short-lived descendants can be undercounted.
- Fast phases may have no ps sample; operation latency remains in events rather than inventing zero resource usage.
- Three pairs describe this machine and warm local temporary storage, not universal hardware/OS guarantees.
- RSS sums child address spaces and may double-count shared pages; it is not proportional/private memory.
- The prebuilt binary hash is recorded; release profile is validated against the supplied frozen-build manifest when present, otherwise caller supplied.

[Raw metrics, phase events, source/binary hashes and log names](results.json). Per-run JSONL files retain every app/descendant sample.
