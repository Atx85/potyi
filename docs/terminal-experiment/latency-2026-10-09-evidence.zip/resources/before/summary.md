# Matched terminal resource measurements

2026-10-09T14:44:20.892495+00:00 · release test binary · 3 fresh paired samples, alternating order.

Execution: **x86_64 release binary under Rosetta on ARM hardware**. SDL uses a hidden 800×600 dummy-video fixture, embedded fonts and the app's poll/frame schedule. This is not a native window idle measurement.

App and descendant processes are separate scopes. CPU is a percentage of one core from cumulative process counters; small zero values can be below `ps` time resolution. Descendant CPU covers observed process lifetimes and can miss short-lived children.

Only snapshots whose whole `ps` interval is within an observed phase are aggregated. Boundary exclusions and timestamps remain in the raw JSONL evidence. The source digest identifies the sampled checkout; compiled-source identity requires the matching frozen-build manifest.

| Phase | Integration | App RSS median MiB | App CPU s | App CPU % | Descendant RSS median MiB | Observed descendant CPU s | Observed descendant CPU % |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| idle | old | 14.03 | 0.01 | 0.53 | 0.00 | 0.00 | 0.00 |
| idle | new | 15.02 | 0.01 | 0.53 | 3.95 | 0.00 | 0.00 |
| small_command | old | 14.71 | — | — | 1.92 | — | — |
| small_command | new | 15.36 | 0.00 | 0.00 | 7.77 | 0.06 | 38.14 |
| small_idle | old | 15.38 | 0.01 | 0.53 | 0.00 | 0.00 | 0.00 |
| small_idle | new | 16.34 | 0.01 | 0.53 | 4.20 | 0.00 | 0.00 |
| stream_first | old | 33.86 | 0.63 | 22.55 | 11.94 | 0.09 | 3.19 |
| stream_first | new | 36.23 | 0.89 | 32.56 | 15.67 | 0.15 | 5.49 |
| plateau_first | old | 43.95 | 0.01 | 0.53 | 0.00 | 0.00 | 0.00 |
| plateau_first | new | 43.22 | 0.01 | 0.55 | 4.07 | 0.00 | 0.00 |
| stream_second | old | 47.76 | 0.61 | 22.45 | 11.92 | 0.08 | 2.92 |
| stream_second | new | 46.98 | 0.94 | 33.47 | 15.81 | 0.15 | 5.28 |
| plateau_second | old | 51.80 | 0.01 | 0.54 | 0.00 | 0.00 | 0.00 |
| plateau_second | new | 50.30 | 0.01 | 0.54 | 4.07 | 0.00 | 0.00 |
| stream_third | old | 55.01 | 0.61 | 22.41 | 11.91 | 0.09 | 3.33 |
| stream_third | new | 53.07 | 1.00 | 36.25 | 15.73 | 0.15 | 5.24 |
| plateau_third | old | 56.88 | 0.01 | 0.53 | 0.00 | 0.00 | 0.00 |
| plateau_third | new | 54.48 | 0.01 | 0.54 | 4.07 | 0.00 | 0.00 |
| resize | old | 82.04 | 2.19 | 99.94 | 0.00 | 0.00 | 0.00 |
| resize | new | 67.51 | 1.64 | 99.78 | 4.07 | 0.00 | 0.00 |
| copy_selected | old | 91.91 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| copy_selected | new | 73.95 | 0.01 | 1.47 | 4.07 | 0.00 | 0.00 |
| copy_all | old | 113.74 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| copy_all | new | 87.77 | 0.05 | 7.43 | 4.07 | 0.00 | 0.00 |
| copied_idle | old | 113.74 | 0.01 | 0.52 | 0.00 | 0.00 | 0.00 |
| copied_idle | new | 87.77 | 0.01 | 0.54 | 4.07 | 0.00 | 0.00 |

| Operation | Integration | Median ms | Min–max ms | Median copied MiB |
| --- | --- | ---: | ---: | ---: |
| small_command | old | 76.06 | 58.47–80.31 | — |
| small_command | new | 182.45 | 172.05–285.48 | — |
| stream_first | old | 2890.75 | 2872.44–2937.76 | — |
| stream_first | new | 2916.69 | 2878.64–3076.64 | — |
| stream_second | old | 2882.73 | 2850.60–2885.38 | — |
| stream_second | new | 2982.52 | 2941.66–3045.01 | — |
| stream_third | old | 2891.05 | 2862.10–2922.06 | — |
| stream_third | new | 2963.17 | 2890.95–4590.89 | — |
| resize | old | 2319.80 | 2318.73–2322.79 | — |
| resize | new | 1713.55 | 1705.80–1730.28 | — |
| copy_selected | old | 0.01 | 0.01–0.01 | 0.00 |
| copy_selected | new | 1.42 | 1.38–1.54 | 0.00 |
| copy_all | old | 11.74 | 11.66–14.88 | 8.00 |
| copy_all | new | 47.31 | 45.55–49.48 | 4.56 |

Each integration receives the same 64KiB small producer and three paced 12MiB producers (36MiB cumulative cap-crossing output), then 9 width/height changes and selected ≤4KiB / all-retained clipboard copies. Commands, cwd, fonts and test binary are shared. Later settled phases check continued eviction and memory growth after the first cap crossing; a flat RSS plateau is not asserted.

RSS includes allocator-retained memory, headless renderer/texture caches, terminal grids and clipboard storage. Clipboard phases include verification through SDL. Binary/test fixture setup and producer creation are outside the measured settled phases.

CopyAll is each integration's retained plaintext, whose size is recorded above: the new 8MiB budget includes record/index metadata, while legacy caps its output text. CopyAll costs therefore cover different retained byte counts; the selected ≤4KiB scope is matched. Producer rows contain changing serial numbers and Unicode, rather than repeating one cache-identical row.

The command helper path is explicit and overrides inherited test-helper settings; its SHA-256 is checked before and after each run and against the frozen-build manifest when supplied.

- Headless hidden SDL fixture; no native compositor, OS keyboard delivery or visible clipboard UX is measured.
- The persistent new terminal shell contributes to descendant idle RSS; it is separate from app RSS.
- Polling ps is an external observer with scheduling overhead, retained in raw sample timings.
- Whole observer intervals crossing observed phase markers are excluded; marker timestamps include log reader scheduling delay.
- CPU counters have platform-dependent resolution; vanished/short-lived descendants can be undercounted.
- Fast phases may have no ps sample; operation latency remains in events rather than inventing zero resource usage.
- Three pairs describe this machine and warm local temporary storage, not universal hardware/OS guarantees.
- RSS sums child address spaces and may double-count shared pages; it is not proportional/private memory.
- The prebuilt binary hash is recorded; release profile is validated against the supplied frozen-build manifest when present, otherwise caller supplied.

[Raw metrics, phase events, source/binary hashes and log names](results.json). Per-run JSONL files retain every app/descendant sample.
