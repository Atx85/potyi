The latest `:term-new` changes reduce command delay and output CPU, preserving original `:term` and existing limits. Warm commands take a median **84.69 ms**, down from **124.61 ms**. Three 12 MiB streams use **36.4% less app CPU** in the raw comparison; normalization against the original terminal's controls gives **28.6% less CPU**.

Values are medians unless marked otherwise. Original `:term` used unchanged source in both batches; its two values show control variation.

| Measurement | Previous `:term-new` | Current `:term-new` | Original `:term`, before → after |
|---|---:|---:|---:|
| Warm tiny command, 50 commands | 124.61 ms | **84.69 ms** | 14.78 → 16.15 ms |
| First tiny command, 10 fresh processes | 128.91 ms | **92.11 ms** | 16.24 → 16.39 ms |
| Worst first command / nearest-rank p95 | 2,610.54 ms | **388.58 ms** | 20.59 → 19.49 ms |
| App CPU for 36 MiB output | 2.83 s | **1.80 s** | 1.85 → 1.67 s |
| Resize sequence elapsed time | 1,713.55 ms | **723.30 ms** | 2,319.80 → 2,444.06 ms |
| Resize app CPU | 1.64 s | **0.605 s†** | 2.19 → 2.20 s |
| Settled app + descendants RSS after third stream | 58.49 MiB | 56.86 MiB | 56.88 → 49.02 MiB |
| Settled app + descendants RSS after Copy All | 91.78 MiB | 91.12 MiB | 113.74 → 128.66 MiB |

*† Only two current resize runs had valid CPU sample windows; all three elapsed-time observations are retained.*

The new terminal is still slower for tiny commands. The separate first-observed app completion median is **84.15 ms**, only about 0.54 ms before the final settled display measurement, so waiting for final layout settlement does not explain most of the remaining delay. That completion timestamp includes the observing event-loop turn; it is not an exact shell-exit timestamp. The warm median is below the 100 ms target, but first-command p95 still misses the 250 ms target. With ten fresh processes, nearest-rank p95 is the observed maximum, and these launches are not proven cold OS-cache launches.

Current output CPU is close to the original: paired per-stream CPU ratios are about **1.04, 1.09 and 1.12**. Memory ranges overlap: settled RSS was 56.83–68.57 MiB before and 51.45–74.10 MiB after; post-copy ranges were 83.39–107.07 and 86.90–106.44 MiB. These results do not establish a meaningful memory reduction or a flat plateau. The new terminal made zero draws in the measured idle windows and used about 0.01 seconds of app CPU over two seconds, near the process-counter resolution.

Copying remains a gap: current selected-copy median is 1.43 ms versus 0.016 ms in original `:term`. Copy All takes 47.89 ms versus 13.36 ms, but copies different retained amounts: 4.56 MiB in the new transcript versus 8 MiB of original output text. The new 8 MiB storage cap includes record and index metadata.

The command helper is now a separate **470 KiB** executable instead of launching the approximately **12 MiB** app image. It shares the same request implementation, authentication, limits and completion protocol, and links no graphics libraries. Builds and packages include a helper for the same target beside the app; the app path remains a fallback for a copied standalone executable. A diagnostic control using the current driver with the full app helper measured 98.14 ms warm commands and a 2,762.95 ms worst first command; the smaller helper measured 84.69 ms and 388.58 ms. This supports the helper change without attributing every saving to it.

The POSIX production driver avoids external `mv` and `rm` processes for each command. The app removes the numbered command and directory packets after authenticated metadata and the ordered output seal, or after driver closure. A monotonic ID guard rejects duplicate and older retained packets. Cleanup failures retain one pending ID and block the next command until cleanup succeeds. Raw mode and Fish retain their existing execution paths.

Counting, checkpoints, locating and rebasing process printable ASCII in spans of at most **64 bytes**, borrowing existing text with no new cache or retained buffer. Exact wrapping, styles, anchors, fragment caps and 64-scalar yield points are retained. Visible projection, its allocation growth, the 256 KiB allowance per projection and the conservative 2 MiB accounting for active and saved projection sets are unchanged. The production work budget remains 128 record reads / approximately 2 ms per poll.

Candidate verification passed **246 app checks** on Mac and Linux, **215 backend checks plus 2 VT checks** on native Mac ARM and Linux ARM, and **55 exact RGB / 21 exact clipboard comparisons** against original `:term`. Windows GNU compilation includes four new directory checks, but those checks have not run on native Windows. A Mac bundle containing the helper passed ad-hoc signing and strict signature verification; this is not notarization. Visual checks use the bundled font and software rendering, not every native display configuration.

Windows’ `\\?\` prefix denotes an extended path, as described by [Microsoft’s path documentation](https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file). CMD misreads that spelling as an unsupported network current directory and silently falls back to the Windows directory. The Windows CMD directory workaround translates a safe local-drive `\\?\` path only at the process boundary, using UTF-16. It rejects UNC/device paths, paths of 260 or more UTF-16 units, trailing dot/space components and DOS device components before dispatch. Browser, transcript and completion paths retain their canonical spelling; direct Git execution is unchanged. Native Windows runtime validation remains outstanding.

Performance evidence uses frozen release **x86_64 Mac binaries under Rosetta on ARM hardware**, dummy SDL, ten startup repetitions and three alternating resource pairs per batch. Tracing was disabled; builds, profilers and sampling did not overlap startup timing. Resource measurements retain boundary exclusions and observer costs, and use simultaneous app-plus-descendant RSS samples.

The measured candidate source SHA-256 is `ee7dae31b1c0255d171b26065412248b49f7e95a6564c01caa740448b6168295`. Concurrent editor work in `Cargo.toml`/`Cargo.lock`, `piece_table`, `line_index_tests` and `line_scan` was preserved during guarded application. The resulting shared snapshot is `b457e5d2c2d0814465e484c0fa95f621058b44038446e671b274d5211a34fc95`; it is a separate integration build that passed the release build, all 246 terminal app checks and a fresh 55 RGB / 21 clipboard comparison; it is not the exact measured source. Original terminal files and the Git index were preserved.

Raw results, process samples, lossless PNG comparisons, frozen source files and manifests, build/check logs and the patch are retained in [the evidence archive](latency-2026-10-09-evidence.zip); previous evidence remains unchanged. One archive avoids hundreds of loose files. The archive also retains failed preliminary fixture/sandbox checks, with only the final successful logs used for acceptance. It includes the separately hashed help document used by compile-time tests.

No branch, commit or FTP upload was created during this pass. The prepared commit guide includes the helper packaging changes and preserves other tasks’ shared hunks.
