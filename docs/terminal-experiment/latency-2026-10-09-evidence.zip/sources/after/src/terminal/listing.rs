// Pötyi - Lightweight text editor
// Copyright (C) 2026 Attila Banko
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

use super::TerminalEvent;
use sdl3::event::EventSender;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
    mpsc::{Receiver, SyncSender, sync_channel},
};
use std::thread;

use super::{DirectoryListing, LsOptions, append_ls_entry, parse_ls_arguments, resolve_ls_path};

const CHUNK_BYTES: usize = 16 * 1024;
const CHUNK_ENTRIES: usize = 64;
const QUEUED_CHUNKS: usize = 8;

pub(super) enum Message {
    Started(Option<PathBuf>),
    Chunk(DirectoryListing),
    NamesReady,
    GitStatus(super::git_status::Snapshot),
    Finished(Result<(), String>),
}

pub(super) struct Job {
    pub receiver: Receiver<Message>,
    pub background_only: bool,
    pub decorations: Option<(super::git_status::Snapshot, usize)>,
    cancelled: Arc<AtomicBool>,
}

impl Drop for Job {
    fn drop(&mut self) {
        self.cancelled.store(true, Ordering::Relaxed);
    }
}

pub(super) fn start(
    arguments: String,
    cwd: PathBuf,
    enter: Option<PathBuf>,
    width: usize,
    events: Option<EventSender>,
) -> io::Result<Job> {
    let (sender, receiver) = sync_channel(QUEUED_CHUNKS);
    let cancelled = Arc::new(AtomicBool::new(false));
    let worker_cancelled = cancelled.clone();
    thread::Builder::new()
        .name("potyi-listing".into())
        .spawn(move || {
            let mut writer = Writer {
                sender,
                events,
                cancelled: worker_cancelled,
                chunk: DirectoryListing::default(),
                width,
            };
            let result = (|| {
                let cwd = if let Some(path) = enter {
                    let target = path.canonicalize()?;
                    if !target.is_dir() {
                        return Err(io::Error::new(
                            io::ErrorKind::InvalidInput,
                            "Not a directory",
                        ));
                    }
                    writer.send(Message::Started(Some(target.clone())))?;
                    writer
                        .chunk
                        .text
                        .push_str(&format!("{}:\n", super::display_path(&target)));
                    target
                } else {
                    writer.send(Message::Started(None))?;
                    cwd
                };
                let (options, paths) = parse_ls_arguments(&arguments)?;
                let mut scopes = Vec::new();
                for (index, value) in paths.iter().enumerate() {
                    writer.check_cancelled()?;
                    if index > 0 {
                        writer.chunk.text.push('\n');
                    }
                    let path = resolve_ls_path(value, &cwd);
                    // Normalize parent components without following a file symlink.
                    let path = if path.is_dir() { path.canonicalize()? } else {
                        path.parent().unwrap_or(&cwd).canonicalize()?.join(path.file_name().unwrap_or_default())
                    };
                    let scope = if path.is_dir() { path.clone() } else { path.parent().unwrap().to_path_buf() };
                    if !scopes.iter().any(|existing: &PathBuf| scope.starts_with(existing)) {
                        scopes.retain(|existing| !existing.starts_with(&scope));
                        if scopes.len() < 8 { scopes.push(scope); }
                    }
                    writer.path(
                        &path,
                        value,
                        &options,
                        paths.len() > 1 || options.recursive,
                    )?;
                }
                writer.chunk.text.push('\n');
                writer.flush()?;
                writer.send(Message::NamesReady)?;
                // All names are available before Git starts. No watcher or idle polling.
                let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
                for scope in scopes {
                    writer.check_cancelled()?;
                    if let Some(snapshot) = super::git_status::load(&scope, &writer.cancelled, deadline) {
                        writer.send(Message::GitStatus(snapshot))?;
                    }
                }
                Ok(())
            })();
            // Preserve any entries produced before a filesystem error.
            if !writer.chunk.text.is_empty() {
                let _ = writer.flush();
            }
            let _ = writer.send(Message::Finished(
                result.map_err(|error: io::Error| error.to_string()),
            ));
        })?;
    Ok(Job {
        receiver,
        background_only: false,
        decorations: None,
        cancelled,
    })
}

struct Writer {
    sender: SyncSender<Message>,
    events: Option<EventSender>,
    cancelled: Arc<AtomicBool>,
    chunk: DirectoryListing,
    width: usize,
}

/// Only a width and a row position are retained, even for huge directories.
struct Columns {
    cell: usize,
    count: usize,
    position: usize,
}

impl Columns {
    fn new(width: usize, longest: usize) -> Self {
        let cell = longest.saturating_add(2).max(1);
        Self {
            cell,
            count: (width.saturating_add(2) / cell).max(1),
            position: 0,
        }
    }

    fn append(&mut self, output: &mut DirectoryListing) {
        let entry = output.entries.last().unwrap();
        let length = output.text[entry.range.clone()].chars().count();
        output.text.truncate(entry.range.end);
        self.position += 1;
        if self.position == self.count {
            output.text.push('\n');
            self.position = 0;
        } else {
            output.text.extend(std::iter::repeat_n(
                ' ',
                self.cell.saturating_sub(length).max(2),
            ));
        }
    }

    fn finish(&mut self, output: &mut DirectoryListing) {
        if self.position != 0 {
            output.text.push('\n');
            self.position = 0;
        }
    }
}

fn name_length(name: &str) -> usize {
    name.chars()
        .map(|c| {
            if c.is_control() {
                c.escape_default().count()
            } else {
                1
            }
        })
        .sum()
}

impl Writer {
    fn check_cancelled(&self) -> io::Result<()> {
        if self.cancelled.load(Ordering::Relaxed) {
            Err(io::Error::new(
                io::ErrorKind::Interrupted,
                "Listing cancelled",
            ))
        } else {
            Ok(())
        }
    }

    fn send(&self, message: Message) -> io::Result<()> {
        self.check_cancelled()?;
        // The bounded queue applies backpressure; dropping Job unblocks send.
        self.sender
            .send(message)
            .map_err(|_| io::Error::new(io::ErrorKind::Interrupted, "Listing closed"))?;
        if let Some(events) = &self.events {
            let _ = events.push_custom_event(TerminalEvent::ListingReady);
        }
        Ok(())
    }

    fn flush(&mut self) -> io::Result<()> {
        let chunk = std::mem::take(&mut self.chunk);
        if !chunk.text.is_empty() {
            self.send(Message::Chunk(chunk))?;
        }
        Ok(())
    }

    fn entry(
        &mut self,
        path: &Path,
        name: &str,
        options: &LsOptions,
        columns: Option<&mut Columns>,
    ) -> io::Result<()> {
        self.check_cancelled()?;
        append_ls_entry(&mut self.chunk, path, name, options)?;
        if let Some(columns) = columns {
            columns.append(&mut self.chunk);
        } else if !options.long && !options.one_per_line {
            self.chunk
                .text
                .truncate(self.chunk.entries.last().unwrap().range.end);
            self.chunk.text.push('\n');
        }
        if self.chunk.text.len() >= CHUNK_BYTES || self.chunk.entries.len() >= CHUNK_ENTRIES {
            self.flush()?;
        }
        Ok(())
    }

    fn path(
        &mut self,
        path: &Path,
        name: &str,
        options: &LsOptions,
        header: bool,
    ) -> io::Result<()> {
        self.check_cancelled()?;
        if !std::fs::metadata(path)?.is_dir() {
            return self.entry(path, name, options, None);
        }
        if header {
            self.chunk
                .text
                .push_str(&format!("{}:\n", super::display_path(Path::new(name))));
        }
        let mut columns = if options.long || options.one_per_line {
            None
        } else {
            // Measure names only, on the worker. Do not collect directory entries
            // or sniff file contents in this pass. The second pass retains order.
            let mut longest = 3; // ../
            for entry in std::fs::read_dir(path)? {
                self.check_cancelled()?;
                let entry = entry?;
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if options.all || !name.starts_with('.') {
                    // Reserve room for the optional directory slash.
                    longest = longest.max(name_length(&name).saturating_add(1));
                }
            }
            Some(Columns::new(self.width, longest))
        };
        if let Some(parent) = path.canonicalize()?.parent() {
            self.entry(parent, "..", options, columns.as_mut())?;
        }
        self.flush()?;
        for entry in std::fs::read_dir(path)? {
            self.check_cancelled()?;
            let entry = entry?;
            let name = entry.file_name();
            let name = name.to_string_lossy();
            if !options.all && name.starts_with('.') {
                continue;
            }
            self.entry(&entry.path(), &name, options, columns.as_mut())?;
            if options.recursive && entry.file_type()?.is_dir() {
                if let Some(columns) = &mut columns {
                    columns.finish(&mut self.chunk);
                }
                self.chunk.text.push('\n');
                self.path(
                    &entry.path(),
                    &super::display_path(&entry.path()),
                    options,
                    true,
                )?;
            }
        }
        if let Some(columns) = &mut columns {
            columns.finish(&mut self.chunk);
        }
        self.flush()
    }
}
