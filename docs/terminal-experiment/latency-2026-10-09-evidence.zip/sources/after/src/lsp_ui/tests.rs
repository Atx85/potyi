use super::*;
use crate::config::EditorConfig;

fn editor(text: &str) -> Editor {
    let mut editor = Editor::new(EditorConfig::default()).unwrap();
    editor.document.insert(0, text).unwrap();
    editor
}

#[test]
fn pending_results_are_invalid_after_edits_reopens_cursor_moves_or_dismissal() {
    let mut editor = editor("hello");
    let other = self::editor("other");
    let mut bar = CommandBar::new();
    bar.open(":lsp hover");
    let pending = Pending {
        id: 1,
        revision: editor.document.revision(),
        other_revision: other.document.revision(),
        path: editor.path().clone(),
        cursor: 0,
        epoch: bar.epoch(),
    };
    assert!(pending.matches(&editor, &other, &bar));
    editor.document.move_cursor(1).unwrap();
    assert!(!pending.matches(&editor, &other, &bar));
    editor.document.move_cursor(0).unwrap();
    bar.close();
    bar.open(":lsp hover");
    assert!(!pending.matches(&editor, &other, &bar));
    bar.epoch();
    let old = editor.document.revision();
    editor.insert_text("x").unwrap();
    assert_ne!(old, editor.document.revision());
    let changed = editor.document.revision();
    editor.undo().unwrap();
    assert_ne!(changed, editor.document.revision());
    assert_ne!(old, editor.document.revision());
    let undone = editor.document.revision();
    editor.redo().unwrap();
    assert_ne!(undone, editor.document.revision());
}

#[test]
fn batch_formatting_and_replacing_a_document_invalidate_pending_results() {
    let mut active = editor("original\n");
    let mut other = editor("other");
    let mut bar = CommandBar::new();
    bar.open(":lsp definition");
    let pending = Pending {
        id: 1,
        revision: active.document.revision(),
        other_revision: other.document.revision(),
        path: active.path().clone(),
        cursor: active.document.cursor.position,
        epoch: bar.epoch(),
    };
    assert!(pending.matches(&active, &other, &bar));
    active
        .apply_formatted(&mut std::io::Cursor::new(b"formatted\n"))
        .unwrap();
    assert!(!pending.matches(&active, &other, &bar));
    active.undo().unwrap();
    assert_eq!(active.document.text().unwrap(), "original\n");
    assert!(!pending.matches(&active, &other, &bar));
    let pending = Pending {
        revision: active.document.revision(),
        ..pending
    };
    assert!(pending.matches(&active, &other, &bar));
    other = editor("other");
    assert!(!pending.matches(&active, &other, &bar));
}

struct Files(PathBuf);
impl Files {
    fn new() -> Self {
        let directory = std::env::temp_dir().join(format!(
            "potyi-lsp-ui-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&directory).unwrap();
        Self(directory)
    }
    fn write(&self, name: &str, text: &str) -> PathBuf {
        let path = self.0.join(name);
        std::fs::write(&path, text).unwrap();
        path
    }
}
impl Drop for Files {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

#[test]
#[ignore = "SDL integration with temporary cwd; run with SDL_VIDEODRIVER=dummy --ignored --test-threads=1"]
fn unity_missing_language_server_keeps_the_document_editable() {
    use std::time::{Duration, Instant};
    struct WorkingDirectory(PathBuf);
    impl Drop for WorkingDirectory {
        fn drop(&mut self) { std::env::set_current_dir(&self.0).unwrap(); }
    }
    let files = Files::new();
    for directory in ["Assets/Scripts", "ProjectSettings", "config"] {
        std::fs::create_dir_all(files.0.join(directory)).unwrap();
    }
    files.write("ProjectSettings/ProjectVersion.txt", "m_EditorVersion: 6000.0.0f1\n");
    files.write("Game.sln", "");
    let missing = files.0.join("not-installed/csharp-ls.exe");
    files.write("config/lsp.toml", &format!(
        "enabled=false\n[[servers]]\nname='csharp'\ncommand={}\nextensions=['cs']\nlanguage_id='csharp'\n",
        serde_json::to_string(&missing.to_string_lossy()).unwrap(),
    ));
    let source = "\u{feff}using UnityEngine;\r\npublic class Player : MonoBehaviour {}\r\n";
    let path = files.write("Assets/Scripts/Player.cs", source);
    let _cwd = WorkingDirectory(std::env::current_dir().unwrap());
    std::env::set_current_dir(&files.0).unwrap();
    let sdl = sdl3::init().unwrap();
    let events = sdl.event().unwrap();
    let _ = events.register_custom_event::<lsp::Event>();
    let mut pump = sdl.event_pump().unwrap();
    let mut ui = LspUi::new(events);
    let mut active = editor("");
    active.open(path.to_str().unwrap()).unwrap();
    let mut other = editor("another unsaved document");
    let mut bar = CommandBar::new();
    ui.reconcile(&active, &other);
    assert!(ui.sessions.is_empty(), "opening a file must not launch a server");
    active.insert_text("// unsaved edit\r\n").unwrap();
    let edited = active.document.text().unwrap();
    bar.open(":lsp start");
    ui.start(false, &active, &other, &mut bar).unwrap();
    let started = Instant::now();
    while ui.pending.is_some() {
        assert!(started.elapsed() < Duration::from_secs(5));
        if let Some(event) = pump.wait_event_timeout(Duration::from_millis(20))
            && let Some(event) = event.as_user_event_type::<lsp::Event>() {
            ui.accept(event, &mut active, &mut other, &mut bar);
        }
    }
    assert!(bar.is_active() && bar.is_info(), "missing server must show a message");
    assert!(ui.status(&active).contains("was not found"));
    assert!(ui.status(&active).contains("keep editing without LSP"));
    assert_eq!(active.document.text().unwrap(), edited);
    assert_eq!(other.document.text().unwrap(), "another unsaved document");
    assert!(active.is_dirty());
    active.undo().unwrap();
    assert_eq!(active.document.text().unwrap(), source);
    active.insert_text("// still editable\r\n").unwrap();
    assert!(active.document.text().unwrap().starts_with("// still editable"));
    assert_eq!(std::fs::read_to_string(path).unwrap(), source);
    ui.stop();
}

#[test]
#[cfg(unix)]
#[ignore = "SDL integration with a temporary working directory; run with --ignored --test-threads=1"]
fn hover_clicks_refresh_only_the_latest_target_and_respect_dismissal() {
    use std::time::{Duration, Instant};
    struct WorkingDirectory(PathBuf);
    impl Drop for WorkingDirectory {
        fn drop(&mut self) { std::env::set_current_dir(&self.0).unwrap(); }
    }
    let files = Files::new();
    std::fs::create_dir(files.0.join("config")).unwrap();
    let fixture = format!("{}/tests/fixtures/lsp_server.py", env!("CARGO_MANIFEST_DIR"));
    files.write("config/lsp.toml", &format!(
        "enabled = true\n[[servers]]\nname = 'mock'\ncommand = 'python3'\nargs = ['{fixture}', 'incremental']\nextensions = ['rs']\nlanguage_id = 'rust'\n"));
    let path = files.write("main.rs", "one two three");
    let _cwd = WorkingDirectory(std::env::current_dir().unwrap());
    std::env::set_current_dir(&files.0).unwrap();
    let sdl = sdl3::init().unwrap();
    let events = sdl.event().unwrap();
    // SDL retains custom type registration across sequential test contexts.
    let _ = events.register_custom_event::<lsp::Event>();
    let mut pump = sdl.event_pump().unwrap();
    let mut ui = LspUi::new(events);
    let mut active = editor("");
    active.open(path.to_str().unwrap()).unwrap();
    let mut other = editor("");
    let mut bar = CommandBar::new();
    bar.open(":lsp hover");
    ui.document_clicked(&active, &other, &mut bar);
    assert!(ui.pending.is_none(), "typing a command must not enable click inspection");
    ui.request(lsp::Action::Hover, &active, &other, &mut bar).unwrap();
    let first = ui.pending.as_ref().unwrap().id;
    for position in [4, 2, 8] {
        active.document.move_cursor(position).unwrap();
        ui.document_clicked(&active, &other, &mut bar);
    }
    assert_eq!(ui.next_id, first + 1, "clicks must not queue server jobs while busy");
    assert_eq!(ui.hover_refresh.as_ref().unwrap().cursor, 8);
    let mut drain = |ui: &mut LspUi, active: &mut Editor, other: &mut Editor, bar: &mut CommandBar| {
        let deadline = Instant::now() + Duration::from_secs(5);
        while ui.pending.is_some() {
            assert!(Instant::now() < deadline, "hover result timed out");
            if let Some(event) = pump.wait_event_timeout(Duration::from_millis(100))
                && let Some(event) = event.as_user_event_type::<lsp::Event>()
            {
                ui.accept(event, active, other, bar);
            }
        }
    };
    drain(&mut ui, &mut active, &mut other, &mut bar);
    assert_eq!(ui.next_id, first + 2, "only the latest click should create a follow-up request");
    let result: String = (0..bar.suggestion_count()).map(|i| bar.suggestion(i).unwrap().label).collect();
    let result: serde_json::Value = serde_json::from_str(&result).unwrap();
    assert_eq!(result["position"]["character"], 8);
    assert!(bar.is_active());

    active.document.move_cursor(4).unwrap();
    ui.document_clicked(&active, &other, &mut bar);
    assert_eq!(ui.pending.as_ref().unwrap().cursor, 4, "completed hover must refresh on a click");
    active.document.move_cursor(0).unwrap();
    ui.document_clicked(&active, &other, &mut bar);
    let next_id = ui.next_id;
    bar.close();
    drain(&mut ui, &mut active, &mut other, &mut bar);
    assert!(!bar.is_active(), "a late reply must not reopen a dismissed hover");
    assert_eq!(ui.next_id, next_id, "dismissal must discard the queued click");
    assert!(ui.hover_refresh.is_none());
    bar.open(":lsp definition");
    ui.request(lsp::Action::Definition, &active, &other, &mut bar).unwrap();
    active.document.move_cursor(5).unwrap();
    ui.document_clicked(&active, &other, &mut bar);
    drain(&mut ui, &mut active, &mut other, &mut bar);
    assert_eq!(active.document.cursor.position, 5, "a stale definition must not jump away from a click");
    assert!(bar.suggestion(0).unwrap().label.contains("Cursor moved"));
    assert!(bar.prepare_execute());
    ui.request(lsp::Action::Definition, &active, &other, &mut bar).unwrap();
    drain(&mut ui, &mut active, &mut other, &mut bar);
    assert_eq!(active.document.cursor.position, 2);
    assert!(!bar.is_active());
    ui.stop();
}

#[test]
fn navigation_preserves_both_dirty_panes_and_existing_undo_history() {
    let files = Files::new();
    let path = files.write("existing.rs", "a🦀b\n");
    let new = files.write("new.rs", "new\n");
    let mut active = editor("unsaved");
    active.set_dirty(true);
    let mut other = editor("");
    other.open(path.to_str().unwrap()).unwrap();
    other.document.move_cursor(other.document.len()).unwrap();
    other.insert_text("edit").unwrap();
    let history = other.undo_stack.len();
    other.set_read_only(true);
    let result = navigate(
        &lsp::Location {
            path: path.clone(),
            line: 0,
            character: 3,
        },
        &mut active,
        &mut other,
    )
    .unwrap();
    assert!(result.focus_other);
    assert!(!result.document_reloaded);
    assert_eq!(other.document.cursor.column, 2);
    assert_eq!(other.undo_stack.len(), history);
    assert!(other.is_dirty());
    assert!(other.is_read_only());
    assert_eq!(active.document.text().unwrap(), "unsaved");
    assert!(
        navigate(
            &lsp::Location {
                path: new,
                line: 0,
                character: 0
            },
            &mut active,
            &mut other
        )
        .is_err()
    );
    assert_eq!(other.path(), Some(path));
}

#[test]
fn invalid_definition_does_not_replace_a_clean_document() {
    let files = Files::new();
    let path = files.write("new.rs", "a🦀b");
    let mut active = editor("original");
    let mut other = editor("other");
    for (line, character) in [(100, 0), (0, 2), (0, 100)] {
        assert!(
            navigate(
                &lsp::Location {
                    path: path.clone(),
                    line,
                    character
                },
                &mut active,
                &mut other
            )
            .is_err()
        );
        assert_eq!(active.document.text().unwrap(), "original");
        assert_eq!(other.document.text().unwrap(), "other");
    }
}

#[test]
#[ignore = "requires SDL; run with SDL_VIDEODRIVER=dummy and --test-threads=1"]
fn rename_reply_preview_click_enter_apply_and_dismissal() {
    let files = Files::new();
    let path = files.write("main.rs", "old();\n").canonicalize().unwrap();
    let sdl = sdl3::init().unwrap();
    let mut ui = LspUi::new(sdl.event().unwrap());
    let mut active = editor(""); active.open(path.to_str().unwrap()).unwrap();
    let mut other = editor(""); let mut bar = CommandBar::new();
    let make_preview = || crate::workspace_edit::prepare(&serde_json::json!({"changes": {
        lsp::file_uri(&path).unwrap(): [{"range":{"start":{"line":0,"character":0},
            "end":{"line":0,"character":3}},"newText":"renamed"}]
    }}),&files.0,&[lsp::Document { path:path.clone(), text:"old();\n".into() }],
        &std::collections::HashMap::new(),std::time::SystemTime::now()).unwrap();
    bar.open(":lsp rename renamed");
    ui.pending = Some(Pending { id:42,revision:active.document.revision(),other_revision:other.document.revision(),
        cursor:active.document.cursor.position,path:active.path().clone(),epoch:bar.epoch() });
    ui.accept(lsp::Event { id:42,result:Ok(lsp::Reply::Rename(make_preview())) }, &mut active,&mut other,&mut bar);
    assert!(!bar.is_info()); assert!(ui.preview.is_some());
    bar.select_suggestion(0); assert!(!ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap());
    assert!(bar.is_info()); assert_eq!(active.document.text().unwrap(),"old();\n");
    assert!(bar.prepare_execute()); assert!(!ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap());
    assert!(!bar.is_info());
    bar.select_suggestion(1); assert!(ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap());
    assert_eq!(active.document.text().unwrap(),"renamed();\n"); assert!(!bar.is_active());
    assert_eq!(std::fs::read_to_string(&path).unwrap(),"old();\n");
    crate::workspace_edit::history(&mut active,&mut other,false).unwrap();
    bar.open(":lsp rename renamed"); let preview = make_preview(); bar.show_review(preview.choices());
    ui.preview = Some((bar.epoch(),std::sync::Arc::new(preview)));
    bar.close(); ui.discard_dismissed_preview(&bar); assert!(ui.preview.is_none());
    assert_eq!(active.document.text().unwrap(),"old();\n");
}

#[test]
#[ignore = "requires SDL; run with SDL_VIDEODRIVER=dummy and --test-threads=1"]
fn action_picker_click_enter_cancel_and_selection_invalidation() {
    let sdl = sdl3::init().unwrap();
    let mut ui = LspUi::new(sdl.event().unwrap());
    let mut active = editor("Unknown"); let mut other = editor("");
    let mut bar = CommandBar::new();
    let prepare = |ui: &mut LspUi, bar: &mut CommandBar, active: &mut Editor, other: &mut Editor| {
        bar.open(":lsp actions");
        ui.pending = Some(Pending { id:1, revision:active.document.revision(), other_revision:other.document.revision(),
            cursor:active.document.cursor.position, path:active.path().clone(), epoch:bar.epoch() });
        ui.accept(lsp::Event {id:1, result:Ok(lsp::Reply::CodeActions(lsp::CodeActions {
            started:std::time::SystemTime::now(), items:vec![lsp::CodeActionItem {
                title:"Unavailable fix".into(), disabled:Some("Needs a server extension".into()), value:serde_json::json!({})
            }]
        }))}, active, other, bar);
    };
    prepare(&mut ui,&mut bar,&mut active,&mut other);
    assert!(ui.actions.is_some()); assert!(!bar.is_info());
    bar.select_suggestion(0); ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap();
    assert!(bar.is_info()); assert!(bar.prepare_execute());
    ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap(); assert!(!bar.is_info());
    bar.select_suggestion(1); ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap();
    assert!(!bar.is_active()); assert!(ui.actions.is_none());
    prepare(&mut ui,&mut bar,&mut active,&mut other);
    active.document.cursor.anchor = 1;
    ui.review(&mut active,&mut other,&mut bar).unwrap().unwrap();
    assert!(ui.actions.is_none()); assert!(bar.is_info());
    assert_eq!(active.document.text().unwrap(),"Unknown");
    prepare(&mut ui,&mut bar,&mut active,&mut other);
    bar.close(); ui.discard_dismissed_preview(&bar); assert!(ui.actions.is_none());
}

#[test]
#[cfg(unix)]
#[ignore = "SDL integration with a temporary working directory; run with --test-threads=1"]
fn completion_popup_keys_undo_and_stale_results() {
    use std::time::{Duration,Instant};
    struct WorkingDirectory(PathBuf);
    impl Drop for WorkingDirectory { fn drop(&mut self) { std::env::set_current_dir(&self.0).unwrap(); } }
    let files = Files::new();
    std::fs::create_dir(files.0.join("config")).unwrap();
    let fixture = format!("{}/tests/fixtures/lsp_server.py",env!("CARGO_MANIFEST_DIR"));
    files.write("config/lsp.toml",&format!("enabled=true\n[[servers]]\nname='csharp'\ncommand='python3'\nargs=['{fixture}','slow-completion']\nextensions=['cs']\nlanguage_id='csharp'\n"));
    let path = files.write("Player.cs","transform.");
    let _cwd = WorkingDirectory(std::env::current_dir().unwrap());
    std::env::set_current_dir(&files.0).unwrap();
    let sdl=sdl3::init().unwrap(); let events=sdl.event().unwrap();
    // SDL retains custom type registration across sequential test contexts.
    let _ = events.register_custom_event::<lsp::Event>();
    let mut pump=sdl.event_pump().unwrap(); let mut ui=LspUi::new(events);
    let mut active=editor(""); active.open(path.to_str().unwrap()).unwrap();
    active.document.move_cursor(10).unwrap();
    let mut other=editor(""); let mut bar=CommandBar::new();
    let drain=|ui:&mut LspUi,active:&mut Editor,other:&mut Editor,bar:&mut CommandBar,pump:&mut sdl3::EventPump| {
        let started=Instant::now();
        while ui.pending.is_some() {
            assert!(started.elapsed()<Duration::from_secs(5));
            if let Some(event)=pump.wait_event_timeout(Duration::from_millis(20))
                && let Some(event)=event.as_user_event_type::<lsp::Event>() {ui.accept(event,active,other,bar);}
        }
    };
    ui.typed_member_trigger(".",&active,&other,&mut bar);
    assert!(!bar.is_active(),"autocomplete must not open the command bar");
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert_eq!(ui.completion_display().unwrap().labels,["position","Translate"]);
    assert!(ui.completion_key(sdl3::keyboard::Keycode::Down,false,&active,&other,&mut bar));
    assert_eq!(ui.completion_display().unwrap().selected,1);
    assert!(ui.completion_key(sdl3::keyboard::Keycode::Return,false,&active,&other,&mut bar));
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert_eq!(active.document.text().unwrap(),"transform.Translate");
    assert_eq!(active.document.cursor.position,19);
    assert_eq!(std::fs::read_to_string(&path).unwrap(),"transform.","completion must not save");
    active.undo().unwrap();
    assert_eq!(active.document.text().unwrap(),"transform.");
    assert_eq!(active.document.cursor.position,10);
    active.redo().unwrap();
    assert_eq!(active.document.cursor.position,19);
    active.undo().unwrap();
    ui.typed_member_trigger(".",&active,&other,&mut bar);
    active.insert("x").unwrap();
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert!(ui.completion_display().is_none());
    assert_eq!(active.document.text().unwrap(),"transform.x");
    active.undo().unwrap();
    ui.typed_member_trigger(".",&active,&other,&mut bar);
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert!(ui.completion_key(sdl3::keyboard::Keycode::Escape,false,&active,&other,&mut bar));
    assert!(ui.completion_display().is_none());
    ui.stop();
}

#[test]
#[cfg(unix)]
#[ignore = "SDL integration with temporary config; run with --test-threads=1"]
fn start_enables_stopped_lsp_and_restart_recovers_after_failure() {
    use std::time::{Duration,Instant};
    struct WorkingDirectory(PathBuf);
    impl Drop for WorkingDirectory { fn drop(&mut self) { std::env::set_current_dir(&self.0).unwrap(); } }
    let files=Files::new(); std::fs::create_dir(files.0.join("config")).unwrap();
    let fixture=format!("{}/tests/fixtures/lsp_server.py",env!("CARGO_MANIFEST_DIR"));
    let settings=format!("enabled=false\n[[servers]]\nname='mock'\ncommand='python3'\nargs=['{fixture}','incremental']\nextensions=['rs']\nlanguage_id='rust'\n");
    files.write("config/lsp.toml",&settings);
    let path=files.write("main.rs","player.");
    let _cwd=WorkingDirectory(std::env::current_dir().unwrap()); std::env::set_current_dir(&files.0).unwrap();
    let sdl=sdl3::init().unwrap(); let events=sdl.event().unwrap(); let _=events.register_custom_event::<lsp::Event>();
    let mut pump=sdl.event_pump().unwrap(); let mut ui=LspUi::new(events);
    let mut active=editor(""); active.open(path.to_str().unwrap()).unwrap(); active.document.move_cursor(7).unwrap();
    let mut other=editor(""); let mut bar=CommandBar::new();
    let drain=|ui:&mut LspUi,active:&mut Editor,other:&mut Editor,bar:&mut CommandBar,pump:&mut sdl3::EventPump| {
        let started=Instant::now();
        while ui.pending.is_some() {
            assert!(started.elapsed()<Duration::from_secs(5));
            if let Some(event)=pump.wait_event_timeout(Duration::from_millis(20))
                && let Some(event)=event.as_user_event_type::<lsp::Event>() {ui.accept(event,active,other,bar);}
        }
    };
    ui.typed_member_trigger(".",&active,&other,&mut bar); assert!(ui.pending.is_none());
    bar.open(":lsp start"); ui.start(false,&active,&other,&mut bar).unwrap();
    assert!(ui.status(&active).contains("Connecting / loading"));
    // Connection status should survive moving the cursor or closing its panel.
    active.document.move_cursor(0).unwrap(); bar.close();
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert!(ui.status(&active).contains("Connected to mock"));
    assert!(!bar.is_active());
    active.document.move_cursor(7).unwrap();
    ui.typed_member_trigger(".",&active,&other,&mut bar);
    assert_eq!(ui.completion_display().unwrap().total,0,"loading is visible immediately");
    ui.stop(); ui.typed_member_trigger(".",&active,&other,&mut bar);
    assert!(ui.pending.is_none(),"stop must pause automatic restarts");
    files.write("config/lsp.toml",&settings.replace("command='python3'","command='potyi-nonexistent-language-server'"));
    bar.open(":lsp restart"); ui.start(true,&active,&other,&mut bar).unwrap();
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert!(ui.status(&active).contains("Could not start LSP"));
    files.write("config/lsp.toml",&settings);
    ui.start(true,&active,&other,&mut bar).unwrap();
    drain(&mut ui,&mut active,&mut other,&mut bar,&mut pump);
    assert!(ui.status(&active).contains("Connected to mock"));
    assert!(!ui.status(&active).contains("Could not start LSP"));
    assert_eq!(std::fs::read_to_string("config/lsp.toml").unwrap(),settings,"start is a window-local opt-in");
    assert!(bar.prepare_execute(),"Enter retries start/restart from their result panel");
    ui.stop();
}

#[test]
#[ignore = "SDL setup integration; run with SDL_VIDEODRIVER=dummy and --test-threads=1"]
fn setup_ui_doctor_keeps_editing_and_delivers_background_result() {
    let sdl = sdl3::init().unwrap();
    let events = sdl.event().unwrap();
    events.register_custom_event::<crate::lsp_setup::Event>().unwrap();
    let mut pump = sdl.event_pump().unwrap();
    let mut ui = LspUi::new(events);
    let mut document = editor("unsaved text");
    let other = editor("");
    let mut bar = CommandBar::new(); bar.open(":lsp doctor");
    ui.setup(false, None, &document, &mut bar).unwrap();
    document.document.insert(0, "still editing ").unwrap();
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    while std::time::Instant::now() < deadline {
        for event in pump.poll_iter() {
            if let Some(event) = event.as_user_event_type::<crate::lsp_setup::Event>() {
                ui.accept_setup(event, &document, &other, &mut bar);
            }
        }
        if ui.setup.last.as_ref().is_some_and(|text| text.contains("not managed by Potyi") || text.contains("configured")) { break; }
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    assert!(ui.setup.last.as_ref().is_some_and(|text| text.contains("LSP setup ·")), "{:?}", ui.setup.last);
    assert!(bar.is_info());
    assert_eq!(document.document.text().unwrap(), "still editing unsaved text");
    assert!(ui.sessions.is_empty());
}
